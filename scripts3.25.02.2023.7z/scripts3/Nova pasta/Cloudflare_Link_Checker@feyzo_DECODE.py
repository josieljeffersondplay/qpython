import requests
feyzo=("""
\33[0m⭐️ \33[1;93;33m   𝗣𝗬 𝗖𝗼𝗻𝗳𝗶𝗴    ✩✩ ᴄᴏɴғɪɢ ✩✩ \33[0m ⭐️  \33[33m                 
╔══════════════════════════════════        
║████  ████ ██ ░░ ██ ██████ ░ ████ ░░░       
║██ ░░ ██ ░░ ██  ██ ░░░░ ██ ░██ ░ ██ ░░      
║████  ████ ░ ████ ░░░ ██ ░ ██ ░░░ ██ ░     
║██ ░░ ██ ░░░░ ██ ░░ ██ ░░░░ ██ ░ ██ ░░      
║██ ░░ ████ ░░ ██ ░░ ██████ ░ ████ ░░░        
╚══════════════════════════════════                   
\33[0m⭐️ \33[1;93;33m   𝗣𝗬 𝗖𝗼𝗻𝗳𝗶𝗴    ✩✩ ᴄᴏɴғɪɢ ✩✩ \33[0m ⭐️  

Telegram Address 𝗫 𝗗𝗲𝗲𝗽 𝗚𝗿𝘂𝗽 

🅵🅴🆈🆉🅾️ .       https://t.me/FeyzullahK
☻EFRAİM_OĞUZ☻ .. https://t.me/Karameke

""")
print(feyzo) 
def temizle():
    os.system('clear')
def macHea(panel,macs):
	HEADERA={
"User-Agent":"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 2721 Mobile Safari/533.3" ,
"Referer": "http://"+panel+"/c/" ,
"Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
"Cookie": "mac="+macs+"; stb_lang=en; timezone=Europe%2FIstanbul;",
"Accept-Encoding": "gzip, deflate" ,
"Connection": "Keep-Alive" ,
"X-User-Agent":"Model: MAG254; Link: Ethernet",
	}
	return HEADERA

ses=requests.session()
from requests.packages.urllib3.util.ssl_ import create_urllib3_context
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import logging
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS="TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP"	
def bekle():
	global i
	i +=1
	if i==15:
		i=0
	animation = [
"[■□□□□□□□□□□□□□□]","[■■□□□□□□□□□□□□□]", "[■■■□□□□□□□□□□□□]", "[■■■■□□□□□□□□□□□]", "[■■■■■□□□□□□□□□□]", "[■■■■■■□□□□□□□□□]", "[■■■■■■■□□□□□□□□]", "[■■■■■■■■□□□□□□□]", "[■■■■■■■■■□□□□□□]", "[■■■■■■■■■■□□□□□]",
"[■■■■■■■■■■■□□□□]",
"[■■■■■■■■■■■■□□□]",
"[■■■■■■■■■■■■■□□]",
"[■■■■■■■■■■■■■■□]",
"[■■■■■■■■■■■■■■■]"]
	time.sleep(3.9)
	sys.stdout.write("\r" + animation[ i % len(animation)]+'𝙲𝚑𝚎𝚌𝚔𝚒𝚗𝚐')
	sys.stdout.flush()

		
i =0
hitsdir='/sdcard/Hits/'
import time,sys,os
if not os.path.exists(hitsdir):
	    os.mkdir(hitsdir)
timestr = time.strftime("%d%m%Y")
def kaydet(hit):
	dosya=open(hitsdir+"CloudFlare"+str(timestr)+'@feyzo.txt','a+')
	dosya.write(hit)
	dosya.close()	
import random
def randommac():
	genmac = str("00:1A:79:")+"%02x:%02x:%02x"% ((random.randint(0, 256)),(random.randint(0, 256)),(random.randint(0, 256)))
	genmac=genmac.replace('100','10')
	return genmac

ses= requests.session()
pal=input("dns/ip:")
import os
temizle()
if 'http://' in pal:
	pal=pal.split("://")[1]
	pal=pal.split('/')[0]
pal=pal.replace('/c/','')
pal=pal.replace('/c','')
pal=pal.replace('/','')
port=""
if ":" in pal:
	port=pal.split(":")[1]
	pal=pal.split(':')[0]
print(pal)
if port =="":
	port=input("port:")
url='https://iplist.cc/api/'+pal
res = str(ses.get(url,timeout=(2)).text)
veri=res.split('[')[1].split(']')[0]
k1=veri.replace(' ','').replace('"','').replace('\n','')
k1='http://'+str(k1).replace(',',' \nhttp://')+' \n'
k1=k1.replace('http://','http://')
if not port=="":
	k1=k1.replace(' \n',':'+str(port)+'/c/ \n')
import threading
def macp(panel):
	yaz=""
	bekle()
	mac=randommac().upper()
	macs=mac.replace(':','%3A')
	veri1=str('Panel: http://'+panel+"/c\n")
	veri4=""
	uzmanx=""
	try:
		veri4=str(ses.get('http://'+panel+'/c/xpcom.common.js',headers=macHea(panel,macs), timeout=(2), verify=None).text.replace(' ','').split("portal_ip+'")[1].split("';")[0]+'\n')
		if "+this.portal_path+'" in veri4:
			veri4=veri4.split("+'")[1]
		uzmanm="Request: "+veri4
		uzman=veri4.replace('\n','')
		uzmanx=veri4
	except:pass
	if veri4=="":
		uzman='/portal.php'
		uzmanm="Request: /portal.php\n"
	url="http://"+panel+uzman+"?type=stb&action=handshake&prehash=false&JsHttpRequest=1-xml"
	
	veri=""
	try:
		bekle()
		res = ses.get(url, headers=macHea(panel,macs), timeout=(2), verify=None)
		veri=str(res.text)
	except:pass
	
	if not '{"token":' in veri:
		uzman="/server/load.php"
		url="http://"+panel+uzman+"?type=stb&action=handshake&prehash=false&JsHttpRequest=1-xml"
		veri=""
		try:
			bekle()
			res = ses.get(url, headers=macHea(panel,macs), timeout=(2), verify=None)
			veri=str(res.text)
			if '{"token":' in veri:
				uzmanm="Request: /server/load.php\n"
	
		except:pass
	if not '{"token":' in veri:
		feyzo="feyzo"
		veri2=""
		try:
			bekle()
			veri2=str('Title: '+ses.get('http://'+panel+'/c/',headers=macHea(panel,macs), timeout=(2), verify=None).text.split('<title>')[1].split('<')[0]+'\n')
	
		except:pass
		if 'portal' in veri2 or 'NXT' in veri2:
			yaz=("├▣"+veri1+"├▣"+veri2+"╰─➤"+uzmanm)
		else:
			if  not uzmanx=="":
				yaz=("├▣"+veri1+"├▣"+veri2+"╰─➤"+uzmanm)
		
	else:
	    token="**"+str(veri.replace('{"js":{"token":',""))
	    token=token.replace('**"','')
	    token=token.split('"')[0]
	 
	    token=str("Token: "+token+"\n")
	    bekle()
	    veri3=str('Status: '+str(res.status_code)+'\n')
	    veri2=""
	    try:
	    	veri2=str('Title: '+ses.get('http://'+panel+'/c/',headers=macHea(panel,macs), timeout=(2), verify=None).text.split('<title>')[1].split('<')[0]+'\n')
	    except:pass
	    veri5="RandomMac: "+mac+"\n"
	    yaz=("├▣"+veri1+"├▣"+token+"├▣"+veri2+"├▣"+veri3+"├▣"+uzmanm+"╰─➤"+veri5)
	 
	bekle()
	if not yaz=="":
		yaz="╭➢ 𝗖𝗹𝗼𝘂𝗱𝗙𝗹𝗮𝗿𝗲 𝗖𝗵𝗲𝗰𝗸 𝗟𝗶𝗻𝗸 \n" + str(yaz)
		kaydet('\n\n'+str(yaz))
		print('\n\n'+str(yaz))			

for panel in k1.split('http://'):
	panel=panel.replace('\n','').replace('/c/','').replace(' ','')
	if panel=="":
		continue
	t=threading.Thread(target=macp,kwargs={'panel':panel})
	t.start()
