#qpy:console
try:
    
    from ________ import FreedomCreative 
except:
    from ________ import FreedomCreative 

fc = FreedomCreative()
fc.set_config('UniverDroid/UniversoAndroid.ini')
fc.silva()