import random
import subprocess
subprocess.run(["clear", ""])
import string

# CÓDIGO FEITO POR MAX ROOT'S 
# MOD BY MAX

#largocadena= 20 #longitud de la cadena de texto


c = ['1','2','3','4','5','6','7','8','9','0','a','b', 'c', 'd', 'e','f', 'g','h','i','j','k', 'l', 'm', 'n', 'o','p', 'q', 'r', 's', 't', 'u', 'w','v', 'x', 'y', 'z', 'A','B', 'C', 'D', 'E','F', 'G','H','I','J','K', 'L', 'M', 'N', 'O','P', 'Q', 'R', 'S', 'T', 'U', 'W','V', 'X', 'Y', 'Z']

print(" ")
print(" ")


n = int(input("""
 ╔══════════════════════════════════════╗         
 ║         ░░▒█ █▀▀█ █▀▀ ░▀░ █▀▀ █░░
 ║         ▄░▒█ █░░█ ▀▀█ ▀█▀ █▀▀ █░░
 ║         █▄▄█ ▀▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀
 ║
 ║ ░░▒█ █▀▀ █▀▀ █▀▀ █▀▀ █▀▀█ █▀▀ █▀▀█ █▀▀▄
 ║ ▄░▒█ █▀▀ █▀▀ █▀▀ █▀▀ █▄▄▀ ▀▀█ █░░█ █░░█
 ║ █▄▄█ ▀▀▀ ▀░░ ▀░░ ▀▀▀ ▀░▀▀ ▀▀▀ ▀▀▀▀ ▀░░▀
 ╚════════════ Geredor de Combo Xtream Codes ╝\n
	           
\33[0m\n\nDigite a quantidade que deseja gerar : """))
print (" ")
largouser=input("Digite o comprimento do usuário: ")
if largouser == "0" or largouser=="":
    largouser="4"
largouser=int(largouser)
print(" ")
largopass=input("Digite o comprimento da senha: ")
if largopass == "0" or largopass=="":
    largopass="4"
largopass=int(largopass)
print(" ")
print ("╔════════════════  Combo  ══════════════╗       ")
print ("║      ▀▄▒▄▀ ▀▀█▀▀ █▀▀█ █▀▀ █▀▀█ █▀▄▀█       ")
print ("║      ░▒█░░ ░░█░░ █▄▄▀ █▀▀ █▄▄█ █░▀░█       ")
print ("║      ▄▀▒▀▄ ░░▀░░ ▀░▀▀ ▀▀▀ ▀░░▀ ▀░░░▀       ")
print ("║   ")
print ("║            █▀▀ █▀▀█ █▀▀▄ █▀▀ █▀▀    ")
print ("║            █░░ █░░█ █░░█ █▀▀ ▀▀█    ")
print ("║            ▀▀▀ ▀▀▀▀ ▀▀▀░ ▀▀▀ ▀▀▀    ")
print ("╚════════════ Geredor de Combo Xtream Codes ╝  \33[0m ")
filename = input("\nNome do combo : ")
filename = filename + ".txt"
print (" ")



f = open(filename, "w")
f.write("")
f.close()



i = 1

while i <= n:
   
   user = (''.join(random.choice(c) for _ in range(largouser)))
   pas  = (''.join(random.choice(c) for _ in range(largopass)))
   
   user=user+":"+pas
   print(i," = ",user)
   f = open(filename, "a")
   f.write(user)
   f.write("\n")
   f.close()
   i += 1
   


print ("\33[1;37;42m")
print (n," Combo gerado com sucesso : ",filename,)
print ("\33[0m")
print(" ╔══════════════════════════════════════╗        ")
print(" ║ ░░▒█ █▀▀█ █▀▀ ░▀░ █▀▀ █░░                       ")
print(" ║ ▄░▒█ █░░█ ▀▀█ ▀█▀ █▀▀ █░░                       ")
print(" ║ █▄▄█ ▀▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀                       ")
print(" ║                                                    ")
print(" ║ ░░▒█ █▀▀ █▀▀ █▀▀ █▀▀ █▀▀█ █▀▀ █▀▀█ █▀▀▄    ")
print(" ║ ▄░▒█ █▀▀ █▀▀ █▀▀ █▀▀ █▄▄▀ ▀▀█ █░░█ █░░█    ")    
print(" ║ █▄▄█ ▀▀▀ ▀░░ ▀░░ ▀▀▀ ▀░▀▀ ▀▀▀ ▀▀▀▀ ▀░░▀    ")
print(" ╚════════════ Geredor de Combo Xtream Codes. ╝\n")
