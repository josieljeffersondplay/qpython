import os,pip
import random
import sys
import time
import names

#os.system('clear')
time.sleep(0.1)
print ("""
+========================+========================+
|               Coded By FERO               |
|                                                                      
+========================+========================+

""")
time.sleep(0.1)
print ("""
[*].Choose Which Type of Combo Mail You Want.
1)Mail:pass.
2)User:pass.
3)User:pass matching.
4)Mail.
5)Pass.
6)User.
7)user:pass with numbers 
8)user:with numbers
9)pass:with numbers 
10)pass:birth year
11)user:birth year
12)user:pass:birth year
99)Exit.

""")
menu = input("Enter Option ")
if menu=="1":
	print ("\t\t\33[1;100m (.txt) schreibe \33[0m ")
	filename = input("\nDer Name Ihrer Combo  :  ")
	gmail = input("Which Mail Type ? (Ex:@gmail.com): ")
	hwm = int(input("How Many Time (x2): "))
	i=1
	for i in range (0,hwm):
		i = 1+1
		rname = names.get_first_name()
		rlastname = names.get_last_name()
		num = random.randint(0,2020)
		all1 = "%s%s%s"%(rname,num,gmail)
		alln = "%s%s%s%s"%(all1,":",rname,num)
		all2 = "%s%s%s"%(rlastname,num,gmail)
		allf = "%s%s%s%s"%(all2,":",rlastname,num) 
		print(alln)
		print(allf)
		F ="/sdcard/combo/"+filename+".txt"
		f = open(F, "a+",encoding= "utf-8")
		f.write(alln)
		f.write("\n")
		f.write(allf)
		f.write("\n")
		f.close()
		i += 1

if menu=="2":
	print ("\t\t\33[1;100m (.txt) schreibe \33[0m ")
	filename = input("\nDer Name Ihrer Combo  : ")
	hwm = int(input("How Many Time (x2): "))
	i=1
	for i in range (0,hwm):
		i = 1+1
		rname = names.get_first_name()
		rlastname = names.get_last_name()
		num = random.randint(1900,2020)
		all1 = "%s%s"%(rname,num)
		alln = "%s%s%s%s"%(all1,":",rlastname,num)
		all2 = "%s%s"%(rlastname,num)
		allf = "%s%s%s%s"%(all2,":",rname,num) 
		print(alln)
		print(allf)
		F ="/sdcard/combo/"+filename+".txt"
		f = open(F, "a+",encoding= "utf-8")
		f.write(alln)
		f.write("\n")
		f.write(allf)
		f.write("\n")
		f.close()
		i += 1
		

if menu=="3":
	print ("\t\t\33[1;100m (.txt) schreibe \33[0m ")
	filename = input("\nDer Name Ihrer Combo  :  ")
	hwm = int(input("How Many Time (x2): "))
	i=1
	for i in range (0,hwm):
		i = 1+1
		rname = names.get_first_name()
		rlastname = names.get_last_name()
		num = random.randint(0,999)
		all1 = "%s"%(rname)
		alln = "%s%s%s"%(all1,":",rname)
		all2 = "%s"%(rlastname)
		allf = "%s%s%s"%(all2,":",rlastname)
		print(alln)
		print(allf)
		F ="/sdcard/combo/"+filename+".txt"
		f = open(F, "a+",encoding= "utf-8")
		f.write(alln)
		f.write("\n")
		f.write(allf)
		f.write("\n")
		f.close()
		i += 1

if menu=="4":
	print ("\t\t\33[1;100m (.txt) schreibe \33[0m ")
	filename = input("\nDer Name Ihrer Combo  :  ")
	gmail = input("Which Mail Type ? (Ex:@gmail.com): ")
	hwm = int(input("How Many Time (x2): "))
	i=1
	for i in range (0,hwm):
		i = 1+1
		rname = names.get_first_name()
		rlastname = names.get_last_name()
		num = random.randint(1500,2020)
		all1 = "%s%s%s"%(rname,num,gmail)
		all2 = "%s%s%s"%(rlastname,num,gmail)
		print(all1)
		print(all2)
		F ="/sdcard/combo/"+filename+".txt"
		f = open(F, "a+",encoding= "utf-8")
		f.write(all1)
		f.write("\n")
		f.write(all2)
		f.write("\n")
		f.close()
		i += 1

if menu=="5":
	print ("\t\t\33[1;100m (.txt) schreibe \33[0m ")
	filename = input("\nDer Name Ihrer Combo  :  ")
	hwm = int(input("How Many Time (x2): "))
	i=1+1
	for i in range (0,hwm):
		i = 1
		rname = names.get_first_name()
		rlastname = names.get_last_name()
		num = random.randint(0,999)
		alln = "%s"%(rname)
		print(alln)
		F ="/sdcard/combo/"+filename+".txt"
		f = open(F, "a+",encoding= "utf-8")
		f.write(alln+":"+alln)
		f.write("\n")
		f.close()
		
		
if menu=="6":
	print ("\t\t\33[1;100m  schreibe \33[0m ")
	filename = input("\nDer Name Ihrer Combo  :  ")
	hwm = int(input("How Many Time (x2): "))
	i=1
	for i in range (0,hwm):
	    i = 1+1
	    rname = names.get_first_name()
	    rlastname = names.get_last_name()
	    num = random.randint(0,999)
	    all1 = "%s"%(rname)
	    all2 = "%s"%(rlastname)
	    print(all1)
	    print(all2)
	    F ="/sdcard/combo/"+filename+".txt"
	    f = open(F, "a+",encoding= "utf-8")
	    f.write(all1+":"+all1)
	    f.write("\n")
	    f.write(all2+":"+all2)
	    f.write("\n")
	    f.close()
	    i += 1
        
        
if menu=="7":
	print ("\t\t\33[1;100m  schreibe \33[0m ")
	filename = input("\nDer Name Ihrer Combo  :  ")
	hwm = int(input("How Many Time (x2): "))
	i=1
	for i in range (0,hwm):
		i = 1+1
		rname = names.get_first_name()
		rlastname = names.get_last_name()
		num = random.randint(0,999)
		all1 = "%s%s"%(rname,num)
		alln = "%s%s%s%s"%(all1,":",rname,num)
		all2 = "%s%s"%(rlastname,num)
		allf = "%s%s%s%s"%(all2,":",rlastname,num)
		print(alln)
		print(allf)		
		F ="/sdcard/combo/"+filename+".txt"
		f = open(F, "a+",encoding= "utf-8")
		f.write(alln)
		f.write("\n")
		f.write(allf)
		f.write("\n")
		f.close()
	
if menu=="8":
    print ("\t\t\33[1;100m (.txt) schreibe  \33[0m ")
    filename = input("\nDer Name Ihrer Combo  :  ")
    hwm = int(input("How Many Time (x2): "))
    i=1
    for i in range (0,hwm):
    	i = 1+1
    	rname = names.get_first_name()
    	rlastname = names.get_last_name()
    	num = random.randint(0,2020)
    	alln = "%s%s"%(rname,num)
    	print(alln)	
    	F ="/sdcard/combo/"+filename+".txt"
    	f = open(F, "a+",encoding= "utf-8")
    	f.write(alln+":"+alln)
    	f.write("\n")
    	f.close()

if menu=="9":
    print ("\t\t\33[1;100m (.txt) schreibe  \33[0m ")
    filename = input("\nDer Name Ihrer Combo  :  ")
    hwm = int(input("Quantas vezes (x2): "))
    i=1
    for i in range (0,hwm):
        i = 1+1
        rname = names.get_first_name()
        rlastname = names.get_last_name()
        num = random.randint(0,999)
        all1 = "%s%s"%(rname,num)
        all2 = "%s%s"%(rlastname,num)
        print(all1)
        print(all2)
        F ="/sdcard/combo/"+filename+".txt"
        f = open(F, "a+",encoding= "utf-8")
        f.write(all1+":"+all1)
        f.write("\n")
        f.write(all2+":"+all2)
        f.write("\n")
        f.close()
        i += 1
    
if menu=="10":
	print ("\t\t\33[1;100m (.txt) schreibe \33[0m ")
	filename = input("\nDer Name Ihrer Combo  :  ")
	hwm = int(input("How Many Time (x2): "))
	i=1
	for i in range (0,hwm):
		i = 1+1
		rname = names.get_first_name()
		rlastname = names.get_last_name()
		num = random.randint(1900,2023)
		alln = "%s%s"%(rname,num)
		print(alln)	
		F ="/sdcard/combo/"+filename+".txt"
		f = open(F, "a+",encoding= "utf-8")
		f.write(alln+":"+alln)
		f.write("\n")
		f.close()

if menu=="11":
    print ("\t\t\33[1;100m (.txt) schreibe \33[0m ")
    filename = input("\nDer Name Ihrer Combo  :  ")
    hwm = int(input("How Many Time (x2): "))
    i=1
    for i in range (0,hwm):
        i = 1+1
        rname = names.get_first_name()
        rlastname = names.get_last_name()
        num = random.randint(1900,2023)
        all1 = "%s%s"%(rname,num)
        all2 = "%s%s"%(rlastname,num)
        print(all1)
        print(all2)
        F ="/sdcard/combo/"+filename+".txt"
        f = open(F, "a+",encoding= "utf-8")
        f.write(all1+":"+all1)
        f.write("\n")
        f.write(all2+":"+all2)
        f.write("\n")
        f.close()
        i += 1
    
    
if menu=="12":
	print ("\t\t\33[1;100m (.txt) schreibe  \33[0m ")
	filename = input("\nDer Name Ihrer Combo  :  ")
	hwm = int(input("How Many Time (x2): "))
	i=1
	for i in range (0,hwm):
		i = 1+1
		rname = names.get_first_name()
		rlastname = names.get_last_name()
		num = random.randint(1500,2023)
		all1 = "%s%s"%(rname,num)
		alln = "%s%s%s%s"%(all1,":",rname,num)
		all2 = "%s%s"%(rlastname,num)
		allf = "%s%s%s%s"%(all2,":",rlastname,num)
		print(alln)
		print(allf)
		F ="/sdcard/combo/"+filename+".txt"
		f = open(F, "a+",encoding= "utf-8")
		f.write(alln)
		f.write("\n")
		f.write(allf)
		f.write("\n")
		f.close()
		i += 1
   


print ("\33[1;37;42m")
print (f," REGISTRADO COM SUCESSO NO DISPOSITIVO : ",f,)
print ("\33[0m")



		
			
					
if menu=="99":
     quit()

	