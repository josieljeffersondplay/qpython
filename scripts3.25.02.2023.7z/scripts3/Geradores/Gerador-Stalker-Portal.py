#Jader Iptv Mix


yeninesil=(
   
"00:1A:79:",
"33:44:CF:",
"10:27:BE:",
"00:1D:E0:",
"10:2F:6B:",
"00:04:4B:",
"74:E5:F9:",
"48:B0:2D:",
"90:0E:B3:",
"90:0E:B3:10:51",
"18:C8:E7:04:3A",
)

import random
import subprocess,webbrowser
subprocess.run(["clear", ""])
jader=("""
\33[32m▰▰ 🅹︎🅰︎🅳︎🅴︎🆁︎ 🄸🄿🅃🅅 🅼︎🅸︎🆇︎ ▰▰           \33[33m    
        
 ╔══════════════════════════════════════╗      
 ║         ░░▒█ █▀▀█ █▀▀ ░▀░ █▀▀ █░░          
 ║         ▄░▒█ █░░█ ▀▀█ ▀█▀ █▀▀ █░░          
 ║         █▄▄█ ▀▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀           
 ║                                               
 ║ ░░▒█ █▀▀ █▀▀ █▀▀ █▀▀ █▀▀█ █▀▀ █▀▀█ █▀▀▄     
 ║ ▄░▒█ █▀▀ █▀▀ █▀▀ █▀▀ █▄▄▀ ▀▀█ █░░█ █░░█     
 ║ █▄▄█ ▀▀▀ ▀░░ ▀░░ ▀▀▀ ▀░▀▀ ▀▀▀ ▀▀▀▀ ▀░░▀     
 ╚══════════ Geredor de Combo Portal Stalker ╝   \n          
\33[32m▰▰▰▰ GERADOR DE MAC ☠️🅹︎🅰︎🅳︎🅴︎🆁︎☠️ ▰▰▰▰             \33[0m\33[1;40m

\33[0m\33[1;40m ╔════════════════  Combo  ═══════════════╗     
 ║
 ║         █▀▀█ █▀▀█ █▀▀█ ▀▀█▀▀ █▀▀█ █░░   
 ║         █▄▄█ █░░█ █▄▄▀ ░░█░░ █▄▄█ █░░   
 ║         █░░░ ▀▀▀▀ ▀░▀▀ ░░▀░░ ▀░░▀ ▀▀▀    
 ║ 
 ║      █▀▀▀█ ▀▀█▀▀ █▀▀█ █░░ █░█ █▀▀ █▀▀█      
 ║      ▀▀▀▄▄ ░░█░░ █▄▄█ █░░ █▀▄ █▀▀ █▄▄▀      
 ║      █▄▄▄█ ░░▀░░ ▀░░▀ ▀▀▀ ▀░▀ ▀▀▀ ▀░▀▀      
 ║ 
 ╚══════════════════════════════════════╝      \33[0m\33[1;40m""")

print(jader) 
print("""

Tipos de Mac disponíveis:
""")
nnesil=str(yeninesil)
nnesil=(nnesil.count(',')+1)
for xd in range(0,(nnesil)):
		print(str(xd+1)+" - "+yeninesil[xd] )
#subprocess.run(["clear", ""])


#print(nnesil)
i=0

dosya=input("""
Entre com nome do seu arquivo combo...

Não coloque \33[1;31;40m.txt\33[0m\33


 Nome do arquivo = """)
karisik=input("""
\33[1;31;40m 
Aperte enter 👉 \33[0m\33[1;40mpara escolher o tipo de Mac👈  """)
karisik=karisik.upper()
print("")
if not karisik[:1]=="E" :
	for xd in range(0,(nnesil)):
		print(str(xd+1)+" - "+yeninesil[xd] )
	nesil=input("""escolha o tipo de Mac=""")

adet=input("""

Quantos macs quer gerar? =""")

DosyaA="/sdcard/combo/" +dosya+".csv"
def kaydet(mac):
    dosya=open(DosyaA,'a+') 
    dosya.write(mac)
    dosya.close()


while True:
	#hex_num = hex(mac)[2:].zfill(6)
	genmac = "%02x:%02x:%02x"% (random.randint(0, 256),random.randint(0, 256),random.randint(0, 256))
	genmac=genmac.replace('100','10')
	genmac=genmac.upper()
	#print(karisik[:1])
	if karisik[:1]=="E" :
		for xd in range(0,nnesil):
				genmac = "%02x:%02x:%02x"% (random.randint(0, 256),random.randint(0, 256),random.randint(0, 256))
				genmac=genmac.replace('100','10')
				print(yeninesil[xd]+genmac)
				kaydet(yeninesil[xd]+genmac+"\n")
	else:
		print(yeninesil[int(nesil)-1]+genmac)
		kaydet(yeninesil[int(nesil)-1]+genmac+"\n")
		i=i+1			
	
	if str(i) ==adet:
		break

print("\n\n Processo completo, aproveite seu combo!\n\n")

print("Arquivo salvo em sdcard/combo/")
	
print(" ╔══════════════════════════════════════╗        ")
print(" ║ ░░▒█ █▀▀█ █▀▀ ░▀░ █▀▀ █░░                       ")
print(" ║ ▄░▒█ █░░█ ▀▀█ ▀█▀ █▀▀ █░░                       ")
print(" ║ █▄▄█ ▀▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀                       ")
print(" ║                                                    ")
print(" ║ ░░▒█ █▀▀ █▀▀ █▀▀ █▀▀ █▀▀█ █▀▀ █▀▀█ █▀▀▄    ")
print(" ║ ▄░▒█ █▀▀ █▀▀ █▀▀ █▀▀ █▄▄▀ ▀▀█ █░░█ █░░█    ")    
print(" ║ █▄▄█ ▀▀▀ ▀░░ ▀░░ ▀▀▀ ▀░▀▀ ▀▀▀ ▀▀▀▀ ▀░░▀    ")
print(" ╚══════════ Geredor de Combo Portal Stalker ╝\n")