import os,sys

combo="1"

if combo=="1":
 	say=0
 	dsy=""
 	dir='/sdcard/combo/'
 	for files in os.listdir (dir):
 		say=say+1
 		dsy=dsy+"	"+str(say)+"=⫸ "+files+'\n'
 	print ("""Aşağıdaki listeden combonuzu seçin!!!
"""+dsy+"""
\33[33mCombo klasörünüzde """ +str(say)+""" adet dosya bulundu !
	""")
 	dsyno=str(input(" \33[31mCombo No =\33[0m"))
 	say=0
 	for files in os.listdir (dir):
 			say=say+1
 			if dsyno==str(say):
 				dosyaa=(dir+files)
 	say=0
 	print(dosyaa) 
 	c=open(dosyaa, 'r')
 	totLen=c.readlines()
 	
os.remove(dosyaa) 	
temiz=dosyaa
storehouse = set()
with open(dosyaa, 'w+') as out:
	for i in totLen:
		line=(i.replace('',''))
		if line not in storehouse:
			out.write(line)
			storehouse.add(line)
			
print("""


İŞLEM TAMAMLANDI.........		


byFeyzullahK
	""")	
quit()



def remove_duplicates(infile):
    storehouse = set()
    with open('/sdcard/combo/'+temiz, 'w+') as out:
        for line in open(infile):
            if line not in storehouse:
                out.write(line)
                storehouse.add(line)

remove_duplicates('/sdcard/combo/1@Feyzo.txt')