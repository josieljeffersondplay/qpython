#Telegram> @🖋️PKG📚


yeninesil=(
"00:1A:79:",
"33:44:CF:",
"28:79:94:",
"A0:BB:3E:",
"90:0E:B3:",)

import random
import subprocess,webbrowser
subprocess.run(["clear", ""])
feyzo=("""
\33[32m▰▰ (｡◕‿◕｡) P♥R♥A♥V♥E♥E♥N♥ (｡◕‿◕｡) ▰▰▰▰           \33[33m            
     
╔═════════════════════════════════        
║         ▞▞▞ 🅿🆁🅰🆅🅴🅴🅽 ▞▞▞       
╚══════════════════════════════════     
              
\33[32m▰▰▰▰ MAC GENARATOR 🅿🆁🅰🆅🅴🅴🅽 ▰▰▰▰             \33[0m\33[1;40m""")

print(feyzo) 
print("""

Mac Combo Generating
""")
nnesil=str(yeninesil)
nnesil=(nnesil.count(',')+1)
for xd in range(0,(nnesil)):
		print(str(xd+1)+" - "+yeninesil[xd] )
#subprocess.run(["clear", ""])


#print(nnesil)
i=0
nesil=0
dosya=input("""
Enter Your Combo File Name...

File name=""")
karisik=input("""
\33[1;31;40m 
Mixed\33[0m\33[1;40m Create mac type ?

\33[1;31;43m Yes\33[0m\33[1;31;40m Or \33[1;31;46mNo\33[0m Write\033[1;40m=""")
karisik=karisik.upper()
print("")
if not karisik[:1]=="E" :
	for xd in range(0,(nnesil)):
		print(str(xd+1)+" - "+yeninesil[xd] )
	nesil=input("""
	
Choose Mac type=""")

adet=input("""

Number of macs to generate=""")

DosyaA="/sdcard/qpython/combo/" +dosya+"@Praveen.txt"
def kaydet(mac):
    dosya=open(DosyaA,'a+') 
    dosya.write(mac)
    dosya.close()


while True:
	#hex_num = hex(mag)[2:].zfill(6)
	genmac = "%02x:%02x:%02x"% (random.randint(0, 256),random.randint(0, 256),random.randint(0, 256))
	genmac=genmac.replace('100','10')
	#print(karisik[:1])
	if karisik[:1]=="E" :
		for xd in range(0,nnesil):
				genmac = "%02x:%02x:%02x"% (random.randint(0, 256),random.randint(0, 256),random.randint(0, 256))
				genmac=genmac.replace('100','10')
				print(yeninesil[xd]+genmac)
				kaydet(yeninesil[xd]+genmac+"\n")
	else:
		print(yeninesil[int(nesil)-1]+genmac)
		kaydet(yeninesil[int(nesil)-1]+genmac+"\n")
	i=i+1
	if str(i) ==adet:
		break
print("\n\nProcess Copmlete now Goto Scanner and Scan for Fun\n\n")
	
