import os,pip
try:
	import requests
except:
	print('modul hatası')
	#print("requests modulu yüklü değil \n requests modulü yükleniyor \n")
	#pip.main(['install', 'requests'])
	#import requests

import random, time, datetime
import subprocess
import json, sys, re
import pathlib

import logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS="TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_AES_128_GCM_SHA256:TLS_RSA_WITH_AES_256_GCM_SHA384:TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_3DES_EDE_CBC_SHA:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256"
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
logging.captureWarnings(True)
try:
	import cfscrape
	sesq= requests.Session()
	ses = cfscrape.create_scraper(sess=sesq)
except:
	ses= requests.Session()
try:
	import androidhelper as sl4a
	ad = sl4a.Android()
except:pass

pattern= "(^\S{2,}:\S{2,}$)|(^.*?(\n|$))"
subprocess.run(["clear", ""])
say=0
hit=0
bul=0
cpm=1

feyzo=("""
\33[32m
 \33[0m\33[0m╭─────\33[1;31m𝗨𝗥𝗟_𝗖𝗵𝗲𝗰𝗸𝗲𝗿\33[0m 𝓑𝔂 🅵🅴🆈🆉🅾️\33[0m────╮\33[0m
Bu çalışma @FeyzullahK tarafından kodlanmıştır. 

 ▰▰▰▰▰▰▰ 𝓑𝔂 𝙁𝙚𝙮𝙯𝙤@ ▰▰▰▰▰▰▰  '' " '
\33[0m""") 

print(feyzo) 
#=========++===+++++========++
 #Combo adını giriniz (user:pass)
 #dahili hafıza ana dizine atınız   
#combo =input("""
#MAC combonuzun adını yazınız...!
#	\33[1mDosya Adı=""") 

	
say=0
dsy=""
dir='/sdcard/combo/'
for files in os.listdir (dir):
	#if files.endswith(".txt"):
	say=say+1
	dsy=dsy+"	"+str(say)+"-) "+files+'\n'
print ("""Aşağıdaki listeden combonuzu seçin!!!
	
 """+dsy+"""
 
\33[33mCombo klasörünüzde """ +str(say)+""" adet dosya bulundu !
""")

dsyno=str(input(" \33[31mCombo No =\33[0m"))
say=0
for files in os.listdir (dir):
	#if files.endswith(".txt"):
	say=say+1
	if dsyno==str(say):
		dosyaa=(dir+files)
		break
say=0

print(dosyaa)
subprocess.run(["clear", ""])
subprocess.run(["clear", ""])
subprocess.run(["clear", ""])
print(feyzo) 
HEADERA={
"User-Agent":"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 2721 Mobile Safari/533.3" ,
"Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
"Cookie": "stb_lang=en; timezone=Europe/Paris;",
"Accept-Encoding": "gzip, deflate" ,
"Connection": "Keep-Alive" ,
"X-User-Agent":"Model: MAG254; Link: Ethernet",
	}	
for fyz in open(dosyaa, 'r'):
	if not fyz =="":
		if not 'http://' in fyz:
			fyz='http://'+str(fyz)
		
		if ' ' in fyz:
			fyz=fyz.replace(' ','')
		if fyz.count(':')==0:#not ':' in fyz:
			fyz=fyz+':80'
			print(fyz)
			if fyz==fyz+'/:80':
				fyz=fyz.replace('/:80',':/80')
				
			
		try:
			ses.get(str(fyz),headers=HEADERA, timeout=7, verify=False)
			#dgr='\33[1;32m'+str(fyz).replace('\n','') +'  -  \33[107m🅞🅝🅛🅘🅝🅔     \33[0m\n'
			#dgr='\33[1;32m'+str(fyz).replace('\n','') +' 33\107m- 🅞🅝🅛🅘🅝🅔\33[0m\n'
			dgr='\33[1;32m'+str(fyz).replace('\n','') +' \33[30;102m-🅞🅝🅛🅘🅝🅔     \33[0m\n'
			print(dgr)
		except:
				
			
				headerc={
"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
"Pragma":"no-cache",
"Accept":"*/*",
				}
				link=""
				link=fyz.replace('http://','').replace('/c/','').replace('/c','').replace('http://','').replace('/','').replace('\n','')
				url=""
				url="https://us.host-tools.com/website-status/"+link+"/http"
				#print(url)
				res=ses.get(url,headers=headerc, timeout=15, verify=False)
				veri=str(res.text).split('<title>')[1].split('</title>')[0]
				
				if 'ONLINE' in veri:
					renk='\33[1;36m'
					#print('http://'+veri)
					dgr=renk+str(fyz).replace('\n','') +'  -  🇻 🇵 🇳     \33[0m\n'
					print(dgr)
				else:
					if 'OFFLINE' in veri:
						renk='\33[1;31m'
						#print('http://'+veri)
					else:
						renk='\33[1;31m'
					dgr=renk+str(fyz).replace('\n','') +'  -  🅞🅕🅕🅛🅘🅝🅔     \33[0m\n'
				#quit()
			
					print(dgr)