from random import choice
import traceback


string = '0123456789ABCDEF'
file = '/sdcard/qpython/combo/ComboMacAddresses.txt'

def duplicate(path):
  f = open(path, 'r', errors='ignnore').readlines()
  old = len(f)
  new_f = set(f)
  new = len(new_f)
  o = open(path, 'w')
  for line in new_f:
    o.write(line)
  print(f"{old - new} duplicate(s) have been removed!")
  print(f"\nFinished! Results have been saved in {path}")


def mode1():
  mac = ''.join(choice(string) for _ in range(6))
  return f"00:1A:79:{mac[0:2]}:{mac[2:4]}:{mac[4:6]}\n"

def mode2():
  mac = ''.join(choice(string) for _ in range(6))
  return f"10:27:BE:{mac[0:2]}:{mac[2:4]}:{mac[4:6]}\n"
  
def mode3(custom):
  list1 = []
  for letter in custom:
    if letter == '*':
      letter = letter.replace('*', ''.join(choice(string)))
    list1.append(letter)
  return ''.join(list1) + "\n"


def generator(mode, custom):
  with open(file, 'w') as o:
    for x in range(number):
      if mode == '1':
        o.write(mode1())
      if mode == '2':
        o.write(mode2())
      elif mode == '3':
        o.write(mode3(custom))
      print(f"Generated: {x + 1} MAC addresses", end='\r')
  print("\nRemoving duplicates...", end='\r')
  duplicate(file)


if __name__ == '__main__':
  try:
    print("""
                        

                ██╗░░░██╗██╗██████╗░  ███╗░░░███╗░█████╗░░█████╗░
                ██║░░░██║██║██╔══██╗  ████╗░████║██╔══██╗██╔══██╗
                ╚██╗░██╔╝██║██████╔╝  ██╔████╔██║███████║██║░░╚═╝
                ░╚████╔╝░██║██╔═══╝░  ██║╚██╔╝██║██╔══██║██║░░██╗
                ░░╚██╔╝░░██║██║░░░░░  ██║░╚═╝░██║██║░░██║╚█████╔╝
                ░░░╚═╝░░░╚═╝╚═╝░░░░░  ╚═╝░░░░░╚═╝╚═╝░░╚═╝░╚════╝░

  ░██████╗░███████╗███╗░░██╗███████╗██████╗░░█████╗░████████╗░█████╗░██████╗░
  ██╔════╝░██╔════╝████╗░██║██╔════╝██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗
  ██║░░██╗░█████╗░░██╔██╗██║█████╗░░██████╔╝███████║░░░██║░░░██║░░██║██████╔╝
  ██║░░╚██╗██╔══╝░░██║╚████║██╔══╝░░██╔══██╗██╔══██║░░░██║░░░██║░░██║██╔══██╗
  ╚██████╔╝███████╗██║░╚███║███████╗██║░░██║██║░░██║░░░██║░░░╚█████╔╝██║░░██║
  ░╚═════╝░╚══════╝╚═╝░░╚══╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝
                                      """)
    mode = input("""   Select Mode:
    1. Default: 00:1A:79:**:**:**
    2. Default: 10:27:BE:**:**:**
    3. Custom (Example: 00:1A:79:*8:1B:**)
    > """)
    custom = input("Enter custom mode: ") if mode == '3' else None
    number = int(input("Enter the amount of Macs to generate: "))
    generator(mode, custom)
  except:
    print(traceback.format_exc())
    print('Something went wrong, please try again. If the same error keeps happening contact oppaje.')
  input("Press enter to close: ")
