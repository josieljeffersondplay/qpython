#SSHFENIX GERADOR 10.000 LETRAS E NÚMEROS ALEATÓRIOS - DIVINO MOD
#Exemplo : 9C8a2eb5:A6W49k3e
# -------------------------------
import os,pip, random, csv
try:
	import requests
except:
	print("requests modulu yüklü değil \n requests modulü yükleniyor \n")
	pip.main(['install', 'requests'])
	import requests

import random, time, datetime
import subprocess
import json, sys, re,base64
import pathlib
import threading
import shutil

import logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS="TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_AES_128_GCM_SHA256:TLS_RSA_WITH_AES_256_GCM_SHA384:TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_3DES_EDE_CBC_SHA:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256"
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
logging.captureWarnings(True)
mac = ""#str(get_mac())
nick=""
		
try:
	import cfscrape
	sesq= requests.Session()
	ses = cfscrape.create_scraper(sess=sesq)
except:
	ses= requests.Session()

try:
	import androidhelper as sl4a
	ad = sl4a.Android()
except:pass

pattern= "(^\S{2,}:\S{2,}$)|(^.*?(\n|$))"
subprocess.run(["clear", ""])
say=0
hit=0
bul=0
cpm=1


feyzo=("""                   
 \33 Gerador 8 números e letras aleatórios
Ex: 9C8a2eb5:A6W49k3e \33[0m
\33[0m\33[1;5;30;107m                                            
             |▮▮||| BY_DIVINO  |||▮▮|             
                                            
\33[0m\33[1;44m
                 GERADO COM SUCESSO!         
\33[0m           
   \33[0;1m Salvo na pasta arquivos\33[0m""")
print(feyzo)
 
 
 
lista1 = ['a','b', 'c', 'd', 'e','f', 'g','h','i','j','k', 'l', 'm', 'n', 'o','p', 'q', 'r', 's', 't', 'w','v', 'x', 'z''A','B', 'C', 'D', 'E','F', 'G','H','I','J','K', 'L', 'M', 'N', 'O','P', 'Q', 'R', 'S', 'T', 'W','V', 'X', 'Z']
lista2 = ['e', 'u', 'i', 'a', 'o']
lista3 = ['1','2','3','4','5','6','7','8','9','0','a','b', 'c', 'd', 'e','f', 'g','h','i','j','k', 'l', 'm', 'n', 'o','p', 'q', 'r', 's', 't', 'w','v', 'x', 'z''A','B', 'C', 'D', 'E','F', 'G','H','I','J','K', 'L', 'M', 'N', 'O','P', 'Q', 'R', 'S', 'T', 'W','V', 'X', 'Z']
lista4 = [':']
lista5 = ['1','2','3','4','5','6','7','8','9','0']
lista6 = ['1','2','3','4','5','6','7','8','9','0','a','b', 'c', 'd', 'e','f', 'g','h','i','j','k', 'l', 'm', 'n', 'o','p', 'q', 'r', 's', 't', 'w','v', 'x', 'z']
lista7 = ['a','b', 'c', 'd', 'e','f', 'g','h','i','j','k', 'l', 'm', 'n', 'o','p', 'q', 'r', 's', 't', 'w','v', 'x', 'z']
lista8 = ['A','B', 'C', 'D', 'E','F', 'G','H','I','J','K', 'L', 'M', 'N', 'O','P', 'Q', 'R', 'S', 'T', 'W','V', 'X', 'Z']
lista9 = ['1','2','3','4','5','6','7','8','9','0','A','B', 'C', 'D', 'E','F', 'G','H','I','J','K', 'L', 'M', 'N', 'O','P', 'Q', 'R', 'S', 'T', 'W','V', 'X', 'Z']
with open("/sdcard/combo/combo.m3u.sm1ar.xyz.1000000.csv", 'w', newline='') as saida:
    escrever = csv.writer(saida)
    for i in range(1000000):

        inicio = ''
        letra1 = random.choice(lista4)
        letra2 = random.choice(lista6)
        letra3 = random.choice(lista6)
        letra4 = random.choice(lista6)
        letra5 = random.choice(lista6)
        letra6 = random.choice(lista6)
        letra7 = random.choice(lista6)        
        fim = ''
  
            
        nome = inicio + "trial" + letra1 + letra2 + letra3 + letra4 + letra5 + letra6 + letra7 + fim
        escrever.writerow([nome])
        i =+ 1

print ("\33[1;37;42m")
print (n," registros criados com sucesso : ",filename,)
print ("\33[0m")
print (" 🇧​🇾​ ☛ 🆃🅰️🅿️🅸🅽🅰🅺🅲🅸 ☚")
print (" ")
print (" ")