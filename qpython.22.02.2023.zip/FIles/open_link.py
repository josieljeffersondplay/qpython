import subprocess
print(subprocess.run(["xdg-open","https://google.com"], capture_output=True))
