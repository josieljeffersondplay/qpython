import random
import subprocess
subprocess.run(["clear", ""])
import string



#largocadena= 20 #longitud de la cadena de texto


c = ["1","2","3","4","5","6","7","8","9","0","9","8","7","6","5","4","3","2","1"]

e = ["1","2","3","4","5","6","7","8","9","0","9","8","7","6","5","4","3","2","1"]
print(" ")
print(" ")


n = int(input("""   \33[0m\33[1;41m(.txt) ᘜᗴᑎᗴᖇᗩᗪOᖇ ᗰI᙭TO        
	    TᗴOՏՏᑭᗴᖇᑌ-ᒍᑕ      
\33[0m\n\nPONGA LA CANTIDAD A GENERAR :   """))
print (" ")
largouser=input("Ingrese longitud user: ")

if largouser == "0" or largouser=="":
    largouser="4"
largouser=int(largouser)
print(" ")
largopas=input("Ingresd longitud password: ")
if largopas== "0" or largopas=="":
    largopas="4"
largopas=int(largopas)


print (" ")
print ("\t\t\33[1;100m (.txt) Escriba \33[0m ")
filename = input("\nNombre del combo     :  ")
filename = filename + ".txt"
print (" ")



f = open(filename, "w")
f.write("")
f.close()



i = 1

while i <= n:
   
   user = (''.join(random.choice(string.digits) for _ in range(largouser)))
   pas  = (''.join(random.choice(string.digits) for _ in range(largouser)))
   
   user=user+":"+pas
   print(i," = ",user)
   f = open(filename, "a")
   f.write(user)
   f.write("\n")
   f.close()
   i += 1
   


print ("\33[1;37;42m")
print (n," COMBOS GENERADOS CON EXITO : ",filename,)
print ("\33[0m")
print ("👍TᗴOՏՏᑭᗴᖇᑌ-ᒍᑕ👍")
print (" ")
print (" ")

