import random
import subprocess
subprocess.run(["clear", ""])
import string

# Código feito por TᗴOՏՏᑭᗴᖇᑌ-ᒍᑕ
# MOD by Guhhzin

#largocadena= 20 #longitud de la cadena de texto


c = ['1','2','3','4','5','6','7','8','9','0','a','b', 'c', 'd', 'e','f', 'g','h','i','j','k', 'l', 'm', 'n', 'o','p', 'q', 'r', 's', 't', 'u', 'w','v', 'x', 'y', 'z', 'A','B', 'C', 'D', 'E','F', 'G','H','I','J','K', 'L', 'M', 'N', 'O','P', 'Q', 'R', 'S', 'T', 'U', 'W','V', 'X', 'Y', 'Z']

print(" ")
print(" ")


n = int(input("""   \33[0m\33[1;41m(.txt) ᘜᗴᑎᗴᖇᗩᗪOᖇ ᗰI᙭TO        
	    TᗴOՏՏᑭᗴᖇᑌ-ᒍᑕ
	    
	     MOD BY GUHHZIN E DIVINO
	           
\33[0m\n\nINSIRA A QUANTIDADE QUE QUER GERAR :   """))
print (" ")
largouser=input("Insira o comprimento do usuário: ")
if largouser == "0" or largouser=="":
    largouser="4"
largouser=int(largouser)
print(" ")
largopass=input("Insira o comprimento da senha: ")
if largopass == "0" or largopass=="":
    largopass="4"
largopass=int(largopass)
print(" ")
print ("\t\t\33[1;100m (.txt) Escreva \33[0m ")
filename = input("\nNome do combo     :  ")
filename = filename + ".txt"
print (" ")



f = open(filename, "w")
f.write("")
f.close()



i = 1

while i <= n:
   
   user = (''.join(random.choice(c) for _ in range(largouser)))
   pas  = (''.join(random.choice(c) for _ in range(largopass)))
   
   user=user+":"+pas
   print(i," = ",user)
   f = open(filename, "a")
   f.write(user)
   f.write("\n")
   f.close()
   i += 1
   


print ("\33[1;37;42m")
print (n," COMBOS GERADOS COM SUCESSO : ",filename,)
print ("\33[0m")
print ("👍TᗴOՏՏᑭᗴᖇᑌ-ᒍᑕ👍")
print (" ")
print (" ")
