import os,pip, random, csv

 
 
 
lista1 = ['a','b', 'c', 'd', 'e','f', 'g','h','i','j','k', 'l', 'm', 'n', 'o','p', 'q', 'r', 's', 't', 'w','v', 'x', 'z']
lista2 = ['e', 'u', 'i', 'a', 'o']
lista3 = ['1','2','3','4','5','6','7','8','9','0']

with open("arquivos/saida.csv", 'w', newline='') as saida:
    escrever = csv.writer(saida)
    for i in range(10000):

        inicio = 'BMW'
        letra1 = random.choice(lista3)
        letra2 = random.choice(lista3)
        letra3 = random.choice(lista3)
        fim = ''
  
            
        nome = inicio + letra1 + letra2 + letra3 +  fim
        escrever.writerow([nome])
        i =+ 1

